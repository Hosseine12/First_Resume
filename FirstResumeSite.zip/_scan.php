<?php
$f = __DIR__ . '/index.php';
$lines = file($f);
echo "TOTAL: " . count($lines) . PHP_EOL;
$needles = ['header-inner','nav-toggle','chatFab','topbar','main-nav','nav-auth','nav-extra','chat-fab','logo-dot','site-header'];
foreach ($lines as $i => $s) {
    foreach ($needles as $n) {
        if (strpos($s, $n) !== false) {
            echo ($i + 1) . ": " . rtrim(substr($s, 0, 120)) . PHP_EOL;
            break;
        }
    }
}
