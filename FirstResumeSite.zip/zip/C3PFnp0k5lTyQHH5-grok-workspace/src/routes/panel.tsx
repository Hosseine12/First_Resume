import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { RedirectToSignIn, SignedIn, SignedOut } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { useCart } from "@/lib/cart";
import { money } from "@/lib/utils";
import { readEvents, summarize } from "@/lib/analytics";
import { draftSeo } from "@/lib/server/ai";
import { productById } from "@/lib/catalog";

export const Route = createFileRoute("/panel")({ component: Panel });

function Panel() {
  return (
    <SiteShell>
      <SignedOut>
        <RedirectToSignIn to="/login" />
      </SignedOut>
      <SignedIn>
        <PanelInner />
      </SignedIn>
    </SiteShell>
  );
}

function PanelInner() {
  const user = useCurrentUser();
  const cart = useCart();
  const stats = useMemo(() => summarize(readEvents()), []);
  const [seo, setSeo] = useState("");
  const [busy, setBusy] = useState(false);

  function download(id: string) {
    const p = productById(id);
    if (!p || !cart.owned.has(id)) return;
    const blob = new Blob(
      [
        `${p.title}\nGoldenDevs license (demo)\nخریدار: ${user?.primaryEmail ?? ""}\nاین فایل نمایشی است؛ سورس کامل پس از تحویل واقعی ارسال می‌شود.\n`,
      ],
      { type: "text/plain;charset=utf-8" },
    );
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${p.slug}-license.txt`;
    a.click();
  }

  return (
    <div className="container-site py-10 grid gap-8">
      <div>
        <h1 className="font-display text-4xl">پنل کاربری</h1>
        <p className="text-muted mt-1">{user?.displayName ?? user?.primaryEmail}</p>
      </div>
      <section className="surface rounded-[var(--radius-lg)] p-5">
        <h2 className="font-medium mb-3">سفارش‌ها</h2>
        {cart.orders.length === 0 ? (
          <p className="text-sm text-muted">سفارشی نیست.</p>
        ) : (
          <ul className="grid gap-3">
            {cart.orders.map((o) => (
              <li key={o.ref} className="border-b border-line pb-3">
                <p className="font-medium">{o.ref}</p>
                <p className="text-sm text-muted">{money(o.total)}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {o.items.map((i) => (
                    <button key={i.id} type="button" className="btn btn-soft text-sm" onClick={() => download(i.id)}>
                      دانلود نمایشی {i.title}
                    </button>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="surface rounded-[var(--radius-lg)] p-5">
        <h2 className="font-medium mb-3">فعالیت این مرورگر</h2>
        <p className="text-sm text-muted">مجموع رویداد: {stats.total}</p>
        <ul className="mt-3 text-sm grid gap-1">
          {stats.paths.slice(0, 8).map(([p, n]) => (
            <li key={p}>
              {p} — {n}
            </li>
          ))}
        </ul>
      </section>
      <section className="surface rounded-[var(--radius-lg)] p-5">
        <h2 className="font-medium mb-2">دستیار محتوا</h2>
        <p className="text-sm text-muted mb-3">موضوع بدهید؛ پیش‌نویس اصیل با نکات سئو. متن رقیب اختیاری است و کپی نمی‌شود.</p>
        <form
          className="grid gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            setBusy(true);
            setSeo("");
            try {
              const r = await draftSeo({
                data: {
                  topic: String(fd.get("topic") ?? ""),
                  notes: String(fd.get("notes") ?? ""),
                  competitor: String(fd.get("competitor") ?? ""),
                },
              });
              setSeo(r.ok ? r.text : r.error);
            } catch (ex) {
              setSeo(ex instanceof Error ? ex.message : "خطا");
            } finally {
              setBusy(false);
            }
          }}
        >
          <input className="field" name="topic" required placeholder="موضوع مقاله" />
          <textarea className="field min-h-20" name="notes" placeholder="زاویه یا نکات خودتان" />
          <textarea className="field min-h-20" name="competitor" placeholder="خلاصهٔ رقیب (اختیاری)" />
          <button className="btn btn-primary" type="submit" disabled={busy}>
            پیش‌نویس
          </button>
        </form>
        {seo && <pre className="mt-4 text-sm whitespace-pre-wrap font-sans">{seo}</pre>}
      </section>
      <Link to="/shop" className="btn btn-ghost w-fit">
        ادامهٔ خرید
      </Link>
    </div>
  );
}
