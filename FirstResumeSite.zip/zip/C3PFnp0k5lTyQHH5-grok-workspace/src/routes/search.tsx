import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { searchCatalog } from "@/lib/catalog";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>) => ({ q: String(s.q ?? "") }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const r = searchCatalog(q);
  return (
    <SiteShell>
      <div className="container-site py-10">
        <h1 className="font-display text-4xl">جستجو</h1>
        <p className="text-muted mt-2">{q ? `نتایج «${q}»` : "عبارتی بنویسید."}</p>
        <section className="mt-8">
          <h2 className="font-medium mb-3">محصولات</h2>
          <ul className="grid gap-2">
            {r.products.map((p) => (
              <li key={p.id}>
                <Link to="/shop/$slug" params={{ slug: p.slug }} className="text-brand">
                  {p.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
        <section className="mt-6">
          <h2 className="font-medium mb-3">مقالات</h2>
          <ul className="grid gap-2">
            {r.topics.map((t) => (
              <li key={t.slug}>
                <Link to="/topics/$slug" params={{ slug: t.slug }}>
                  {t.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </SiteShell>
  );
}
