import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { AzarinDemo } from "@/components/demos/azarin";
import { CmsDemo } from "@/components/demos/cms";
import { UiDemo } from "@/components/demos/ui-kit";
import { ZarvanDemo } from "@/components/demos/zarvan";
import { ZaferanDemo } from "@/components/demos/zaferan";
import { productBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/preview/$slug")({ component: Preview });

function Preview() {
  const { slug } = Route.useParams();
  const product = productBySlug(slug);
  const title =
    slug === "zaferan" ? "رستوران زعفران" : product?.title ?? "پیش‌نمایش";
  return (
    <SiteShell>
      <div className="container-site py-8">
        <p className="text-sm text-muted">پیش‌نمایش محدود — دادهٔ نمایشی، بدون دسترسی به سورس واقعی</p>
        <div className="flex flex-wrap items-center justify-between gap-3 mt-2 mb-6">
          <h1 className="font-display text-3xl">{title}</h1>
          {product && (
            <Link to="/shop/$slug" params={{ slug: product.slug }} className="btn btn-ghost">
              صفحهٔ محصول
            </Link>
          )}
        </div>
        {slug === "azarin" && <AzarinDemo />}
        {slug === "lite-cms" && <CmsDemo />}
        {slug === "turquoise-ui" && <UiDemo />}
        {slug === "zarvan-bot" && <ZarvanDemo />}
        {slug === "zaferan" && <ZaferanDemo />}
        {!["azarin", "lite-cms", "turquoise-ui", "zarvan-bot", "zaferan"].includes(slug) && (
          <p>برای این مورد پیش‌نمایشی نیست.</p>
        )}
      </div>
    </SiteShell>
  );
}
