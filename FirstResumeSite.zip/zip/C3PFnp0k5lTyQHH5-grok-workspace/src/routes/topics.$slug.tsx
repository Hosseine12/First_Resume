import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { TOPICS } from "@/lib/catalog";

export const Route = createFileRoute("/topics/$slug")({ component: Topic });

function Topic() {
  const { slug } = Route.useParams();
  const t = TOPICS.find((x) => x.slug === slug);
  if (!t) throw notFound();
  return (
    <SiteShell>
      <article className="container-site py-10 max-w-3xl">
        <p className="text-sm text-muted">
          <Link to="/topics">آموزش</Link> / {t.title}
        </p>
        <h1 className="font-display text-4xl mt-2">{t.title}</h1>
        <p className="text-lg text-muted mt-3">{t.lead}</p>
        <p className="mt-6 leading-8">{t.body}</p>
      </article>
    </SiteShell>
  );
}
