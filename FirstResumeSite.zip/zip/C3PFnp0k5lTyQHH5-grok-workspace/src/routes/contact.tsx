import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { sendContact } from "@/lib/server/ai";
import { track } from "@/lib/analytics";
import { BRAND } from "@/lib/catalog";

export const Route = createFileRoute("/contact")({ component: Contact });

function Contact() {
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <SiteShell>
      <div className="container-site py-10 max-w-xl">
        <p className="text-sm text-muted">خانه / تماس</p>
        <h1 className="font-display text-4xl mt-2">تماس با من</h1>
        <p className="text-muted mt-2 text-sm">
          {BRAND.email} — فرم دارای محدودیت نرخ است و ایمیل را در کلاینت ذخیره نمی‌کند.
        </p>
        <form
          className="grid gap-3 mt-6"
          onSubmit={async (e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            setBusy(true);
            setMsg(null);
            try {
              const res = await sendContact({
                data: {
                  name: String(fd.get("name") ?? ""),
                  email: String(fd.get("email") ?? ""),
                  subject: String(fd.get("subject") ?? ""),
                  body: String(fd.get("body") ?? ""),
                },
              });
              track("contact");
              setMsg(res.ok ? "پیام دریافت شد." : res.error);
              if (res.ok) e.currentTarget.reset();
            } catch (err) {
              setMsg(err instanceof Error ? err.message : "خطا");
            } finally {
              setBusy(false);
            }
          }}
        >
          <input className="field" name="name" required placeholder="نام" maxLength={80} />
          <input className="field" name="email" type="email" required placeholder="ایمیل" />
          <input className="field" name="subject" required placeholder="موضوع" maxLength={120} />
          <textarea className="field min-h-32" name="body" required placeholder="پیام" maxLength={2000} />
          <button className="btn btn-primary" type="submit" disabled={busy}>
            ارسال
          </button>
          {msg && <p className="text-sm text-muted">{msg}</p>}
        </form>
      </div>
    </SiteShell>
  );
}
