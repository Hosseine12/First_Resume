import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { ProductCard } from "@/components/product-card";
import { ProductCover } from "@/components/covers";
import { BRAND, PRODUCTS, PROJECTS, TOPICS } from "@/lib/catalog";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <SiteShell>
      <section className="container-site py-12 sm:py-16 grid gap-10 lg:grid-cols-[1.05fr_.95fr] items-center">
        <div>
          <p className="kicker">استودیوی {BRAND.fa}</p>
          <h1 className="font-display text-5xl sm:text-6xl mt-3">{BRAND.owner}</h1>
          <p className="mt-3 text-lg text-muted">{BRAND.slogan} — وب‌سایت، قالب و ابزار فول‌استک.</p>
          <p className="mt-4 max-w-prose text-muted">
            کد تمیز، امنیت لایه‌لایه، پیش‌نمایش واقعی محصول بدون لینک مرده. قیمت و موجودی را نمی‌توان با Inspect عوض کرد.
          </p>
          <div className="flex flex-wrap gap-2 mt-6">
            <Link to="/shop" className="btn btn-primary">
              فروشگاه
            </Link>
            <Link to="/portfolio" className="btn btn-ghost">
              نمونه‌کارها
            </Link>
          </div>
        </div>
        <div className="surface rounded-[var(--radius-lg)] overflow-hidden">
          <ProductCover kind="desk" title="فضای کار گلدن‌دِوز" />
        </div>
      </section>

      <section className="container-site pb-12">
        <p className="kicker">محصولات</p>
        <h2 className="font-display text-3xl mt-2 mb-6">قابل خرید، با پیش‌نمایش زنده</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          {PRODUCTS.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="container-site pb-12">
        <p className="kicker">نمونه‌کار</p>
        <h2 className="font-display text-3xl mt-2 mb-6">پروژه‌های اخیر</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          {PROJECTS.map((p) => (
            <Link key={p.slug} to="/portfolio" className="surface rounded-[var(--radius-lg)] overflow-hidden">
              <ProductCover kind={p.slug === "zaferan" ? "resto" : "template"} title={p.title} />
              <div className="p-4">
                <p className="text-xs text-muted">{p.year}</p>
                <h3 className="font-medium mt-1">{p.title}</h3>
                <p className="text-sm text-muted mt-1">{p.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="container-site pb-16">
        <p className="kicker">آموزش</p>
        <h2 className="font-display text-3xl mt-2 mb-6">یادداشت‌های کوتاه</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {TOPICS.slice(0, 4).map((t) => (
            <Link key={t.slug} to="/topics/$slug" params={{ slug: t.slug }} className="surface rounded-[var(--radius-md)] p-4">
              <h3 className="font-medium">{t.title}</h3>
              <p className="text-sm text-muted mt-1">{t.lead}</p>
            </Link>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
