import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { TOPICS } from "@/lib/catalog";

export const Route = createFileRoute("/topics/")({ component: Topics });

function Topics() {
  return (
    <SiteShell>
      <div className="container-site py-10">
        <p className="text-sm text-muted">خانه / آموزش</p>
        <h1 className="font-display text-4xl mt-2">آموزش و مقالات</h1>
        <div className="grid gap-3 sm:grid-cols-2 mt-8">
          {TOPICS.map((t) => (
            <Link key={t.slug} to="/topics/$slug" params={{ slug: t.slug }} className="surface rounded-[var(--radius-md)] p-5">
              <h2 className="font-medium">{t.title}</h2>
              <p className="text-sm text-muted mt-1">{t.lead}</p>
            </Link>
          ))}
        </div>
      </div>
    </SiteShell>
  );
}
