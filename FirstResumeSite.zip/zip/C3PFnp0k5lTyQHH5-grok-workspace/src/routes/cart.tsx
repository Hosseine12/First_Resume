import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { useCart } from "@/lib/cart";
import { faNum, money } from "@/lib/utils";

export const Route = createFileRoute("/cart")({ component: Cart });

function Cart() {
  const cart = useCart();
  return (
    <SiteShell>
      <div className="container-site py-10">
        <h1 className="font-display text-4xl">سبد خرید</h1>
        {cart.lines.length === 0 ? (
          <p className="mt-6 text-muted">سبد خالی است.</p>
        ) : (
          <ul className="mt-6 grid gap-3">
            {cart.lines.map((l) => (
              <li key={l.product.id} className="surface rounded-[var(--radius-md)] p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium">{l.product.title}</p>
                  <p className="text-sm text-muted">{money(l.product.price)}</p>
                  {l.product.stock <= 5 && (
                    <p className="text-xs mt-1">فقط {faNum(l.product.stock)} در انبار</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button type="button" className="btn btn-ghost" onClick={() => cart.setQty(l.product.id, l.qty - 1)}>
                    −
                  </button>
                  <span>{faNum(l.qty)}</span>
                  <button
                    type="button"
                    className="btn btn-ghost"
                    disabled={l.qty >= l.product.stock}
                    onClick={() => cart.setQty(l.product.id, l.qty + 1)}
                  >
                    +
                  </button>
                  <button type="button" className="btn btn-ghost" onClick={() => cart.remove(l.product.id)}>
                    حذف
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
        {cart.lines.length > 0 && (
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <p className="font-display text-2xl">{money(cart.total)}</p>
            <Link to="/checkout" className="btn btn-primary">
              تسویه
            </Link>
          </div>
        )}
      </div>
    </SiteShell>
  );
}
