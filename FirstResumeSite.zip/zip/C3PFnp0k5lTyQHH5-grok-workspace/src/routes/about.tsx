import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { ProductCover } from "@/components/covers";
import { BRAND } from "@/lib/catalog";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <SiteShell>
      <div className="container-site py-10 grid gap-8 lg:grid-cols-[.9fr_1.1fr] items-start">
        <ProductCover kind="desk" title={BRAND.owner} className="surface rounded-[var(--radius-lg)]" />
        <div>
          <p className="text-sm text-muted">خانه / درباره</p>
          <h1 className="font-display text-4xl mt-2">{BRAND.owner}</h1>
          <p className="mt-4 text-muted max-w-prose">
            جزئیات پروژه برایم مهم است: ظاهر خوانا، امنیت از اول، و تحویل زمان‌بندی‌شده. قالب وردپرس تصادفی در این نسخه نیست؛ محصولات همان چیزهایی‌اند که واقعاً می‌فروشم یا می‌سازم.
          </p>
          <div className="grid sm:grid-cols-2 gap-3 mt-6">
            {[
              ["کد تمیز", "ساختار قابل نگهداری"],
              ["امنیت اول", "قیمت و موجودی سمت کاتالوگ"],
              ["زمان‌بندی", "شفاف از جلسهٔ اول"],
              ["یادگیری", "ابزار روز، بدون شلوغی"],
            ].map(([t, d]) => (
              <div key={t} className="surface rounded-[var(--radius-md)] p-4">
                <h3 className="font-medium">{t}</h3>
                <p className="text-sm text-muted mt-1">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
