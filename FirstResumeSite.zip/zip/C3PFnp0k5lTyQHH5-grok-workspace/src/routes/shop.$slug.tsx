import { toast } from "sonner";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { ProductCover } from "@/components/covers";
import { productBySlug } from "@/lib/catalog";
import { money, faNum } from "@/lib/utils";
import { useCart } from "@/lib/cart";
import { track } from "@/lib/analytics";

export const Route = createFileRoute("/shop/$slug")({
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const p = productBySlug(slug);
  if (!p) throw notFound();
  const cart = useCart();
  const owned = cart.owned.has(p.id);
  return (
    <SiteShell>
      <div className="container-site py-10 grid gap-8 lg:grid-cols-2">
        <ProductCover kind={p.kind} title={p.title} className="surface rounded-[var(--radius-lg)]" />
        <div>
          <p className="text-sm text-muted">فروشگاه / {p.kindLabel}</p>
          <h1 className="font-display text-4xl mt-2">{p.title}</h1>
          <p className="mt-4 text-muted">{p.description}</p>
          <ul className="flex flex-wrap gap-2 mt-4">
            {p.stack.map((s) => (
              <li key={s} className="text-xs border border-line rounded-full px-3 py-1">
                {s}
              </li>
            ))}
          </ul>
          <p className="font-display text-3xl text-brand mt-6">{money(p.price)}</p>
          <p className="text-sm text-muted mt-1">موجودی {faNum(p.stock)} — کنترل سمت کاتالوگ</p>
          <div className="flex flex-wrap gap-2 mt-6">
            {p.preview && (
              <Link to="/preview/$slug" params={{ slug: p.slug }} className="btn btn-ghost">
                پیش‌نمایش {p.demoLive ? "زنده" : "محیط"}
              </Link>
            )}
            <button
              type="button"
              className="btn btn-primary"
              disabled={p.stock < 1}
              onClick={() => {
                const r = cart.add(p.id);
                track("add_cart");
                toast(r.message);
              }}
            >
              افزودن به سبد
            </button>
            {owned && (
              <a className="btn btn-soft" href={`/api/download/${p.slug}`} onClick={(e) => e.preventDefault()}>
                دانلود پس از خرید (نسخهٔ نمایشی در پنل)
              </a>
            )}
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
