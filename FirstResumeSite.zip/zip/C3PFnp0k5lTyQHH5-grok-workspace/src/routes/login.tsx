import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authEnabled, signIn, authClient } from "@/lib/auth/client";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <SiteShell>
      <div className="container-site py-12 max-w-md">
        <h1 className="font-display text-4xl">{mode === "in" ? "ورود" : "ثبت‌نام"}</h1>
        <p className="text-sm text-muted mt-2">گوگل، ایکس، یا ایمیل.</p>
        {authEnabled ? (
          <div className="grid gap-2 mt-6">
            {GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                className="btn btn-ghost w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/panel" })}
              >
                ادامه با {p.label}
              </button>
            ))}
            <form
              className="grid gap-3 mt-4"
              onSubmit={async (e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const email = String(fd.get("email") ?? "");
                const password = String(fd.get("password") ?? "");
                const name = String(fd.get("name") ?? "");
                setBusy(true);
                setErr(null);
                try {
                  if (mode === "up") {
                    const r = await authClient.signUp.email({ email, password, name });
                    if (r.error) setErr(r.error.message ?? "ثبت‌نام ناموفق");
                    else window.location.href = "/panel";
                  } else {
                    const r = await authClient.signIn.email({ email, password });
                    if (r.error) setErr(r.error.message ?? "ورود ناموفق");
                    else window.location.href = "/panel";
                  }
                } catch (ex) {
                  setErr(ex instanceof Error ? ex.message : "خطا");
                } finally {
                  setBusy(false);
                }
              }}
            >
              {mode === "up" && <input className="field" name="name" required placeholder="نام" />}
              <input className="field" name="email" type="email" required placeholder="ایمیل" />
              <input className="field" name="password" type="password" required minLength={8} placeholder="رمز (حداقل ۸)" />
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {mode === "in" ? "ورود با ایمیل" : "ساخت حساب"}
              </button>
              {err && <p className="text-sm text-red-700">{err}</p>}
            </form>
            <button type="button" className="text-sm text-brand mt-2" onClick={() => setMode(mode === "in" ? "up" : "in")}>
              {mode === "in" ? "حساب ندارید؟ ثبت‌نام" : "حساب دارید؟ ورود"}
            </button>
          </div>
        ) : (
          <p className="mt-6 text-muted">ورود در این محیط خاموش است.</p>
        )}
        <p className="text-sm mt-8">
          <Link to="/">بازگشت</Link>
        </p>
      </div>
    </SiteShell>
  );
}
