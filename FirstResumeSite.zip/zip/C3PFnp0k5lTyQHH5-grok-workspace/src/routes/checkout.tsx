import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteShell } from "@/components/site-shell";
import { useCart } from "@/lib/cart";
import { money } from "@/lib/utils";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { track } from "@/lib/analytics";

export const Route = createFileRoute("/checkout")({ component: Checkout });

function Checkout() {
  const cart = useCart();
  const [ref, setRef] = useState<string | null>(null);
  return (
    <SiteShell>
      <div className="container-site py-10 max-w-xl">
        <h1 className="font-display text-4xl">تسویه</h1>
        <p className="text-sm text-muted mt-2">پرداخت نمایشی است. مبلغ از کاتالوگ محاسبه می‌شود.</p>
        <SignedOut>
          <p className="mt-6">
            برای ثبت سفارش{" "}
            <Link to="/login" className="text-brand">
              وارد شوید
            </Link>
            .
          </p>
        </SignedOut>
        <SignedIn>
          {ref ? (
            <div className="surface rounded-[var(--radius-md)] p-5 mt-6">
              <p>سفارش ثبت شد.</p>
              <p className="font-medium mt-2">کد پیگیری: {ref}</p>
              <Link to="/panel" className="btn btn-primary mt-4">
                پنل
              </Link>
            </div>
          ) : cart.lines.length === 0 ? (
            <p className="mt-6 text-muted">سبد خالی است.</p>
          ) : (
            <form
              className="grid gap-3 mt-6"
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const r = cart.place({
                  name: String(fd.get("name") ?? ""),
                  phone: String(fd.get("phone") ?? ""),
                  address: String(fd.get("address") ?? ""),
                });
                if (!r.ok) {
                  alert(r.message);
                  return;
                }
                track("checkout");
                setRef(r.ref ?? null);
              }}
            >
              <p className="font-display text-2xl">{money(cart.total)}</p>
              <input className="field" name="name" required placeholder="نام تحویل‌گیرنده" />
              <input className="field" name="phone" required pattern="09[0-9]{9}" placeholder="09xxxxxxxxx" />
              <textarea className="field min-h-24" name="address" required placeholder="نشانی" />
              <button className="btn btn-primary" type="submit">
                پرداخت نمایشی
              </button>
            </form>
          )}
        </SignedIn>
      </div>
    </SiteShell>
  );
}
