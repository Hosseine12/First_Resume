import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { ProductCard } from "@/components/product-card";
import { PRODUCTS } from "@/lib/catalog";

export const Route = createFileRoute("/shop/")({ component: Shop });

function Shop() {
  return (
    <SiteShell>
      <div className="container-site py-10">
        <p className="text-sm text-muted">خانه / فروشگاه</p>
        <h1 className="font-display text-4xl mt-2">فروشگاه</h1>
        <p className="text-muted mt-2 max-w-prose">
          پیش‌نمایش‌ها داخل همین سایت اجرا می‌شوند. قیمت از کاتالوگ خوانده می‌شود، نه از DOM.
        </p>
        <div className="grid gap-5 sm:grid-cols-2 mt-8">
          {PRODUCTS.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </SiteShell>
  );
}
