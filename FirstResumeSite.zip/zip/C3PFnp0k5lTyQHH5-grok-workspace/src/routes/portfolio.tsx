import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { ProductCover } from "@/components/covers";
import { PROJECTS } from "@/lib/catalog";

export const Route = createFileRoute("/portfolio")({ component: Portfolio });

function Portfolio() {
  return (
    <SiteShell>
      <div className="container-site py-10">
        <p className="text-sm text-muted">خانه / نمونه‌کارها</p>
        <h1 className="font-display text-4xl mt-2">نمونه‌کارها</h1>
        <div className="grid gap-5 sm:grid-cols-2 mt-8">
          {PROJECTS.map((p) => (
            <article key={p.slug} className="surface rounded-[var(--radius-lg)] overflow-hidden">
              <ProductCover kind={p.slug === "zaferan" ? "resto" : "template"} title={p.title} />
              <div className="p-4">
                <p className="text-xs text-muted">{p.year}</p>
                <h2 className="font-medium mt-1">{p.title}</h2>
                <p className="text-sm text-muted mt-1">{p.desc}</p>
                {p.preview && (
                  <Link to="/preview/$slug" params={{ slug: p.preview.replace("/preview/", "") }} className="btn btn-ghost mt-3 text-sm">
                    پیش‌نمایش
                  </Link>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </SiteShell>
  );
}
