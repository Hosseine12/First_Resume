import type { ProductKind } from "@/lib/catalog";

export function ProductCover({
  kind,
  title,
  className = "",
}: {
  kind: ProductKind | "resto" | "desk";
  title: string;
  className?: string;
}) {
  const palettes: Record<string, [string, string, string]> = {
    template: ["#0c7f70", "#d7efe9", "#c4a574"],
    script: ["#1f4e5f", "#dce8e6", "#8aa4a1"],
    uikit: ["#2f5d50", "#e7eee8", "#b08968"],
    bot: ["#121816", "#1c2623", "#7f908b"],
    plugin: ["#0c7f70", "#eef4f1", "#c4a574"],
    resto: ["#5c3d2e", "#f3eadb", "#0c7f70"],
    desk: ["#2a322e", "#ece7dc", "#0c7f70"],
  };
  const [a, b, c] = palettes[kind] ?? palettes.template;
  return (
    <svg viewBox="0 0 800 500" className={className} role="img" aria-label={title}>
      <rect width="800" height="500" fill={b} />
      <rect x="40" y="36" width="720" height="428" rx="22" fill={kind === "bot" ? "#0e1412" : "#fff"} opacity="0.92" />
      <rect x="64" y="60" width="120" height="10" rx="5" fill={a} />
      <rect x="64" y="86" width="280" height="28" rx="6" fill={kind === "bot" ? "#d7efe9" : a} opacity="0.9" />
      <rect x="64" y="130" width="210" height="10" rx="5" fill={c} opacity="0.7" />
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(${64 + i * 230}, 180)`}>
          <rect width="210" height="150" rx="14" fill={kind === "bot" ? "#17201d" : b} />
          <rect x="14" y="14" width="182" height="72" rx="8" fill={a} opacity="0.35" />
          <rect x="14" y="98" width="120" height="10" rx="5" fill={a} />
          <rect x="14" y="118" width="80" height="8" rx="4" fill={c} />
        </g>
      ))}
      <text x="400" y="460" textAnchor="middle" fill={a} fontSize="22" fontFamily="Vazirmatn, sans-serif">
        {title}
      </text>
    </svg>
  );
}
