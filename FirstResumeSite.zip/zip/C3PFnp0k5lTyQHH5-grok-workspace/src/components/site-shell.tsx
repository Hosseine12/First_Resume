import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Menu,
  Search,
  ShoppingBag,
  SunMoon,
  X,
  BookOpen,
  LayoutGrid,
  Mail,
  User,
} from "lucide-react";
import { useEffect, useState } from "react";
import { BRAND } from "@/lib/catalog";
import { useCart } from "@/lib/cart";
import { track } from "@/lib/analytics";
import { faNum } from "@/lib/utils";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { ThemeDrawer } from "./theme-drawer";
import { ChatWidget } from "./chat-widget";

const NAV = [
  { to: "/", label: "خانه", icon: LayoutGrid },
  { to: "/shop", label: "فروشگاه", icon: ShoppingBag },
  { to: "/portfolio", label: "نمونه‌کارها", icon: LayoutGrid },
  { to: "/topics", label: "آموزش", icon: BookOpen },
  { to: "/about", label: "درباره", icon: User },
  { to: "/contact", label: "تماس", icon: Mail },
] as const;

export function SiteShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const search = useRouterState({ select: (s) => s.location.searchStr });
  const navigate = useNavigate();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);
  const [q, setQ] = useState("");

  useEffect(() => {
    setOpen(false);
    track("view", pathname);
  }, [pathname, search]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="min-h-dvh flex flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:right-2 focus:z-50 btn btn-primary"
      >
        پرش به محتوا
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-[color-mix(in_oklab,var(--bg)_88%,transparent)]">
        <div className="container-site grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 py-3">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              className="grid size-11 place-items-center rounded-[calc(var(--radius)-6px)] border border-line"
              aria-label={open ? "بستن منو" : "باز کردن منو"}
              aria-expanded={open}
              aria-controls="site-drawer"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
            <Link to="/" className="font-display text-2xl leading-none truncate">
              {BRAND.fa}
              <span className="inline-block size-1.5 rounded-sm bg-accent ms-1 align-middle" />
            </Link>
          </div>

          <form
            className="justify-self-center w-full max-w-[260px] sm:max-w-[300px]"
            role="search"
            onSubmit={(e) => {
              e.preventDefault();
              void navigate({ to: "/search", search: { q } });
            }}
          >
            <label className="flex items-center gap-2 h-11 rounded-full border border-line bg-card px-3">
              <Search size={16} className="shrink-0 opacity-60" aria-hidden />
              <input
                className="w-full bg-transparent text-sm outline-none"
                type="search"
                name="q"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="جستجو…"
                aria-label="جستجو در سایت"
              />
            </label>
          </form>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              className="grid size-11 place-items-center rounded-full border border-line"
              aria-label="تنظیم ظاهر"
              onClick={() => setThemeOpen(true)}
            >
              <SunMoon size={18} />
            </button>
            <Link
              to="/cart"
              className="relative grid size-11 place-items-center rounded-full border border-line"
              aria-label="سبد خرید"
            >
              <ShoppingBag size={18} />
              {count > 0 && (
                <span className="absolute -top-1 -start-1 min-w-5 h-5 px-1 grid place-items-center rounded-full bg-brand text-[11px] text-white">
                  {faNum(count)}
                </span>
              )}
            </Link>
            <div className="hidden md:flex items-center">
              <SignedIn>
                <Link to="/panel" className="btn btn-ghost text-sm px-3 min-h-11">
                  پنل
                </Link>
                <UserButton />
              </SignedIn>
              <SignedOut>
                <Link to="/login" className="btn btn-ghost text-sm px-3 min-h-11">
                  ورود
                </Link>
              </SignedOut>
            </div>
          </div>
        </div>
      </header>

      {open && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-black/40"
          aria-label="بستن منو"
          onClick={() => setOpen(false)}
        />
      )}
      <aside
        id="site-drawer"
        className={`fixed top-0 bottom-0 start-0 z-50 w-[min(92vw,360px)] bg-card border-e border-line p-5 overflow-y-auto transition-transform duration-300 ${open ? "translate-x-0" : "translate-x-full"}`}
      >
        <div className="flex items-center justify-between mb-6">
          <p className="font-display text-xl">{BRAND.fa}</p>
          <button type="button" className="size-11 grid place-items-center" onClick={() => setOpen(false)} aria-label="بستن">
            <X size={20} />
          </button>
        </div>
        <nav className="grid gap-1" aria-label="منوی اصلی">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={`flex items-center gap-3 min-h-11 px-3 rounded-[calc(var(--radius)-6px)] ${pathname === n.to ? "bg-[color-mix(in_oklab,var(--brand)_14%,transparent)]" : ""}`}
            >
              <n.icon size={18} />
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="mt-6 grid gap-2 md:hidden">
          <SignedIn>
            <Link to="/panel" className="btn btn-soft">
              پنل کاربری
            </Link>
            <UserButton />
          </SignedIn>
          <SignedOut>
            <Link to="/login" className="btn btn-primary">
              ورود / ثبت‌نام
            </Link>
          </SignedOut>
        </div>
      </aside>

      <main id="main" className="flex-1">
        {children}
      </main>

      <footer className="mt-16 border-t border-line bg-brand-ink text-[color-mix(in_oklab,white_88%,transparent)]">
        <div className="container-site grid gap-8 py-12 sm:grid-cols-3">
          <div>
            <p className="font-display text-2xl text-white">{BRAND.fa}</p>
            <p className="mt-2 text-sm opacity-80">ساخت وب‌سایت‌های سریع، امن و خوانا. {BRAND.owner}</p>
          </div>
          <div>
            <p className="font-medium text-white mb-2">مسیرها</p>
            <ul className="grid gap-1 text-sm opacity-85">
              {NAV.map((n) => (
                <li key={n.to}>
                  <Link to={n.to}>{n.label}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="text-sm opacity-85">
            <p className="font-medium text-white mb-2">ارتباط</p>
            <p>{BRAND.email}</p>
            <p className="mt-1">{BRAND.phone}</p>
          </div>
        </div>
      </footer>
      <ThemeDrawer open={themeOpen} onClose={() => setThemeOpen(false)} />
      <ChatWidget />
    </div>
  );
}
