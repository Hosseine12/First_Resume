export function UiDemo() {
  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" type="button">اصلی</button>
        <button className="btn btn-ghost" type="button">حاشیه</button>
        <button className="btn btn-soft" type="button">نرم</button>
      </div>
      <input className="field max-w-md" placeholder="نمونه فیلد" />
      <div className="grid sm:grid-cols-3 gap-3">
        {["کارت یک", "کارت دو", "کارت سه"].map((t) => (
          <div key={t} className="surface rounded-[var(--radius-md)] p-4">
            <h3 className="font-medium">{t}</h3>
            <p className="text-sm text-muted mt-1">شعاع تو در تو، فاصلهٔ منظم، بدون شلوغی.</p>
          </div>
        ))}
      </div>
    </div>
  );
}
