import { useState } from "react";

const SEED = [
  { id: 1, title: "راهنمای RTL", status: "منتشر" },
  { id: 2, title: "چک‌لیست سئو", status: "پیش‌نویس" },
  { id: 3, title: "امنیت فرم", status: "منتشر" },
];

export function CmsDemo() {
  const [rows, setRows] = useState(SEED);
  const [title, setTitle] = useState("");
  return (
    <div className="surface rounded-[var(--radius-lg)] overflow-hidden">
      <div className="px-5 py-4 border-b border-line font-medium">پنل محتوا — نسخهٔ نمایشی</div>
      <form
        className="p-5 flex flex-wrap gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!title.trim()) return;
          setRows((r) => [{ id: Date.now(), title: title.trim(), status: "پیش‌نویس" }, ...r]);
          setTitle("");
        }}
      >
        <input className="field flex-1 min-w-[180px]" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان نوشته" />
        <button className="btn btn-primary" type="submit">
          پیش‌نویس جدید
        </button>
      </form>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-muted">
            <tr>
              <th className="text-start p-3">عنوان</th>
              <th className="text-start p-3">وضعیت</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-line">
                <td className="p-3">{r.title}</td>
                <td className="p-3">{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
