import { useMemo, useState } from "react";
import { money } from "@/lib/utils";

const ITEMS = [
  { id: "1", title: "کاسهٔ سفالی", price: 320000 },
  { id: "2", title: "رومیزی کتان", price: 540000 },
  { id: "3", title: "آینهٔ برنجی", price: 890000 },
  { id: "4", title: "شمع گیاهی", price: 120000 },
];

export function AzarinDemo() {
  const [cart, setCart] = useState<Record<string, number>>({});
  const lines = useMemo(
    () => ITEMS.filter((i) => cart[i.id]).map((i) => ({ ...i, qty: cart[i.id] })),
    [cart],
  );
  const total = lines.reduce((s, l) => s + l.price * l.qty, 0);
  return (
    <div className="surface rounded-[var(--radius-lg)] overflow-hidden">
      <div className="px-5 py-4 border-b border-line flex items-center justify-between bg-[color-mix(in_oklab,var(--brand)_10%,var(--surface))]">
        <strong>آذین</strong>
        <span className="text-sm text-muted">سبد نمایشی {money(total)}</span>
      </div>
      <div className="grid sm:grid-cols-2 gap-4 p-5">
        {ITEMS.map((i) => (
          <article key={i.id} className="border border-line rounded-[calc(var(--radius)-4px)] p-4">
            <div className="h-24 rounded-md mb-3" style={{ background: "color-mix(in oklab, var(--brand) 18%, var(--bg))" }} />
            <h3 className="font-medium">{i.title}</h3>
            <p className="text-sm text-brand mt-1">{money(i.price)}</p>
            <button
              type="button"
              className="btn btn-soft mt-3 text-sm"
              onClick={() => setCart((c) => ({ ...c, [i.id]: (c[i.id] ?? 0) + 1 }))}
            >
              افزودن
            </button>
          </article>
        ))}
      </div>
      {lines.length > 0 && (
        <ul className="px-5 pb-5 text-sm text-muted grid gap-1">
          {lines.map((l) => (
            <li key={l.id}>
              {l.title} × {l.qty}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
