import { useState } from "react";

export function ZaferanDemo() {
  const [ok, setOk] = useState(false);
  return (
    <div className="surface rounded-[var(--radius-lg)] overflow-hidden">
      <div className="p-6 bg-[color-mix(in_oklab,var(--accent)_20%,var(--surface))]">
        <p className="kicker">رستوران</p>
        <h2 className="font-display text-4xl mt-1">زعفران</h2>
        <p className="text-muted mt-2">رزرو میز — نمونهٔ رابط، بدون رزرو واقعی.</p>
      </div>
      {ok ? (
        <p className="p-6">درخواست نمایشی ثبت شد. در پروژهٔ واقعی به تقویم شعب وصل می‌شود.</p>
      ) : (
        <form
          className="p-6 grid gap-3 max-w-md"
          onSubmit={(e) => {
            e.preventDefault();
            setOk(true);
          }}
        >
          <input className="field" required placeholder="نام" />
          <input className="field" required placeholder="تعداد نفرات" />
          <input className="field" type="date" required />
          <button className="btn btn-primary" type="submit">
            رزرو نمایشی
          </button>
        </form>
      )}
    </div>
  );
}
