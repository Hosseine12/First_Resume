export function ZarvanDemo() {
  const lines = [
    "[21:04:11] scheduler: job scrape.sources queued",
    "[21:04:12] worker: 3 urls fetched, 0 blocked",
    "[21:04:13] parse: 18 records → report.json",
    "[21:04:13] notify: digest written (local)",
  ];
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <pre className="surface rounded-[var(--radius-md)] p-4 text-sm overflow-auto bg-[#101614] text-[#d7efe9] min-h-[240px]" dir="ltr">
        {lines.join("\n")}
      </pre>
      <div className="surface rounded-[var(--radius-md)] p-5">
        <h3 className="font-medium">چرا دموی اجرایی نیست؟</h3>
        <p className="text-sm text-muted mt-2">
          بات روی محیط شما اجرا می‌شود (زمان‌بندی، شبکه، کلیدها). اینجا فقط نمای لاگ است. بعد از خرید، فایل اسکلت و README را از پنل می‌گیرید.
        </p>
      </div>
    </div>
  );
}
