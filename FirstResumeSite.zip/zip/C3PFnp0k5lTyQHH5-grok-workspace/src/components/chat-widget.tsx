import { MessageCircle, Send, X } from "lucide-react";
import { useState } from "react";
import { askAssistant } from "@/lib/server/ai";
import { track } from "@/lib/analytics";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", content: "سلام، زرین هستم. دربارهٔ محصولات، سبد یا پروژه‌ها بپرس." },
  ]);

  async function send() {
    const q = text.trim();
    if (!q || busy) return;
    setText("");
    const history = [...msgs, { role: "user" as const, content: q }];
    setMsgs(history);
    setBusy(true);
    track("chat");
    try {
      const res = await askAssistant({
        data: {
          question: q,
          history: history.slice(0, -1).map((m) => ({ role: m.role, content: m.content })),
        },
      });
      setMsgs((m) => [
        ...m,
        { role: "assistant", content: res.ok ? res.text : res.error },
      ]);
    } catch (e) {
      setMsgs((m) => [...m, { role: "assistant", content: e instanceof Error ? e.message : "خطا" }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        className="fixed bottom-5 left-5 z-40 size-14 rounded-full bg-brand text-white grid place-items-center shadow-lg"
        aria-label="گفتگو"
        onClick={() => setOpen(true)}
      >
        <MessageCircle size={22} />
      </button>
      {open && (
        <div className="fixed bottom-5 left-5 z-50 w-[min(92vw,360px)] h-[min(70dvh,520px)] bg-card border border-line rounded-[calc(var(--radius)+8px)] shadow-lg flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-line">
            <p className="font-medium">زرین</p>
            <button type="button" className="size-11 grid place-items-center" onClick={() => setOpen(false)} aria-label="بستن گفتگو">
              <X size={16} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 grid gap-2 content-start">
            {msgs.map((m, i) => (
              <p
                key={i}
                className={`text-sm leading-6 px-3 py-2 rounded-[calc(var(--radius)-4px)] max-w-[90%] ${m.role === "user" ? "justify-self-start bg-[color-mix(in_oklab,var(--brand)_16%,transparent)]" : "justify-self-end bg-[color-mix(in_oklab,var(--fg)_6%,transparent)]"}`}
              >
                {m.content}
              </p>
            ))}
          </div>
          <form
            className="flex gap-2 p-3 border-t border-line"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <input
              className="field"
              value={text}
              maxLength={500}
              onChange={(e) => setText(e.target.value)}
              placeholder="پیام…"
              aria-label="متن پیام"
            />
            <button type="submit" className="btn btn-primary px-3" disabled={busy} aria-label="ارسال">
              <Send size={16} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
