import { PALETTES, useTheme, type Mode } from "@/lib/theme";
import { X } from "lucide-react";

export function ThemeDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useTheme();
  if (!open) return null;
  const modes: { id: Mode; label: string }[] = [
    { id: "light", label: "روشن" },
    { id: "dark", label: "تاریک" },
    { id: "system", label: "سیستم" },
  ];
  return (
    <div className="fixed inset-0 z-[60]">
      <button className="absolute inset-0 bg-black/40" aria-label="بستن" onClick={onClose} />
      <div className="absolute top-0 bottom-0 start-0 w-[min(92vw,380px)] bg-card border-e border-line p-5 overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-2xl">ظاهر سایت</h2>
          <button type="button" className="size-11 grid place-items-center" onClick={onClose} aria-label="بستن">
            <X size={18} />
          </button>
        </div>
        <p className="text-sm text-muted mb-3">حالت</p>
        <div className="grid grid-cols-3 gap-2 mb-6">
          {modes.map((m) => (
            <button
              key={m.id}
              type="button"
              className={`btn ${t.mode === m.id ? "btn-primary" : "btn-ghost"} text-sm`}
              onClick={() => t.setMode(m.id)}
            >
              {m.label}
            </button>
          ))}
        </div>
        <p className="text-sm text-muted mb-3">پالت</p>
        <div className="grid grid-cols-2 gap-2 mb-6">
          {PALETTES.map((p) => (
            <button
              key={p.id}
              type="button"
              className="btn btn-ghost justify-start gap-2"
              onClick={() => t.setPalette(p.id)}
            >
              <span className="size-4 rounded-full" style={{ background: p.primary }} />
              {p.label}
            </button>
          ))}
        </div>
        <label className="text-sm text-muted grid gap-1 mb-4">
          رنگ اصلی
          <input
            type="color"
            value={t.primary}
            onChange={(e) => t.setCustom({ primary: e.target.value })}
            className="h-11 w-full"
          />
        </label>
        <label className="text-sm text-muted grid gap-1 mb-4">
          رنگ تأکیدی
          <input
            type="color"
            value={t.accent}
            onChange={(e) => t.setCustom({ accent: e.target.value })}
            className="h-11 w-full"
          />
        </label>
        <label className="text-sm text-muted grid gap-1 mb-4">
          گردی گوشه‌ها ({t.radius})
          <input
            type="range"
            min={8}
            max={24}
            value={t.radius}
            onChange={(e) => t.setCustom({ radius: Number(e.target.value) })}
          />
        </label>
        <label className="text-sm text-muted grid gap-1 mb-4">
          اندازه متن
          <input
            type="range"
            min={0.9}
            max={1.15}
            step={0.01}
            value={t.fontScale}
            onChange={(e) => t.setCustom({ fontScale: Number(e.target.value) })}
          />
        </label>
        <label className="flex items-center gap-2 mb-6 text-sm">
          <input type="checkbox" checked={t.gradient} onChange={(e) => t.setCustom({ gradient: e.target.checked })} />
          پس‌زمینهٔ ملایم گرادیان
        </label>
        <button type="button" className="btn btn-ghost w-full" onClick={t.reset}>
          بازگشت به پیش‌فرض
        </button>
      </div>
    </div>
  );
}
