import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { ProductCover } from "./covers";
import type { Product } from "@/lib/catalog";
import { money, faNum } from "@/lib/utils";
import { useCart } from "@/lib/cart";
import { track } from "@/lib/analytics";

export function ProductCard({ product }: { product: Product }) {
  const cart = useCart();
  const low = product.stock > 0 && product.stock <= 5;
  return (
    <article className="surface overflow-hidden rounded-[var(--radius-lg)] flex flex-col">
      <Link to="/shop/$slug" params={{ slug: product.slug }} className="block">
        <ProductCover kind={product.kind} title={product.title} className="w-full h-auto" />
      </Link>
      <div className="p-4 flex-1 flex flex-col gap-2">
        <p className="text-xs text-muted">{product.kindLabel}</p>
        <h3 className="text-lg font-medium">
          <Link to="/shop/$slug" params={{ slug: product.slug }}>
            {product.title}
          </Link>
        </h3>
        <p className="text-sm text-muted flex-1">{product.summary}</p>
        <p className="font-display text-xl text-brand">{money(product.price)}</p>
        <p className={`text-xs ${product.stock < 1 ? "text-red-700" : low ? "text-amber-800" : "text-muted"}`}>
          {product.stock < 1 ? "ناموجود" : low ? `فقط ${faNum(product.stock)} عدد` : `موجودی ${faNum(product.stock)}`}
        </p>
        <div className="flex flex-wrap gap-2 pt-2">
          {product.preview && (
            <Link to="/preview/$slug" params={{ slug: product.slug }} className="btn btn-ghost text-sm">
              پیش‌نمایش
            </Link>
          )}
          <button
            type="button"
            className="btn btn-primary text-sm"
            disabled={product.stock < 1}
            onClick={() => {
              const r = cart.add(product.id);
              track("add_cart");
              toast(r.message);
            }}
          >
            افزودن به سبد
          </button>
        </div>
      </div>
    </article>
  );
}
