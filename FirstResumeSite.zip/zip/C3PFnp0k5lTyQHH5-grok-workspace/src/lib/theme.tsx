import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export const PALETTES = [
  { id: "teal", label: "فیروزه", primary: "#0c7f70", accent: "#c4a574" },
  { id: "ink", label: "مرکب", primary: "#1f4e5f", accent: "#8aa4a1" },
  { id: "forest", label: "جنگل", primary: "#2f5d50", accent: "#b08968" },
  { id: "slate", label: "سنگ", primary: "#3d5a5b", accent: "#9aa7a6" },
] as const;

export type Mode = "light" | "dark" | "system";

export type ThemeState = {
  mode: Mode;
  paletteId: string;
  primary: string;
  accent: string;
  radius: number;
  fontScale: number;
  gradient: boolean;
};

const DEFAULT: ThemeState = {
  mode: "system",
  paletteId: "teal",
  primary: "#0c7f70",
  accent: "#c4a574",
  radius: 14,
  fontScale: 1,
  gradient: false,
};

const KEY = "gd-theme-v1";

type Ctx = ThemeState & {
  setMode: (m: Mode) => void;
  setPalette: (id: string) => void;
  setCustom: (partial: Partial<ThemeState>) => void;
  reset: () => void;
};

const ThemeCtx = createContext<Ctx | null>(null);

function readStored(): ThemeState {
  if (typeof window === "undefined") return DEFAULT;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT;
    return { ...DEFAULT, ...JSON.parse(raw) };
  } catch {
    return DEFAULT;
  }
}

function apply(s: ThemeState) {
  const root = document.documentElement;
  const sysDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const dark = s.mode === "dark" || (s.mode === "system" && sysDark);
  root.dataset.theme = dark ? "dark" : "light";
  root.style.setProperty("--brand", s.primary);
  root.style.setProperty("--accent", s.accent);
  root.style.setProperty("--radius", `${s.radius}px`);
  root.style.setProperty("--font-scale", String(s.fontScale));
  root.dataset.gradient = s.gradient ? "on" : "off";
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<ThemeState>(DEFAULT);

  useEffect(() => {
    const s = readStored();
    setState(s);
    apply(s);
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const on = () => apply(readStored());
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);

  const commit = useCallback((next: ThemeState) => {
    setState(next);
    localStorage.setItem(KEY, JSON.stringify(next));
    apply(next);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      ...state,
      setMode: (mode) => commit({ ...state, mode }),
      setPalette: (id) => {
        const p = PALETTES.find((x) => x.id === id) ?? PALETTES[0];
        commit({ ...state, paletteId: p.id, primary: p.primary, accent: p.accent });
      },
      setCustom: (partial) => commit({ ...state, ...partial, paletteId: "custom" }),
      reset: () => commit(DEFAULT),
    }),
    [state, commit],
  );

  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error("useTheme");
  return ctx;
}
