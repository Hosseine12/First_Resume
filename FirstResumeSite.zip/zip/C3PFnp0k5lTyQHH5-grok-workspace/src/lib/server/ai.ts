import { createServerFn } from "@tanstack/react-start";
import { PRODUCTS, TOPICS, BRAND } from "@/lib/catalog";

const buckets = new Map<string, { n: number; t: number }>();

function limited(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || now - b.t > windowMs) {
    buckets.set(key, { n: 1, t: now });
    return false;
  }
  if (b.n >= max) return true;
  b.n += 1;
  return false;
}

const knowledge = [
  `برند: ${BRAND.fa} (${BRAND.name}) — ${BRAND.owner}.`,
  "محصولات:",
  ...PRODUCTS.map(
    (p) => `- ${p.title} | ${p.price} تومان | موجودی ${p.stock} | ${p.summary}`,
  ),
  "مقالات:",
  ...TOPICS.map((t) => `- ${t.title}: ${t.lead}`),
  "پرداخت فعلاً نمایشی است. قیمت سبد فقط از کاتالوگ سرور/کلاینت هم‌خوان خوانده می‌شود نه از DOM.",
].join("\n");

export const askAssistant = createServerFn({ method: "POST" })
  .validator((input: { question: string; history?: { role: string; content: string }[] }) => {
    const question = String(input.question ?? "").trim().slice(0, 500);
    if (question.length < 2) throw new Error("پیام خیلی کوتاه است.");
    return {
      question,
      history: (input.history ?? []).slice(-6).map((h) => ({
        role: h.role === "assistant" ? "assistant" : "user",
        content: String(h.content ?? "").slice(0, 400),
      })),
    };
  })
  .handler(async ({ data }) => {
    if (limited("chat", 20, 10 * 60 * 1000)) {
      return { ok: false as const, error: "فعلاً زیاد پیام فرستادید. کمی بعد دوباره." };
    }
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: true as const,
        text: "دستیار فعلاً به مدل وصل نیست. از مقالات و صفحهٔ تماس استفاده کنید یا بعداً دوباره سر بزنید.",
      };
    }
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 400,
        messages: [
          {
            role: "system",
            content:
              `تو زرین، دستیار ${BRAND.fa} هستی. فارسی، کوتاه، دقیق. حدس نزن. اگر نمی‌دانی بگو به پشتیبانی انسانی وصل شود. دانش:\n${knowledge}`,
          },
          ...data.history,
          { role: "user", content: data.question },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: "پاسخ مدل الان در دسترس نیست." };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { ok: true as const, text: body.choices?.[0]?.message?.content ?? "پاسخی نبود." };
  });

export const draftSeo = createServerFn({ method: "POST" })
  .validator((input: { topic: string; notes: string; competitor?: string }) => {
    const topic = String(input.topic ?? "").trim().slice(0, 120);
    const notes = String(input.notes ?? "").trim().slice(0, 1500);
    const competitor = String(input.competitor ?? "").trim().slice(0, 1500);
    if (topic.length < 3) throw new Error("موضوع را بنویسید.");
    return { topic, notes, competitor };
  })
  .handler(async ({ data }) => {
    if (limited("seo", 8, 30 * 60 * 1000)) {
      return { ok: false as const, error: "سقف پیش‌نویس این بازه پر شده." };
    }
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "مدل در این محیط فعال نیست." };
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 900,
        messages: [
          {
            role: "system",
            content:
              "ویراستار سئوی فارسی هستی. خروجی باید اصیل باشد، کپی از رقبا ممنوع، ساختار: عنوان، توضیح متا، طرح کلی، متن، نکات داخلی‌لینک. اگر متن رقیب داده شد فقط الگو بگیر نه جمله.",
          },
          {
            role: "user",
            content: `موضوع: ${data.topic}\nیادداشت: ${data.notes}\nنمونه رقیب (اختیاری):\n${data.competitor || "—"}`,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: "خطا در تولید پیش‌نویس." };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { ok: true as const, text: body.choices?.[0]?.message?.content ?? "" };
  });

export const sendContact = createServerFn({ method: "POST" })
  .validator((input: { name: string; email: string; subject: string; body: string }) => {
    const name = String(input.name ?? "").trim().slice(0, 80);
    const email = String(input.email ?? "").trim().slice(0, 120);
    const subject = String(input.subject ?? "").trim().slice(0, 120);
    const body = String(input.body ?? "").trim().slice(0, 2000);
    if (name.length < 2 || !email.includes("@") || subject.length < 2 || body.length < 8) {
      throw new Error("فرم را کامل و معتبر پر کنید.");
    }
    return { name, email, subject, body };
  })
  .handler(async ({ data }) => {
    if (limited("contact:" + data.email, 3, 30 * 60 * 1000)) {
      return { ok: false as const, error: "پیام‌های این ایمیل موقتاً محدود شد." };
    }
    return { ok: true as const };
  });
