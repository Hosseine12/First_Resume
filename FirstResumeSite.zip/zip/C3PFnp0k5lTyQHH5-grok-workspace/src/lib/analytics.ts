export type Event = { t: number; path: string; name: string };

const KEY = "gd-analytics-v1";
const MAX = 400;

export function track(name: string, path = typeof window !== "undefined" ? window.location.pathname : "/") {
  try {
    const prev: Event[] = JSON.parse(localStorage.getItem(KEY) || "[]");
    prev.push({ t: Date.now(), path, name });
    localStorage.setItem(KEY, JSON.stringify(prev.slice(-MAX)));
  } catch {
    /* ignore */
  }
}

export function readEvents(): Event[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function summarize(events: Event[]) {
  const byPath = new Map<string, number>();
  const byName = new Map<string, number>();
  for (const e of events) {
    byPath.set(e.path, (byPath.get(e.path) ?? 0) + 1);
    byName.set(e.name, (byName.get(e.name) ?? 0) + 1);
  }
  return {
    total: events.length,
    paths: [...byPath.entries()].sort((a, b) => b[1] - a[1]),
    names: [...byName.entries()].sort((a, b) => b[1] - a[1]),
  };
}
