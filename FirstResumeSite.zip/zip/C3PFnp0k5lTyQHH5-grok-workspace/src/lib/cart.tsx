import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { productById, PRODUCTS, type Product } from "./catalog";

type CartMap = Record<string, number>;

type Line = { product: Product; qty: number; line: number };

type Order = {
  ref: string;
  at: string;
  total: number;
  items: { id: string; title: string; qty: number; price: number }[];
  name: string;
  phone: string;
  address: string;
};

type Ctx = {
  lines: Line[];
  count: number;
  total: number;
  add: (id: string) => { ok: boolean; message: string };
  setQty: (id: string, qty: number) => { ok: boolean; message: string };
  remove: (id: string) => void;
  clear: () => void;
  orders: Order[];
  place: (info: { name: string; phone: string; address: string }) => {
    ok: boolean;
    message: string;
    ref?: string;
  };
  owned: Set<string>;
};

const CART_KEY = "gd-cart-v1";
const ORDER_KEY = "gd-orders-v1";
const CartCtx = createContext<Ctx | null>(null);

function load<T>(k: string, fallback: T): T {
  try {
    const r = localStorage.getItem(k);
    return r ? (JSON.parse(r) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [map, setMap] = useState<CartMap>({});
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    setMap(load(CART_KEY, {}));
    setOrders(load(ORDER_KEY, []));
  }, []);

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(map));
  }, [map]);
  useEffect(() => {
    localStorage.setItem(ORDER_KEY, JSON.stringify(orders));
  }, [orders]);

  const lines = useMemo<Line[]>(() => {
    return Object.entries(map)
      .map(([id, qty]) => {
        const product = productById(id);
        if (!product || qty < 1) return null;
        return { product, qty, line: product.price * qty };
      })
      .filter(Boolean) as Line[];
  }, [map]);

  const add = useCallback((id: string) => {
    const p = productById(id);
    if (!p) return { ok: false, message: "محصول معتبر نیست." };
    if (p.stock < 1) return { ok: false, message: "ناموجود است." };
    setMap((m) => {
      const next = Math.min((m[id] ?? 0) + 1, p.stock);
      return { ...m, [id]: next };
    });
    return { ok: true, message: "به سبد اضافه شد." };
  }, []);

  const setQty = useCallback((id: string, qty: number) => {
    const p = productById(id);
    if (!p) return { ok: false, message: "محصول معتبر نیست." };
    if (qty < 1) {
      setMap((m) => {
        const n = { ...m };
        delete n[id];
        return n;
      });
      return { ok: true, message: "حذف شد." };
    }
    if (qty > p.stock) return { ok: false, message: `فقط ${p.stock} عدد موجود است.` };
    setMap((m) => ({ ...m, [id]: qty }));
    return { ok: true, message: "به‌روز شد." };
  }, []);

  const remove = useCallback((id: string) => {
    setMap((m) => {
      const n = { ...m };
      delete n[id];
      return n;
    });
  }, []);

  const clear = useCallback(() => setMap({}), []);

  const place = useCallback(
    (info: { name: string; phone: string; address: string }) => {
      const current = Object.entries(map)
        .map(([id, qty]) => {
          const product = productById(id);
          return product ? { product, qty } : null;
        })
        .filter(Boolean) as { product: Product; qty: number }[];
      if (!current.length) return { ok: false, message: "سبد خالی است." };
      for (const l of current) {
        if (l.qty > l.product.stock) {
          return { ok: false, message: `موجودی «${l.product.title}» کافی نیست.` };
        }
      }
      const total = current.reduce((s, l) => s + l.product.price * l.qty, 0);
      const ref = "GD" + Math.random().toString(36).slice(2, 8).toUpperCase();
      const order: Order = {
        ref,
        at: new Date().toISOString(),
        total,
        name: info.name,
        phone: info.phone,
        address: info.address,
        items: current.map((l) => ({
          id: l.product.id,
          title: l.product.title,
          qty: l.qty,
          price: l.product.price,
        })),
      };
      setOrders((o) => [order, ...o]);
      setMap({});
      return { ok: true, message: "سفارش ثبت شد (پرداخت نمایشی).", ref };
    },
    [map],
  );

  const owned = useMemo(() => {
    const s = new Set<string>();
    for (const o of orders) for (const i of o.items) s.add(i.id);
    return s;
  }, [orders]);

  const value = useMemo<Ctx>(
    () => ({
      lines,
      count: lines.reduce((s, l) => s + l.qty, 0),
      total: lines.reduce((s, l) => s + l.line, 0),
      add,
      setQty,
      remove,
      clear,
      orders,
      place,
      owned,
    }),
    [lines, add, setQty, remove, clear, orders, place, owned],
  );

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const c = useContext(CartCtx);
  if (!c) throw new Error("useCart");
  return c;
}

export function catalogFingerprint() {
  return PRODUCTS.map((p) => `${p.id}:${p.price}:${p.stock}`).join("|");
}
