import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="min-h-dvh grid place-items-center p-8 text-center">
      <div>
        <h1 className="font-display text-4xl">صفحه پیدا نشد</h1>
        <p className="mt-2 text-sm opacity-70">نشانی اشتباه است یا جابه‌جا شده.</p>
        <a href="/" className="inline-block mt-4 underline">
          خانه
        </a>
      </div>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}
