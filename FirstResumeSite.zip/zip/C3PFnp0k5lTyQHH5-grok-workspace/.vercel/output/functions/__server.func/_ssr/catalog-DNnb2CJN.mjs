//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DNnb2CJN.js
var BRAND = {
	name: "GoldenDevs",
	fa: "گلدن‌دِوز",
	owner: "حسین امیان",
	slogan: "توسعه‌دهندگان طلایی",
	email: "hello@goldendevs.ir",
	phone: "۰۹۱۲۱۲۳۴۵۶۷"
};
var PRODUCTS = [
	{
		id: "p-azarin",
		slug: "azarin",
		title: "قالب فروشگاهی آذین",
		kind: "template",
		kindLabel: "قالب HTML/CSS/JS",
		price: 89e4,
		stock: 12,
		summary: "قالب فروشگاهی راست‌چین، آمادهٔ سفارشی‌سازی، با سبد و فیلتر محصول.",
		description: "آذین یک قالب فروشگاهی خالص (HTML، CSS، JS) است؛ بدون وردپرس. مناسب فروش صنایع‌دستی، پوشاک و برندهای کوچک. شامل صفحهٔ خانه، فهرست محصول، جزئیات، سبد و تسویهٔ نمایشی. کد تمیز، RTL کامل و قابل اتصال به هر بک‌اند.",
		stack: [
			"HTML",
			"CSS",
			"JS",
			"RTL"
		],
		preview: "/preview/azarin",
		galleryHint: "پیش‌نمایش زنده داخل سایت، نه لینک خارجی.",
		downloadable: true,
		demoLive: true
	},
	{
		id: "p-cms",
		slug: "lite-cms",
		title: "اسکریپت مدیریت محتوای سبک",
		kind: "script",
		kindLabel: "اسکریپت PHP",
		price: 145e4,
		stock: 7,
		summary: "پنل سبک برای صفحات و مقالات؛ بدون فریم‌ورک سنگین.",
		description: "یک CMS جمع‌وجور برای سایت‌های محتوایی. مدیریت نوشته، پیش‌نویس، برچسب و رسانه. مناسب کسی که PHP می‌خواهد ولی Laravel برایش زیاد است. پیش‌نمایش زندهٔ پنل را همین‌جا ببینید.",
		stack: [
			"PHP",
			"MySQL",
			"RTL"
		],
		preview: "/preview/lite-cms",
		galleryHint: "داشبورد تعاملی نمونه.",
		downloadable: true,
		demoLive: true
	},
	{
		id: "p-turquoise",
		slug: "turquoise-ui",
		title: "کیت رابط کاربری فیروزه",
		kind: "uikit",
		kindLabel: "کیت UI",
		price: 65e4,
		stock: 20,
		summary: "کامپوننت‌های آماده با توکن رنگی، فاصله و شعاع هم‌مرکز.",
		description: "دکمه‌ها، فیلدها، کارت، تب، نشان و مودال با قرارداد طراحی گلدن‌دِوز. خروجی HTML/CSS و راهنمای توکن. مناسب فرانت‌اندکارهایی که نمی‌خواهند از صفر شروع کنند.",
		stack: [
			"HTML",
			"CSS",
			"Design tokens"
		],
		preview: "/preview/turquoise",
		galleryHint: "گالری زندهٔ کامپوننت‌ها.",
		downloadable: true,
		demoLive: true
	},
	{
		id: "p-zarvan",
		slug: "zarvan-bot",
		title: "بات اتوماسیون زرون",
		kind: "bot",
		kindLabel: "اتوماسیون پایتون",
		price: 21e5,
		stock: 5,
		summary: "اسکلت بات زمان‌بندی‌شده برای جمع‌آوری و گزارش. دموی تعاملی ندارد.",
		description: "زرون یک اسکلت پایتونی برای زمان‌بندی کار، لاگ ساخت‌یافته و خروجی JSON است. به‌خاطر ماهیت اتوماسیون، پیش‌نمایش زنده ارائه نمی‌شود؛ چند نما از محیط اجرا را می‌بینید. اسکریپت نهایی را خودتان روی سرور یا لوکال اجرا می‌کنید.",
		stack: [
			"Python",
			"Cron",
			"JSON"
		],
		preview: "/preview/zarvan",
		galleryHint: "فقط نمای محیط؛ بدون دموی اجرایی.",
		downloadable: true,
		demoLive: false
	}
];
var PROJECTS = [
	{
		slug: "zaferan",
		title: "سامانهٔ رزرو رستوران زعفران",
		year: "۱۴۰۲",
		tags: ["وب‌سایت", "UI"],
		desc: "رزرو میز، منوی دیجیتال و پنل شعب با تقویم جلالی.",
		preview: "/preview/zaferan"
	},
	{
		slug: "negah",
		title: "فروشگاه صنایع‌دستی نگاه",
		year: "۱۴۰۳",
		tags: ["فروشگاه", "RTL"],
		desc: "فروش آنلاین با فیلتر موجودی و تسویهٔ چندمرحله‌ای.",
		preview: "/preview/azarin"
	},
	{
		slug: "rayan",
		title: "داشبورد تحلیلی رایان",
		year: "۱۴۰۳",
		tags: ["اپلیکیشن", "داده"],
		desc: "نمودار فروش، قیف تبدیل و گزارش روزانه برای تیم کوچک.",
		preview: "/preview/lite-cms"
	}
];
var TOPICS = [
	{
		slug: "html5",
		title: "HTML5 معنایی",
		lead: "ساختار درست، دسترس‌پذیری و پایهٔ سئوی فنی.",
		body: "تگ‌های معنایی (header، main، article) به موتور جستجو و صفحه‌خوان کمک می‌کنند. هر صفحه باید یک h1 داشته باشد، تصاویر alt واقعی، و فرم‌ها label مرتبط. از div به‌عنوان آخرین راه استفاده کنید نه اولین."
	},
	{
		slug: "css-rtl",
		title: "CSS راست‌چین",
		lead: "منطقی بنویسید، نه فیزیکی.",
		body: "margin-inline-start به‌جای margin-left در RTL و LTR درست کار می‌کند. inset-inline و padding-inline را پیش‌فرض کنید. فلکس با direction از سند ارث می‌برد؛ ترجمهٔ X را با منطق جهت تست کنید."
	},
	{
		slug: "php-secure",
		title: "امنیت PHP",
		lead: "CSRF، XSS، تزریق SQL و هدرها.",
		body: "خروجی را escape کنید، کوئری را پارامتری، رمز را با password_hash، نشست را HttpOnly و SameSite. قیمت و موجودی را هرگز از کلاینت نپذیرید. CSP با nonce بهتر از unsafe-inline است."
	},
	{
		slug: "seo-fa",
		title: "سئوی محتوای فارسی",
		lead: "نیت جستجو، ساختار و اصالت.",
		body: "یک موضوع، یک صفحه. عنوان یکتا، توضیحات یکتا، دادهٔ ساخت‌یافته، لینک داخلی. بازنویسی رقیب با تغییر چند کلمه کپی است؛ زاویهٔ تازه و مثال واقعی ارزش می‌سازد."
	},
	{
		slug: "perf",
		title: "عملکرد وب",
		lead: "فونت محلی، تصویر محلی، CSS کم.",
		body: "فونت را خودمیزبان کنید، تصویر را با ابعاد مشخص و lazy، JS را تقسیم کنید. LCP معمولاً هیرو یا فونت است. از تصاویر CDN ناشناس برای سئو و حریم خصوصی پرهیز کنید."
	},
	{
		slug: "checkout",
		title: "سبد امن",
		lead: "موجودی و قیمت فقط سمت سرور.",
		body: "شناسهٔ محصول را از کلاینت بگیرید، قیمت را از کاتالوگ. با تراکنش از فروش بیش از موجودی جلوگیری کنید. Inspect نمی‌تواند قیمت را عوض کند اگر تسویه به کاتالوگ اعتماد کند."
	}
];
function productBySlug(slug) {
	return PRODUCTS.find((p) => p.slug === slug);
}
function productById(id) {
	return PRODUCTS.find((p) => p.id === id);
}
function searchCatalog(q) {
	const n = q.trim().toLowerCase();
	if (!n) return {
		products: PRODUCTS,
		projects: PROJECTS,
		topics: TOPICS
	};
	const hit = (s) => s.toLowerCase().includes(n);
	return {
		products: PRODUCTS.filter((p) => hit(p.title) || hit(p.summary) || p.stack.some(hit)),
		projects: PROJECTS.filter((p) => hit(p.title) || hit(p.desc)),
		topics: TOPICS.filter((t) => hit(t.title) || hit(t.lead) || hit(t.body))
	};
}
//#endregion
export { productById as a, TOPICS as i, PRODUCTS as n, productBySlug as o, PROJECTS as r, searchCatalog as s, BRAND as t };
