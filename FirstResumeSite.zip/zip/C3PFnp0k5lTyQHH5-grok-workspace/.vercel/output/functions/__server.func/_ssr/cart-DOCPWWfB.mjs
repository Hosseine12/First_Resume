import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as useCart } from "./router-C7l28Tgs.mjs";
import { c as money, i as SiteShell, s as faNum } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cart-DOCPWWfB.js
var import_jsx_runtime = require_jsx_runtime();
function Cart() {
	const cart = useCart();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "سبد خرید"
			}),
			cart.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-muted",
				children: "سبد خالی است."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid gap-3",
				children: cart.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "surface rounded-[var(--radius-md)] p-4 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: l.product.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: money(l.product.price)
						}),
						l.product.stock <= 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs mt-1",
							children: [
								"فقط ",
								faNum(l.product.stock),
								" در انبار"
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => cart.setQty(l.product.id, l.qty - 1),
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faNum(l.qty) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								disabled: l.qty >= l.product.stock,
								onClick: () => cart.setQty(l.product.id, l.qty + 1),
								children: "+"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => cart.remove(l.product.id),
								children: "حذف"
							})
						]
					})]
				}, l.product.id))
			}),
			cart.lines.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: money(cart.total)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/checkout",
					className: "btn btn-primary",
					children: "تسویه"
				})]
			})
		]
	}) });
}
//#endregion
export { Cart as component };
