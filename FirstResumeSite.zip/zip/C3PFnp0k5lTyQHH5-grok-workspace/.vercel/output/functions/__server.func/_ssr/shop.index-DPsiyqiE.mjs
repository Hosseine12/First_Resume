import { n as PRODUCTS } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCard } from "./product-card-B7yz6a2e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop.index-DPsiyqiE.js
var import_jsx_runtime = require_jsx_runtime();
function Shop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "خانه / فروشگاه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: "فروشگاه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted mt-2 max-w-prose",
				children: "پیش‌نمایش‌ها داخل همین سایت اجرا می‌شوند. قیمت از کاتالوگ خوانده می‌شود، نه از DOM."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 mt-8",
				children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			})
		]
	}) });
}
//#endregion
export { Shop as component };
