import { o as __toESM } from "../_runtime.mjs";
import { o as productBySlug } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, W as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Route$5 } from "./router-C7l28Tgs.mjs";
import { c as money, i as SiteShell } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview._slug-BbLf-ekH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ITEMS = [
	{
		id: "1",
		title: "کاسهٔ سفالی",
		price: 32e4
	},
	{
		id: "2",
		title: "رومیزی کتان",
		price: 54e4
	},
	{
		id: "3",
		title: "آینهٔ برنجی",
		price: 89e4
	},
	{
		id: "4",
		title: "شمع گیاهی",
		price: 12e4
	}
];
function AzarinDemo() {
	const [cart, setCart] = (0, import_react.useState)({});
	const lines = (0, import_react.useMemo)(() => ITEMS.filter((i) => cart[i.id]).map((i) => ({
		...i,
		qty: cart[i.id]
	})), [cart]);
	const total = lines.reduce((s, l) => s + l.price * l.qty, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface rounded-[var(--radius-lg)] overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-4 border-b border-line flex items-center justify-between bg-[color-mix(in_oklab,var(--brand)_10%,var(--surface))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "آذین" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-muted",
					children: ["سبد نمایشی ", money(total)]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 gap-4 p-5",
				children: ITEMS.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "border border-line rounded-[calc(var(--radius)-4px)] p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-24 rounded-md mb-3",
							style: { background: "color-mix(in oklab, var(--brand) 18%, var(--bg))" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: i.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-brand mt-1",
							children: money(i.price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-soft mt-3 text-sm",
							onClick: () => setCart((c) => ({
								...c,
								[i.id]: (c[i.id] ?? 0) + 1
							})),
							children: "افزودن"
						})
					]
				}, i.id))
			}),
			lines.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "px-5 pb-5 text-sm text-muted grid gap-1",
				children: lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					l.title,
					" × ",
					l.qty
				] }, l.id))
			})
		]
	});
}
var SEED = [
	{
		id: 1,
		title: "راهنمای RTL",
		status: "منتشر"
	},
	{
		id: 2,
		title: "چک‌لیست سئو",
		status: "پیش‌نویس"
	},
	{
		id: 3,
		title: "امنیت فرم",
		status: "منتشر"
	}
];
function CmsDemo() {
	const [rows, setRows] = (0, import_react.useState)(SEED);
	const [title, setTitle] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface rounded-[var(--radius-lg)] overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-5 py-4 border-b border-line font-medium",
				children: "پنل محتوا — نسخهٔ نمایشی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "p-5 flex flex-wrap gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!title.trim()) return;
					setRows((r) => [{
						id: Date.now(),
						title: title.trim(),
						status: "پیش‌نویس"
					}, ...r]);
					setTitle("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field flex-1 min-w-[180px]",
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "عنوان نوشته"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary",
					type: "submit",
					children: "پیش‌نویس جدید"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-start p-3",
							children: "عنوان"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-start p-3",
							children: "وضعیت"
						})] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3",
							children: r.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-3",
							children: r.status
						})]
					}, r.id)) })]
				})
			})
		]
	});
}
function UiDemo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "button",
						children: "اصلی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-ghost",
						type: "button",
						children: "حاشیه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-soft",
						type: "button",
						children: "نرم"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field max-w-md",
				placeholder: "نمونه فیلد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-3 gap-3",
				children: [
					"کارت یک",
					"کارت دو",
					"کارت سه"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface rounded-[var(--radius-md)] p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mt-1",
						children: "شعاع تو در تو، فاصلهٔ منظم، بدون شلوغی."
					})]
				}, t))
			})
		]
	});
}
function ZarvanDemo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "surface rounded-[var(--radius-md)] p-4 text-sm overflow-auto bg-[#101614] text-[#d7efe9] min-h-[240px]",
			dir: "ltr",
			children: [
				"[21:04:11] scheduler: job scrape.sources queued",
				"[21:04:12] worker: 3 urls fetched, 0 blocked",
				"[21:04:13] parse: 18 records → report.json",
				"[21:04:13] notify: digest written (local)"
			].join("\n")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface rounded-[var(--radius-md)] p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-medium",
				children: "چرا دموی اجرایی نیست؟"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted mt-2",
				children: "بات روی محیط شما اجرا می‌شود (زمان‌بندی، شبکه، کلیدها). اینجا فقط نمای لاگ است. بعد از خرید، فایل اسکلت و README را از پنل می‌گیرید."
			})]
		})]
	});
}
function ZaferanDemo() {
	const [ok, setOk] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface rounded-[var(--radius-lg)] overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 bg-[color-mix(in_oklab,var(--accent)_20%,var(--surface))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "رستوران"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl mt-1",
					children: "زعفران"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted mt-2",
					children: "رزرو میز — نمونهٔ رابط، بدون رزرو واقعی."
				})
			]
		}), ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-6",
			children: "درخواست نمایشی ثبت شد. در پروژهٔ واقعی به تقویم شعب وصل می‌شود."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "p-6 grid gap-3 max-w-md",
			onSubmit: (e) => {
				e.preventDefault();
				setOk(true);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					required: true,
					placeholder: "نام"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					required: true,
					placeholder: "تعداد نفرات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					type: "date",
					required: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary",
					type: "submit",
					children: "رزرو نمایشی"
				})
			]
		})]
	});
}
function Preview() {
	const { slug } = Route$5.useParams();
	const product = productBySlug(slug);
	const title = slug === "zaferan" ? "رستوران زعفران" : product?.title ?? "پیش‌نمایش";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "پیش‌نمایش محدود — دادهٔ نمایشی، بدون دسترسی به سورس واقعی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 mt-2 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: title
				}), product && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop/$slug",
					params: { slug: product.slug },
					className: "btn btn-ghost",
					children: "صفحهٔ محصول"
				})]
			}),
			slug === "azarin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AzarinDemo, {}),
			slug === "lite-cms" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CmsDemo, {}),
			slug === "turquoise-ui" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UiDemo, {}),
			slug === "zarvan-bot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZarvanDemo, {}),
			slug === "zaferan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZaferanDemo, {}),
			![
				"azarin",
				"lite-cms",
				"turquoise-ui",
				"zarvan-bot",
				"zaferan"
			].includes(slug) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "برای این مورد پیش‌نمایشی نیست." })
		]
	}) });
}
//#endregion
export { Preview as component };
