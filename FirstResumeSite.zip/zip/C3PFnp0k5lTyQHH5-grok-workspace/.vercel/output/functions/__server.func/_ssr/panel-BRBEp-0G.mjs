import { o as __toESM } from "../_runtime.mjs";
import { a as productById } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, W as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as useCart } from "./router-C7l28Tgs.mjs";
import { c as money, f as summarize, i as SiteShell, l as readEvents, m as useCurrentUser, n as SignedIn, o as draftSeo, r as SignedOut, t as RedirectToSignIn } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel-BRBEp-0G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Panel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelInner, {}) })] });
}
function PanelInner() {
	const user = useCurrentUser();
	const cart = useCart();
	const stats = (0, import_react.useMemo)(() => summarize(readEvents()), []);
	const [seo, setSeo] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	function download(id) {
		const p = productById(id);
		if (!p || !cart.owned.has(id)) return;
		const blob = new Blob([`${p.title}\nGoldenDevs license (demo)\nخریدار: ${user?.primaryEmail ?? ""}\nاین فایل نمایشی است؛ سورس کامل پس از تحویل واقعی ارسال می‌شود.\n`], { type: "text/plain;charset=utf-8" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `${p.slug}-license.txt`;
		a.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10 grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "پنل کاربری"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted mt-1",
				children: user?.displayName ?? user?.primaryEmail
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface rounded-[var(--radius-lg)] p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium mb-3",
					children: "سفارش‌ها"
				}), cart.orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "سفارشی نیست."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-3",
					children: cart.orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-line pb-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: o.ref
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: money(o.total)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2 mt-2",
								children: o.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "btn btn-soft text-sm",
									onClick: () => download(i.id),
									children: ["دانلود نمایشی ", i.title]
								}, i.id))
							})
						]
					}, o.ref))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface rounded-[var(--radius-lg)] p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium mb-3",
						children: "فعالیت این مرورگر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: ["مجموع رویداد: ", stats.total]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 text-sm grid gap-1",
						children: stats.paths.slice(0, 8).map(([p, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							p,
							" — ",
							n
						] }, p))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "surface rounded-[var(--radius-lg)] p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium mb-2",
						children: "دستیار محتوا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mb-3",
						children: "موضوع بدهید؛ پیش‌نویس اصیل با نکات سئو. متن رقیب اختیاری است و کپی نمی‌شود."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "grid gap-2",
						onSubmit: async (e) => {
							e.preventDefault();
							const fd = new FormData(e.currentTarget);
							setBusy(true);
							setSeo("");
							try {
								const r = await draftSeo({ data: {
									topic: String(fd.get("topic") ?? ""),
									notes: String(fd.get("notes") ?? ""),
									competitor: String(fd.get("competitor") ?? "")
								} });
								setSeo(r.ok ? r.text : r.error);
							} catch (ex) {
								setSeo(ex instanceof Error ? ex.message : "خطا");
							} finally {
								setBusy(false);
							}
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								name: "topic",
								required: true,
								placeholder: "موضوع مقاله"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field min-h-20",
								name: "notes",
								placeholder: "زاویه یا نکات خودتان"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field min-h-20",
								name: "competitor",
								placeholder: "خلاصهٔ رقیب (اختیاری)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: busy,
								children: "پیش‌نویس"
							})
						]
					}),
					seo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 text-sm whitespace-pre-wrap font-sans",
						children: seo
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				className: "btn btn-ghost w-fit",
				children: "ادامهٔ خرید"
			})
		]
	});
}
//#endregion
export { Panel as component };
