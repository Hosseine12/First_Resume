import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { d as useCart } from "./router-C7l28Tgs.mjs";
import { c as money, p as track, s as faNum } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCover } from "./covers-CrfxI3oq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-B7yz6a2e.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	const cart = useCart();
	const low = product.stock > 0 && product.stock <= 5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "surface overflow-hidden rounded-[var(--radius-lg)] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/shop/$slug",
			params: { slug: product.slug },
			className: "block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
				kind: product.kind,
				title: product.title,
				className: "w-full h-auto"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 flex-1 flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: product.kindLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-medium",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop/$slug",
						params: { slug: product.slug },
						children: product.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted flex-1",
					children: product.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl text-brand",
					children: money(product.price)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `text-xs ${product.stock < 1 ? "text-red-700" : low ? "text-amber-800" : "text-muted"}`,
					children: product.stock < 1 ? "ناموجود" : low ? `فقط ${faNum(product.stock)} عدد` : `موجودی ${faNum(product.stock)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 pt-2",
					children: [product.preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/preview/$slug",
						params: { slug: product.slug },
						className: "btn btn-ghost text-sm",
						children: "پیش‌نمایش"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary text-sm",
						disabled: product.stock < 1,
						onClick: () => {
							const r = cart.add(product.id);
							track("add_cart");
							toast(r.message);
						},
						children: "افزودن به سبد"
					})]
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
