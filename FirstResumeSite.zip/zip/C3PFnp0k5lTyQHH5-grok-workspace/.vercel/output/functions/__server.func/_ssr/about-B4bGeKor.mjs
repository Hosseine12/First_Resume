import { t as BRAND } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCover } from "./covers-CrfxI3oq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-B4bGeKor.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10 grid gap-8 lg:grid-cols-[.9fr_1.1fr] items-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
			kind: "desk",
			title: BRAND.owner,
			className: "surface rounded-[var(--radius-lg)]"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "خانه / درباره"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: BRAND.owner
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted max-w-prose",
				children: "جزئیات پروژه برایم مهم است: ظاهر خوانا، امنیت از اول، و تحویل زمان‌بندی‌شده. قالب وردپرس تصادفی در این نسخه نیست؛ محصولات همان چیزهایی‌اند که واقعاً می‌فروشم یا می‌سازم."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 gap-3 mt-6",
				children: [
					["کد تمیز", "ساختار قابل نگهداری"],
					["امنیت اول", "قیمت و موجودی سمت کاتالوگ"],
					["زمان‌بندی", "شفاف از جلسهٔ اول"],
					["یادگیری", "ابزار روز، بدون شلوغی"]
				].map(([t, d]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface rounded-[var(--radius-md)] p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mt-1",
						children: d
					})]
				}, t))
			})
		] })]
	}) });
}
//#endregion
export { About as component };
