import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, W as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as useCart } from "./router-C7l28Tgs.mjs";
import { c as money, i as SiteShell, n as SignedIn, p as track, r as SignedOut } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-BulkAwkF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Checkout() {
	const cart = useCart();
	const [ref, setRef] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10 max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "تسویه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted mt-2",
				children: "پرداخت نمایشی است. مبلغ از کاتالوگ محاسبه می‌شود."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6",
				children: [
					"برای ثبت سفارش",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "text-brand",
						children: "وارد شوید"
					}),
					"."
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: ref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface rounded-[var(--radius-md)] p-5 mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "سفارش ثبت شد." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium mt-2",
						children: ["کد پیگیری: ", ref]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/panel",
						className: "btn btn-primary mt-4",
						children: "پنل"
					})
				]
			}) : cart.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-muted",
				children: "سبد خالی است."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 mt-6",
				onSubmit: (e) => {
					e.preventDefault();
					const fd = new FormData(e.currentTarget);
					const r = cart.place({
						name: String(fd.get("name") ?? ""),
						phone: String(fd.get("phone") ?? ""),
						address: String(fd.get("address") ?? "")
					});
					if (!r.ok) {
						alert(r.message);
						return;
					}
					track("checkout");
					setRef(r.ref ?? null);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: money(cart.total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						name: "name",
						required: true,
						placeholder: "نام تحویل‌گیرنده"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						name: "phone",
						required: true,
						pattern: "09[0-9]{9}",
						placeholder: "09xxxxxxxxx"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-24",
						name: "address",
						required: true,
						placeholder: "نشانی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						children: "پرداخت نمایشی"
					})
				]
			}) })
		]
	}) });
}
//#endregion
export { Checkout as component };
