import { i as TOPICS, n as PRODUCTS, r as PROJECTS, t as BRAND } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCover } from "./covers-CrfxI3oq.mjs";
import { t as ProductCard } from "./product-card-B7yz6a2e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-XWqxl8xz.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-site py-12 sm:py-16 grid gap-10 lg:grid-cols-[1.05fr_.95fr] items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "kicker",
					children: ["استودیوی ", BRAND.fa]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl sm:text-6xl mt-3",
					children: BRAND.owner
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-lg text-muted",
					children: [BRAND.slogan, " — وب‌سایت، قالب و ابزار فول‌استک."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-prose text-muted",
					children: "کد تمیز، امنیت لایه‌لایه، پیش‌نمایش واقعی محصول بدون لینک مرده. قیمت و موجودی را نمی‌توان با Inspect عوض کرد."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "btn btn-primary",
						children: "فروشگاه"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/portfolio",
						className: "btn btn-ghost",
						children: "نمونه‌کارها"
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "surface rounded-[var(--radius-lg)] overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
					kind: "desk",
					title: "فضای کار گلدن‌دِوز"
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-site pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "محصولات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl mt-2 mb-6",
					children: "قابل خرید، با پیش‌نمایش زنده"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-site pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "نمونه‌کار"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl mt-2 mb-6",
					children: "پروژه‌های اخیر"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-3",
					children: PROJECTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/portfolio",
						className: "surface rounded-[var(--radius-lg)] overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
							kind: p.slug === "zaferan" ? "resto" : "template",
							title: p.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: p.year
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-medium mt-1",
									children: p.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted mt-1",
									children: p.desc
								})
							]
						})]
					}, p.slug))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "container-site pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "آموزش"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl mt-2 mb-6",
					children: "یادداشت‌های کوتاه"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: TOPICS.slice(0, 4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/topics/$slug",
						params: { slug: t.slug },
						className: "surface rounded-[var(--radius-md)] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: t.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted mt-1",
							children: t.lead
						})]
					}, t.slug))
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
