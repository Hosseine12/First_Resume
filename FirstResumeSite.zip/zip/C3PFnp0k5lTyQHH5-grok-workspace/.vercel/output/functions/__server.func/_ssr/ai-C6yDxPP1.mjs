import { i as TOPICS, n as PRODUCTS, t as BRAND } from "./catalog-DNnb2CJN.mjs";
import { n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-C6yDxPP1.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var buckets = /* @__PURE__ */ new Map();
function limited(key, max, windowMs) {
	const now = Date.now();
	const b = buckets.get(key);
	if (!b || now - b.t > windowMs) {
		buckets.set(key, {
			n: 1,
			t: now
		});
		return false;
	}
	if (b.n >= max) return true;
	b.n += 1;
	return false;
}
var knowledge = [
	`برند: ${BRAND.fa} (${BRAND.name}) — ${BRAND.owner}.`,
	"محصولات:",
	...PRODUCTS.map((p) => `- ${p.title} | ${p.price} تومان | موجودی ${p.stock} | ${p.summary}`),
	"مقالات:",
	...TOPICS.map((t) => `- ${t.title}: ${t.lead}`),
	"پرداخت فعلاً نمایشی است. قیمت سبد فقط از کاتالوگ سرور/کلاینت هم‌خوان خوانده می‌شود نه از DOM."
].join("\n");
var askAssistant_createServerFn_handler = createServerRpc({
	id: "8588707f9edacd23d5b70905cf6dfa3e4d91ffbf23f534c51c874f891e550260",
	name: "askAssistant",
	filename: "src/lib/server/ai.ts"
}, (opts) => askAssistant.__executeServer(opts));
var askAssistant = createServerFn({ method: "POST" }).validator((input) => {
	const question = String(input.question ?? "").trim().slice(0, 500);
	if (question.length < 2) throw new Error("پیام خیلی کوتاه است.");
	return {
		question,
		history: (input.history ?? []).slice(-6).map((h) => ({
			role: h.role === "assistant" ? "assistant" : "user",
			content: String(h.content ?? "").slice(0, 400)
		}))
	};
}).handler(askAssistant_createServerFn_handler, async ({ data }) => {
	if (limited("chat", 20, 6e5)) return {
		ok: false,
		error: "فعلاً زیاد پیام فرستادید. کمی بعد دوباره."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: true,
		text: "دستیار فعلاً به مدل وصل نیست. از مقالات و صفحهٔ تماس استفاده کنید یا بعداً دوباره سر بزنید."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 400,
			messages: [
				{
					role: "system",
					content: `تو زرین، دستیار ${BRAND.fa} هستی. فارسی، کوتاه، دقیق. حدس نزن. اگر نمی‌دانی بگو به پشتیبانی انسانی وصل شود. دانش:\n${knowledge}`
				},
				...data.history,
				{
					role: "user",
					content: data.question
				}
			]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "پاسخ مدل الان در دسترس نیست."
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? "پاسخی نبود."
	};
});
var draftSeo_createServerFn_handler = createServerRpc({
	id: "3435f1a4f906237c93048cec8e4ae5e6e0dd5dffe80f4c23d90a4ab60a83a4a8",
	name: "draftSeo",
	filename: "src/lib/server/ai.ts"
}, (opts) => draftSeo.__executeServer(opts));
var draftSeo = createServerFn({ method: "POST" }).validator((input) => {
	const topic = String(input.topic ?? "").trim().slice(0, 120);
	const notes = String(input.notes ?? "").trim().slice(0, 1500);
	const competitor = String(input.competitor ?? "").trim().slice(0, 1500);
	if (topic.length < 3) throw new Error("موضوع را بنویسید.");
	return {
		topic,
		notes,
		competitor
	};
}).handler(draftSeo_createServerFn_handler, async ({ data }) => {
	if (limited("seo", 8, 18e5)) return {
		ok: false,
		error: "سقف پیش‌نویس این بازه پر شده."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "مدل در این محیط فعال نیست."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 900,
			messages: [{
				role: "system",
				content: "ویراستار سئوی فارسی هستی. خروجی باید اصیل باشد، کپی از رقبا ممنوع، ساختار: عنوان، توضیح متا، طرح کلی، متن، نکات داخلی‌لینک. اگر متن رقیب داده شد فقط الگو بگیر نه جمله."
			}, {
				role: "user",
				content: `موضوع: ${data.topic}\nیادداشت: ${data.notes}\nنمونه رقیب (اختیاری):\n${data.competitor || "—"}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "خطا در تولید پیش‌نویس."
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? ""
	};
});
var sendContact_createServerFn_handler = createServerRpc({
	id: "bf7321bf8b58fa63f93e4e3bec1b7f3743a7bd7a44f88674c2dead0eae6fc88a",
	name: "sendContact",
	filename: "src/lib/server/ai.ts"
}, (opts) => sendContact.__executeServer(opts));
var sendContact = createServerFn({ method: "POST" }).validator((input) => {
	const name = String(input.name ?? "").trim().slice(0, 80);
	const email = String(input.email ?? "").trim().slice(0, 120);
	const subject = String(input.subject ?? "").trim().slice(0, 120);
	const body = String(input.body ?? "").trim().slice(0, 2e3);
	if (name.length < 2 || !email.includes("@") || subject.length < 2 || body.length < 8) throw new Error("فرم را کامل و معتبر پر کنید.");
	return {
		name,
		email,
		subject,
		body
	};
}).handler(sendContact_createServerFn_handler, async ({ data }) => {
	if (limited("contact:" + data.email, 3, 18e5)) return {
		ok: false,
		error: "پیام‌های این ایمیل موقتاً محدود شد."
	};
	return { ok: true };
});
//#endregion
export { askAssistant_createServerFn_handler, draftSeo_createServerFn_handler, sendContact_createServerFn_handler };
