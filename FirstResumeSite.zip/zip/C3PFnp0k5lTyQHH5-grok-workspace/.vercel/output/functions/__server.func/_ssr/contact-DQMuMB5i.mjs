import { o as __toESM } from "../_runtime.mjs";
import { t as BRAND } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, W as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell, p as track, u as sendContact } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DQMuMB5i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Contact() {
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10 max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "خانه / تماس"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: "تماس با من"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted mt-2 text-sm",
				children: [BRAND.email, " — فرم دارای محدودیت نرخ است و ایمیل را در کلاینت ذخیره نمی‌کند."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 mt-6",
				onSubmit: async (e) => {
					e.preventDefault();
					const fd = new FormData(e.currentTarget);
					setBusy(true);
					setMsg(null);
					try {
						const res = await sendContact({ data: {
							name: String(fd.get("name") ?? ""),
							email: String(fd.get("email") ?? ""),
							subject: String(fd.get("subject") ?? ""),
							body: String(fd.get("body") ?? "")
						} });
						track("contact");
						setMsg(res.ok ? "پیام دریافت شد." : res.error);
						if (res.ok) e.currentTarget.reset();
					} catch (err) {
						setMsg(err instanceof Error ? err.message : "خطا");
					} finally {
						setBusy(false);
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						name: "name",
						required: true,
						placeholder: "نام",
						maxLength: 80
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						name: "email",
						type: "email",
						required: true,
						placeholder: "ایمیل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						name: "subject",
						required: true,
						placeholder: "موضوع",
						maxLength: 120
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field min-h-32",
						name: "body",
						required: true,
						placeholder: "پیام",
						maxLength: 2e3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						disabled: busy,
						children: "ارسال"
					}),
					msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: msg
					})
				]
			})
		]
	}) });
}
//#endregion
export { Contact as component };
