import { i as TOPICS } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topics.index-DpJhfaAx.js
var import_jsx_runtime = require_jsx_runtime();
function Topics() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "خانه / آموزش"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: "آموزش و مقالات"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 mt-8",
				children: TOPICS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/topics/$slug",
					params: { slug: t.slug },
					className: "surface rounded-[var(--radius-md)] p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-medium",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mt-1",
						children: t.lead
					})]
				}, t.slug))
			})
		]
	}) });
}
//#endregion
export { Topics as component };
