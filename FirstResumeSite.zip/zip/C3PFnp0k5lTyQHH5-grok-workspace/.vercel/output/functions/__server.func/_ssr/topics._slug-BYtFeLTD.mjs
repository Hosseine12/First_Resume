import { i as TOPICS } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, U as notFound, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Route$1 } from "./router-C7l28Tgs.mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topics._slug-BYtFeLTD.js
var import_jsx_runtime = require_jsx_runtime();
function Topic() {
	const { slug } = Route$1.useParams();
	const t = TOPICS.find((x) => x.slug === slug);
	if (!t) throw notFound();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "container-site py-10 max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/topics",
						children: "آموزش"
					}),
					" / ",
					t.title
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: t.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg text-muted mt-3",
				children: t.lead
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 leading-8",
				children: t.body
			})
		]
	}) });
}
//#endregion
export { Topic as component };
