import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, W as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as GROK_PROVIDERS } from "./router-C7l28Tgs.mjs";
import { a as authClient, d as signIn, i as SiteShell } from "./site-shell-ChA7op6X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-C_Fbbmqu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const [mode, setMode] = (0, import_react.useState)("in");
	const [err, setErr] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-12 max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: mode === "in" ? "ورود" : "ثبت‌نام"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted mt-2",
				children: "گوگل، ایکس، یا ایمیل."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 mt-6",
				children: [
					GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost w-full",
						onClick: () => signIn(p.providerId, { callbackURL: "/panel" }),
						children: ["ادامه با ", p.label]
					}, p.providerId)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "grid gap-3 mt-4",
						onSubmit: async (e) => {
							e.preventDefault();
							const fd = new FormData(e.currentTarget);
							const email = String(fd.get("email") ?? "");
							const password = String(fd.get("password") ?? "");
							const name = String(fd.get("name") ?? "");
							setBusy(true);
							setErr(null);
							try {
								if (mode === "up") {
									const r = await authClient.signUp.email({
										email,
										password,
										name
									});
									if (r.error) setErr(r.error.message ?? "ثبت‌نام ناموفق");
									else window.location.href = "/panel";
								} else {
									const r = await authClient.signIn.email({
										email,
										password
									});
									if (r.error) setErr(r.error.message ?? "ورود ناموفق");
									else window.location.href = "/panel";
								}
							} catch (ex) {
								setErr(ex instanceof Error ? ex.message : "خطا");
							} finally {
								setBusy(false);
							}
						},
						children: [
							mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								name: "name",
								required: true,
								placeholder: "نام"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								name: "email",
								type: "email",
								required: true,
								placeholder: "ایمیل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								name: "password",
								type: "password",
								required: true,
								minLength: 8,
								placeholder: "رمز (حداقل ۸)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn btn-primary",
								type: "submit",
								disabled: busy,
								children: mode === "in" ? "ورود با ایمیل" : "ساخت حساب"
							}),
							err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-red-700",
								children: err
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-brand mt-2",
						onClick: () => setMode(mode === "in" ? "up" : "in"),
						children: mode === "in" ? "حساب ندارید؟ ثبت‌نام" : "حساب دارید؟ ورود"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "بازگشت"
				})
			})
		]
	}) });
}
//#endregion
export { Login as component };
