import { r as PROJECTS } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as SiteShell } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCover } from "./covers-CrfxI3oq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-PDZqIlXH.js
var import_jsx_runtime = require_jsx_runtime();
function Portfolio() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "خانه / نمونه‌کارها"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: "نمونه‌کارها"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:grid-cols-2 mt-8",
				children: PROJECTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "surface rounded-[var(--radius-lg)] overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
						kind: p.slug === "zaferan" ? "resto" : "template",
						title: p.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: p.year
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium mt-1",
								children: p.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted mt-1",
								children: p.desc
							}),
							p.preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/preview/$slug",
								params: { slug: p.preview.replace("/preview/", "") },
								className: "btn btn-ghost mt-3 text-sm",
								children: "پیش‌نمایش"
							})
						]
					})]
				}, p.slug))
			})
		]
	}) });
}
//#endregion
export { Portfolio as component };
