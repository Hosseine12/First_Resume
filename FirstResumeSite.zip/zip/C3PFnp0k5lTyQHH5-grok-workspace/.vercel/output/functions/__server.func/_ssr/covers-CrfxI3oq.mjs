import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/covers-CrfxI3oq.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCover({ kind, title, className = "" }) {
	const palettes = {
		template: [
			"#0c7f70",
			"#d7efe9",
			"#c4a574"
		],
		script: [
			"#1f4e5f",
			"#dce8e6",
			"#8aa4a1"
		],
		uikit: [
			"#2f5d50",
			"#e7eee8",
			"#b08968"
		],
		bot: [
			"#121816",
			"#1c2623",
			"#7f908b"
		],
		plugin: [
			"#0c7f70",
			"#eef4f1",
			"#c4a574"
		],
		resto: [
			"#5c3d2e",
			"#f3eadb",
			"#0c7f70"
		],
		desk: [
			"#2a322e",
			"#ece7dc",
			"#0c7f70"
		]
	};
	const [a, b, c] = palettes[kind] ?? palettes.template;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 800 500",
		className,
		role: "img",
		"aria-label": title,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "800",
				height: "500",
				fill: b
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "40",
				y: "36",
				width: "720",
				height: "428",
				rx: "22",
				fill: kind === "bot" ? "#0e1412" : "#fff",
				opacity: "0.92"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "64",
				y: "60",
				width: "120",
				height: "10",
				rx: "5",
				fill: a
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "64",
				y: "86",
				width: "280",
				height: "28",
				rx: "6",
				fill: kind === "bot" ? "#d7efe9" : a,
				opacity: "0.9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "64",
				y: "130",
				width: "210",
				height: "10",
				rx: "5",
				fill: c,
				opacity: "0.7"
			}),
			[
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				transform: `translate(${64 + i * 230}, 180)`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "210",
						height: "150",
						rx: "14",
						fill: kind === "bot" ? "#17201d" : b
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "14",
						width: "182",
						height: "72",
						rx: "8",
						fill: a,
						opacity: "0.35"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "98",
						width: "120",
						height: "10",
						rx: "5",
						fill: a
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "118",
						width: "80",
						height: "8",
						rx: "4",
						fill: c
					})
				]
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "400",
				y: "460",
				textAnchor: "middle",
				fill: a,
				fontSize: "22",
				fontFamily: "Vazirmatn, sans-serif",
				children: title
			})
		]
	});
}
//#endregion
export { ProductCover as t };
