import { o as productBySlug } from "./catalog-DNnb2CJN.mjs";
import { C as require_jsx_runtime, U as notFound, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as Route$3, d as useCart } from "./router-C7l28Tgs.mjs";
import { c as money, i as SiteShell, p as track, s as faNum } from "./site-shell-ChA7op6X.mjs";
import { t as ProductCover } from "./covers-CrfxI3oq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop._slug-DQe3QAJA.js
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { slug } = Route$3.useParams();
	const p = productBySlug(slug);
	if (!p) throw notFound();
	const cart = useCart();
	const owned = cart.owned.has(p.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "container-site py-10 grid gap-8 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCover, {
			kind: p.kind,
			title: p.title,
			className: "surface rounded-[var(--radius-lg)]"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["فروشگاه / ", p.kindLabel]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl mt-2",
				children: p.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: p.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-2 mt-4",
				children: p.stack.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-xs border border-line rounded-full px-3 py-1",
					children: s
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl text-brand mt-6",
				children: money(p.price)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted mt-1",
				children: [
					"موجودی ",
					faNum(p.stock),
					" — کنترل سمت کاتالوگ"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 mt-6",
				children: [
					p.preview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/preview/$slug",
						params: { slug: p.slug },
						className: "btn btn-ghost",
						children: ["پیش‌نمایش ", p.demoLive ? "زنده" : "محیط"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						disabled: p.stock < 1,
						onClick: () => {
							const r = cart.add(p.id);
							track("add_cart");
							toast(r.message);
						},
						children: "افزودن به سبد"
					}),
					owned && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "btn btn-soft",
						href: `/api/download/${p.slug}`,
						onClick: (e) => e.preventDefault(),
						children: "دانلود پس از خرید (نسخهٔ نمایشی در پنل)"
					})
				]
			})
		] })]
	}) });
}
//#endregion
export { ProductPage as component };
