//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BSYZPXFI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/cart",
			"/checkout",
			"/contact",
			"/login",
			"/panel",
			"/portfolio",
			"/search",
			"/shop",
			"/topics",
			"/preview/$slug",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-B-ToyJ1A.js",
			"/assets/useStore-DF6keGWe.js",
			"/assets/cart-CS71ZUg6.js",
			"/assets/root-DLTE-HSj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B-ToyJ1A.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cn67vTZ6.js",
			"/assets/site-shell-CRs2Xu52.js",
			"/assets/covers-ECh728Zg.js",
			"/assets/product-card-B2MPdUm_.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DZqsjJ_V.js",
			"/assets/site-shell-CRs2Xu52.js",
			"/assets/covers-ECh728Zg.js"
		]
	},
	"/cart": {
		filePath: "/workspace/src/routes/cart.tsx",
		children: void 0,
		preloads: ["/assets/cart-BC-jVToI.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-C0s7ubih.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BMLKuQ4P.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-9WHR3xRf.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/panel": {
		filePath: "/workspace/src/routes/panel.tsx",
		children: void 0,
		preloads: ["/assets/panel-0TO1U3jf.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/portfolio": {
		filePath: "/workspace/src/routes/portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio-CDZv1ejM.js",
			"/assets/site-shell-CRs2Xu52.js",
			"/assets/covers-ECh728Zg.js"
		]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-BcNdjNql.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: ["/shop/$slug", "/shop/"],
		preloads: ["/assets/shop-DOP2jlIu.js"]
	},
	"/topics": {
		filePath: "/workspace/src/routes/topics.tsx",
		children: ["/topics/$slug", "/topics/"],
		preloads: ["/assets/topics-DOP2jlIu.js"]
	},
	"/preview/$slug": {
		filePath: "/workspace/src/routes/preview.$slug.tsx",
		children: void 0,
		preloads: ["/assets/preview._slug-BBvbbjYO.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/shop/$slug": {
		filePath: "/workspace/src/routes/shop.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/shop._slug-D6ypWnMt.js",
			"/assets/site-shell-CRs2Xu52.js",
			"/assets/covers-ECh728Zg.js"
		]
	},
	"/topics/$slug": {
		filePath: "/workspace/src/routes/topics.$slug.tsx",
		children: void 0,
		preloads: ["/assets/topics._slug-DdJYELKS.js", "/assets/site-shell-CRs2Xu52.js"]
	},
	"/shop/": {
		filePath: "/workspace/src/routes/shop.index.tsx",
		children: void 0,
		preloads: [
			"/assets/shop.index-CYvKA534.js",
			"/assets/site-shell-CRs2Xu52.js",
			"/assets/product-card-B2MPdUm_.js"
		]
	},
	"/topics/": {
		filePath: "/workspace/src/routes/topics.index.tsx",
		children: void 0,
		preloads: ["/assets/topics.index-BvENP_-S.js", "/assets/site-shell-CRs2Xu52.js"]
	}
} });
//#endregion
export { tsrStartManifest };
