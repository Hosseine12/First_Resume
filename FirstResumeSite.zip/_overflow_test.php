<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html><html><body><script>
const f=document.createElement('iframe');
f.width=390;f.height=800;f.style.cssText='border:0';
f.src='index.php?page=home';
f.onload=()=>{
  setTimeout(()=>{
    const d=f.contentDocument; const out=[];
    out.push('body.scrollWidth='+d.body.scrollWidth+' docEl.scrollWidth='+d.documentElement.scrollWidth+' innerWidth='+f.contentWindow.innerWidth);
    const bad=[];
    for(const el of d.body.querySelectorAll('*')){
      const r=el.getBoundingClientRect();
      if(r.width>391||r.right>391.5){
        const cs=f.contentWindow.getComputedStyle(el);
        bad.push(el.tagName.toLowerCase()+(el.className&&typeof el.className==='string'?'.'+el.className.split(' ').join('.'):'')+' w='+Math.round(r.width)+' right='+Math.round(r.right)+' pos='+cs.position);
      }
    }
    out.push('OFFENDERS('+bad.length+'):');
    out.push(bad.slice(0,40).join('\n'));
    document.body.style.whiteSpace='pre';document.body.style.font='11px monospace';
    document.body.textContent=out.join('\n');
  },1500);
};
document.body.appendChild(f);
</script></body></html>
