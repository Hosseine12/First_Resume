<?php
/* ============================================================
   Portfolio + Shop — Single-File Edition (PHP 8 + MySQL)
   نصب: install.sql را اجرا کن، سپس این فایل را در سرور PHP بگذار
   ورود مدیر: admin / Admin@123
   ============================================================ */
declare(strict_types=1);

/* ---------- تنظیمات ---------- */
const DB_HOST='127.0.0.1', DB_NAME='portfolio_shop', DB_USER='root', DB_PASS='';
const SITE_NAME='مهدی رضایی — توسعه‌دهندهٔ وب';

/* ---------- دیتابیس ---------- */
function db(): PDO {
    static $pdo=null;
    if($pdo===null){
        try{ $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
        }catch(PDOException $e){ http_response_code(500); exit('خطا در اتصال به دیتابیس. ابتدا install.sql را اجرا کنید.'); }
    }
    return $pdo;
}

/* ---------- سشن ---------- */
if(session_status()===PHP_SESSION_NONE){
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
    session_start();
}

/* ---------- کمکی‌ها ---------- */
function e(?string $v):string{ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function fa_num($v):string{ return str_replace(range('0','9'),['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],(string)$v); }
function money($p):string{ return fa_num(number_format((float)$p)).' تومان'; }
function redirect(string $to):void{ header('Location: '.$to); exit; }
function url(string $page=''):string{ return $page===''?'index.php':'index.php?page='.$page; }
function slugify(string $t):string{ $t=preg_replace('/[^\p{L}\p{N}_\-]+/u','-',trim($t)); return trim((string)preg_replace('/-{2,}/','-',$t),'-'); }

function flash(string $type,string $msg):void{ $_SESSION['_flash'][]=['type'=>$type,'message'=>$msg]; }
function take_flash():array{ $i=$_SESSION['_flash']??[]; unset($_SESSION['_flash']); return $i; }
function keep_old():void{ $_SESSION['_old']=$_POST; }
function old(string $k,string $d=''):string{ return e((string)($_SESSION['_old'][$k]??$d)); }
function clear_old():void{ unset($_SESSION['_old']); }

/* ---------- CSRF ---------- */
function csrf_token():string{ if(empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field():string{ return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf():void{
    if(!hash_equals((string)($_SESSION['_csrf']??''),(string)($_POST['csrf']??''))){
        flash('error','خطای اعتبارسنجی فرم (CSRF).'); redirect($_SERVER['HTTP_REFERER']??url());
    }
}

/* ---------- اعتبارسنجی ---------- */
function validate(array $data,array $rules):array{
    $errors=[];
    foreach($rules as $f=>$set){
        $v=trim((string)($data[$f]??''));
        foreach(explode('|',$set) as $r){
            [$n,$p]=array_pad(explode(':',$r,2),2,null);
            if($n!=='required'&&$v==='') continue;
            switch($n){
                case 'required': if($v==='') $errors[$f][]='این فیلد الزامی است.'; break;
                case 'email': if(!filter_var($v,FILTER_VALIDATE_EMAIL)) $errors[$f][]='ایمیل معتبر نیست.'; break;
                case 'min': if(mb_strlen($v)<(int)$p) $errors[$f][]='حداقل '.fa_num($p).' کاراکتر لازم است.'; break;
                case 'max': if(mb_strlen($v)>(int)$p) $errors[$f][]='حداکثر '.fa_num($p).' کاراکتر مجاز است.'; break;
                case 'numeric': if(!is_numeric($v)) $errors[$f][]='مقدار باید عددی باشد.'; break;
                case 'username': if(!preg_match('/^[A-Za-z0-9_]{3,40}$/',$v)) $errors[$f][]='نام کاربری فقط حروف انگلیسی، عدد و _.'; break;
                case 'url': if(!filter_var($v,FILTER_VALIDATE_URL)) $errors[$f][]='نشانی تصویر معتبر نیست.'; break;
            }
        }
    }
    return $errors;
}
function dump_errors(array $errors):void{ foreach($errors as $l) foreach($l as $m) flash('error',$m); }

/* ---------- احراز هویت و RBAC ---------- */
function current_user():?array{
    static $u=false;
    if($u===false){
        $u=null;
        if(!empty($_SESSION['user_id'])){
            $st=db()->prepare('SELECT id,name,username,email,role,status,created_at FROM users WHERE id=? LIMIT 1');
            $st->execute([(int)$_SESSION['user_id']]);
            $row=$st->fetch();
            if($row && (int)$row['status']===1) $u=$row; else { session_destroy(); $_SESSION=[]; }
        }
    }
    return $u;
}
function is_admin():bool{ $u=current_user(); return $u && $u['role']==='admin'; }
function login_user(array $u):void{ session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; }
function logout_user():void{ $_SESSION=[]; if(ini_get('session.use_cookies')) setcookie(session_name(),'',time()-3600,'/'); session_destroy(); }
function require_login():void{ if(!current_user()){ flash('error','ابتدا وارد شوید.'); redirect(url('login')); } }
function require_admin():void{ require_login(); if(!is_admin()){ flash('error','دسترسی غیرمجاز.'); redirect(url('panel')); } }

/* ---------- دادهٔ نمونه‌کارها ---------- */
function projects():array{ return [
 ['title'=>'فروشگاه اینترنتی بازارچه','tags'=>['shop','web'],'year'=>'۱۴۰۳','desc'=>'فروشگاه کامل با سبد خرید، درگاه پرداخت و پنل مدیریت.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/106fafefc-79e4-4d6a-bbad-330a259655ad.png'],
 ['title'=>'اپلیکیشن مدیریت کارها «کارینو»','tags'=>['app','ui'],'year'=>'۱۴۰۳','desc'=>'اپ موبایل برای مدیریت وظایف روزانه و تقویم تیمی.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/1a81776d7-d96e-43a8-b8f4-ca54cdbf4948.png'],
 ['title'=>'سامانهٔ رزرو رستوران زعفران','tags'=>['web','ui'],'year'=>'۱۴۰۲','desc'=>'وب‌سایت رزرو میز با منوی دیجیتال و پنل مدیریت شعب.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/1766da59c-eae4-4f3d-a3ee-f2e1f72b6921.png'],
 ['title'=>'پلتفرم آموزش آنلاین دانشجو','tags'=>['web','app'],'year'=>'۱۴۰۲','desc'=>'سامانهٔ دوره‌های ویدیویی با آزمون، گواهی و پنل مدرس.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/11f9b7163-d637-4856-8033-73dd944db8b8.png'],
 ['title'=>'کیف پول دیجیتال آفتاب','tags'=>['app'],'year'=>'۱۴۰۱','desc'=>'اپ فین‌تک با انتقال وجه و احراز هویت دومرحله‌ای.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/15e6362e0-c40e-4aa6-ae54-e50b3b41a29a.png'],
 ['title'=>'سامانهٔ رزرو سفر سفرنیک','tags'=>['web','shop'],'year'=>'۱۴۰۱','desc'=>'پلتفرم رزرو تور و اقامتگاه با جستجوی پیشرفته.','image'=>'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/11c30fbcb-8c12-4f10-9d45-826ee2783722.png'],
];}
const TAG_LABEL=['shop'=>'فروشگاه','web'=>'وب‌سایت','app'=>'اپلیکیشن','ui'=>'رابط کاربری'];

/* ============================================================
   رسیدگی به همهٔ POSTها (قبل از هر خروجی)
   ============================================================ */
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $action=$_POST['action']??'';

    if($action==='logout'){ logout_user(); session_start(); flash('info','با موفقیت خارج شدید.'); redirect(url()); }

    if($action==='register'){
        $errors=validate($_POST,['name'=>'required|max:100','username'=>'required|username','email'=>'required|email|max:190','password'=>'required|min:8']);
        if(trim($_POST['password']??'')!==trim($_POST['password_confirm']??'')) $errors['password_confirm'][]='تکرار رمز مطابقت ندارد.';
        if(!$errors){
            $st=db()->prepare('SELECT id FROM users WHERE username=? OR email=? LIMIT 1');
            $st->execute([trim($_POST['username']),trim($_POST['email'])]);
            if($st->fetch()) $errors['username'][]='این نام کاربری یا ایمیل قبلاً ثبت شده.';
        }
        if(!$errors){
            db()->prepare('INSERT INTO users (name,username,email,password_hash,role) VALUES (?,?,?,?,?)')
                ->execute([trim($_POST['name']),trim($_POST['username']),trim($_POST['email']),password_hash($_POST['password'],PASSWORD_DEFAULT),'user']);
            login_user(['id'=>db()->lastInsertId()]);
            flash('success','ثبت‌نام انجام شد. خوش آمدید! 🎉'); redirect(url('panel'));
        }
        dump_errors($errors); keep_old(); redirect(url('register'));
    }

    if($action==='login'){
        $id=trim($_POST['identifier']??''); $pass=$_POST['password']??'';
        $st=db()->prepare('SELECT * FROM users WHERE username=? OR email=? LIMIT 1');
        $st->execute([$id,$id]); $u=$st->fetch();
        if(!$u||!password_verify($pass,$u['password_hash'])){ flash('error','اطلاعات ورود اشتباه است.'); keep_old(); redirect(url('login')); }
        if((int)$u['status']!==1){ flash('error','حساب شما غیرفعال شده است.'); redirect(url('login')); }
        login_user($u); flash('success','خوش آمدید، '.$u['name'].'!');
        redirect($u['role']==='admin'?url('admin'):url('panel'));
    }

    if($action==='contact'){
        $errors=validate($_POST,['name'=>'required|max:100','email'=>'required|email','subject'=>'required|max:190','body'=>'required|max:3000']);
        if(!$errors){
            db()->prepare('INSERT INTO messages (name,email,subject,body) VALUES (?,?,?,?)')
                ->execute([trim($_POST['name']),trim($_POST['email']),trim($_POST['subject']),trim($_POST['body'])]);
            flash('success','پیام شما ارسال شد. ✉️');
        } else { dump_errors($errors); keep_old(); }
        redirect(url('contact'));
    }

    if($action==='profile'){
        require_login(); $me=current_user();
        $errors=validate($_POST,['name'=>'required|max:100','email'=>'required|email']);
        if(!$errors){
            $st=db()->prepare('SELECT id FROM users WHERE email=? AND id<>? LIMIT 1');
            $st->execute([trim($_POST['email']),$me['id']]);
            if($st->fetch()) $errors['email'][]='این ایمیل توسط کاربر دیگری استفاده شده.';
        }
        if(!$errors){ db()->prepare('UPDATE users SET name=?,email=? WHERE id=?')->execute([trim($_POST['name']),trim($_POST['email']),$me['id']]); flash('success','اطلاعات به‌روزرسانی شد.'); }
        else { dump_errors($errors); keep_old(); }
        redirect(url('panel'));
    }

    if($action==='password'){
        require_login(); $me=current_user();
        $errors=validate($_POST,['current'=>'required','password'=>'required|min:8']);
        if(trim($_POST['password']??'')!==trim($_POST['password_confirm']??'')) $errors['password_confirm'][]='تکرار رمز مطابقت ندارد.';
        if($errors){ dump_errors($errors); redirect(url('panel')); }
        $st=db()->prepare('SELECT password_hash FROM users WHERE id=?'); $st->execute([$me['id']]);
        if(!password_verify($_POST['current'],$st->fetchColumn())) flash('error','رمز فعلی اشتباه است.');
        else { db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($_POST['password'],PASSWORD_DEFAULT),$me['id']]); flash('success','رمز عبور تغییر کرد.'); }
        redirect(url('panel'));
    }

    if($action==='product_save'){
        require_admin();
        $id=(int)($_POST['id']??0);
        $errors=validate($_POST,['title'=>'required|max:150','price'=>'required|numeric','stock'=>'required|numeric','image'=>'url|max:500']);
        if((float)($_POST['price']??0)<0) $errors['price'][]='قیمت منفی مجاز نیست.';
        if((int)($_POST['stock']??0)<0) $errors['stock'][]='موجودی منفی مجاز نیست.';
        if($errors){ dump_errors($errors); keep_old(); redirect(url($id?'product_edit&id='.$id:'product_create')); }
        $title=trim($_POST['title']);
        $slug=slugify(trim($_POST['slug']??''))?:slugify($title); $base=$slug; $i=1;
        $st=db()->prepare('SELECT id FROM products WHERE slug=? AND id<>? LIMIT 1');
        while(true){ $st->execute([$slug,$id]); if(!$st->fetch()) break; $slug=$base.'-'.(++$i); }
        $params=[$title,$slug,trim($_POST['description']??''),(float)$_POST['price'],(int)$_POST['stock'],
                 trim($_POST['image']??'')?:null,($_POST['status']??'published')==='draft'?'draft':'published'];
        if($id>0){ $params[]=$id; db()->prepare('UPDATE products SET title=?,slug=?,description=?,price=?,stock=?,image=?,status=? WHERE id=?')->execute($params); flash('success','محصول ویرایش شد.'); }
        else { db()->prepare('INSERT INTO products (title,slug,description,price,stock,image,status) VALUES (?,?,?,?,?,?,?)')->execute($params); flash('success','محصول ثبت شد.'); }
        redirect(url('admin_products'));
    }

    if($action==='product_delete'){
        require_admin();
        db()->prepare('DELETE FROM products WHERE id=?')->execute([(int)($_POST['id']??0)]);
        flash('success','محصول حذف شد.'); redirect(url('admin_products'));
    }

    if(in_array($action,['user_role','user_status','user_delete'],true)){
        require_admin(); $me=current_user();
        $tid=(int)($_POST['id']??0);
        $st=db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1'); $st->execute([$tid]); $t=$st->fetch();
        if(!$t) flash('error','کاربر یافت نشد.');
        elseif($tid===(int)$me['id']) flash('error','این عملیات روی خودتان مجاز نیست.');
        elseif($action==='user_role'){
            if($t['role']==='admin'){
                $n=(int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status=1")->fetchColumn();
                if($n<=1) flash('error','حداقل یک مدیر فعال باید بماند.');
                else { db()->prepare('UPDATE users SET role=? WHERE id=?')->execute(['user',$tid]); flash('success','نقش تغییر کرد.'); }
            } else { db()->prepare('UPDATE users SET role=? WHERE id=?')->execute(['admin',$tid]); flash('success','به مدیر ارتقا یافت.'); }
        }
        elseif($action==='user_status'){ db()->prepare('UPDATE users SET status=1-status WHERE id=?')->execute([$tid]); flash('success','وضعیت تغییر کرد.'); }
        elseif($action==='user_delete'){ db()->prepare('DELETE FROM users WHERE id=?')->execute([$tid]); flash('success','کاربر حذف شد.'); }
        redirect(url('admin_users'));
    }
}

/* ============================================================
   قالب کلی (Layout)
   ============================================================ */
function layout(string $title,callable $content):void{
    $u=current_user(); $page=$_GET['page']??'home';
    $nav=[['home','خانه'],['about','دربارهٔ من'],['portfolio','نمونه‌کارها'],['shop','فروشگاه'],['contact','تماس با من']];
    ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> | مهدی رضایی</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn@5/400.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn@5/700.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/vazirmatn@5/800.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/lalezar@5/400.css">
<style>
:root{--paper:#f1f5f3;--surface:#fff;--ink:#0d2b26;--ink-2:#3f5f58;--ink-3:#71857f;--teal:#0c7f70;--teal-deep:#08574c;--teal-ink:#06231f;--turq:#14b8a6;--saffron:#e8a33d;--saffron-deep:#c9832a;--rose:#d96a5b;--line:#d5e0db;--shadow-sm:0 2px 8px rgba(8,60,52,.06);--shadow-md:0 10px 30px rgba(8,60,52,.10);--shadow-lg:0 24px 60px rgba(8,60,52,.16);--r-sm:8px;--r-md:14px;--r-lg:22px;--fd:'Lalezar','Vazirmatn',serif;--fb:'Vazirmatn',Tahoma,sans-serif}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--fb);background:var(--paper);color:var(--ink);line-height:1.9;font-size:16px;overflow-x:hidden}
body::before{content:'';position:fixed;inset:0;z-index:-2;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='76' height='76' viewBox='0 0 76 76'%3E%3Cpath d='M38 4l8 15 16-5-5 16 15 8-15 8 5 16-16-5-8 15-8-15-16 5 5-16-15-8 15-8-5-16 16 5z' fill='none' stroke='%230c7f70' stroke-opacity='.06'/%3E%3C/svg%3E");background-size:84px}
body::after{content:'';position:fixed;inset:0;z-index:-1;pointer-events:none;background:radial-gradient(600px 420px at 92% -6%,rgba(20,184,166,.14),transparent 65%),radial-gradient(720px 520px at -10% 38%,rgba(232,163,61,.12),transparent 60%),radial-gradient(520px 420px at 70% 102%,rgba(12,127,112,.10),transparent 60%)}
img{max-width:100%;display:block}a{color:var(--teal);text-decoration:none}::selection{background:var(--saffron);color:var(--teal-ink)}
main{min-height:55vh}.container{width:min(1140px,92%);margin-inline:auto}.section{padding:5rem 0}
.section-alt{background:linear-gradient(180deg,rgba(255,255,255,.65),rgba(255,255,255,0));border-block:1px solid var(--line)}
.section-head{margin-bottom:2.2rem;max-width:60ch}.kicker{display:inline-flex;align-items:center;gap:.55rem;color:var(--teal);font-weight:700;font-size:.85rem}.kicker::before{content:'';width:26px;height:2px;background:var(--saffron)}
.section-title{font-family:var(--fd);font-size:clamp(1.9rem,4vw,2.7rem);line-height:1.45;margin:.4rem 0 .5rem}.section-lead{color:var(--ink-2)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;font-family:inherit;font-weight:700;font-size:.95rem;padding:.72rem 1.6rem;border-radius:var(--r-sm);border:2px solid transparent;cursor:pointer;transition:.25s;line-height:1.6}
.btn-primary{background:var(--teal);color:#fff;box-shadow:0 6px 18px rgba(12,127,112,.28)}.btn-primary:hover{background:var(--teal-deep);transform:translateY(-2px)}
.btn-outline{border-color:var(--teal);color:var(--teal)}.btn-outline:hover{background:var(--teal);color:#fff;transform:translateY(-2px)}
.btn-saffron{background:var(--saffron);color:var(--teal-ink)}.btn-saffron:hover{background:var(--saffron-deep);transform:translateY(-2px)}
.btn-ghost{color:var(--ink-2)}.btn-ghost:hover{color:var(--teal);background:rgba(12,127,112,.08)}
.btn-soft{background:rgba(217,106,91,.12);color:var(--rose)}.btn-soft:hover{background:var(--rose);color:#fff}
.btn-sm{padding:.42rem 1rem;font-size:.85rem}.btn-block{width:100%}.btn:active{transform:scale(.98)}
.inline-form{display:inline}
.site-header{position:sticky;top:0;z-index:100;background:rgba(241,245,243,.92);backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
.scroll-progress{position:absolute;bottom:-1px;right:0;height:3px;width:0;background:linear-gradient(90deg,var(--saffron),var(--turq));z-index:101}
.header-inner{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.85rem 0}
.logo{font-family:var(--fd);font-size:1.55rem;color:var(--ink);display:inline-flex;align-items:baseline;line-height:1}
.logo-dot{width:8px;height:8px;background:var(--saffron);border-radius:2px;display:inline-block;margin-inline-start:5px;transform:rotate(45deg);transition:.3s}.logo:hover .logo-dot{transform:rotate(225deg);background:var(--turq)}
.main-nav{display:flex;align-items:center;gap:.3rem}
.nav-link{position:relative;color:var(--ink-2);font-weight:600;font-size:.92rem;padding:.5rem .8rem;border-radius:var(--r-sm);transition:.2s}
.nav-link::after{content:'';position:absolute;bottom:2px;right:.8rem;left:.8rem;height:2px;background:var(--saffron);transform:scaleX(0);transform-origin:right;transition:.25s}
.nav-link:hover::after,.nav-link.is-active::after{transform:scaleX(1)}.nav-link.is-active{color:var(--teal)}
.nav-auth{display:flex;gap:.5rem;margin-inline-start:1rem;padding-inline-start:1rem;border-inline-start:1px solid var(--line)}
.nav-toggle{display:none;flex-direction:column;gap:5px;background:none;border:0;cursor:pointer;padding:8px;z-index:120}
.nav-toggle span{width:24px;height:2.5px;background:var(--ink);border-radius:2px;transition:.3s}
.nav-toggle.open span:nth-child(1){transform:translateY(7.5px) rotate(45deg)}.nav-toggle.open span:nth-child(2){opacity:0}.nav-toggle.open span:nth-child(3){transform:translateY(-7.5px) rotate(-45deg)}
.hero{padding:4rem 0 5rem}.hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:3rem;align-items:center}
.status-chip{display:inline-flex;align-items:center;gap:.55rem;background:var(--surface);border:1px solid var(--line);padding:.35rem 1rem;border-radius:999px;font-size:.82rem;font-weight:700;color:var(--teal-deep);box-shadow:var(--shadow-sm)}
.pulse-dot{width:9px;height:9px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.5);animation:pulse 2s infinite}@keyframes pulse{70%{box-shadow:0 0 0 9px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.hero-name{font-family:var(--fd);font-size:clamp(3rem,9vw,5.4rem);line-height:1.12;margin:1rem 0 .4rem}.hero-name span{color:var(--teal);position:relative}
.hero-name span::after{content:'';position:absolute;bottom:8px;right:0;left:0;height:11px;background:rgba(232,163,61,.4);z-index:-1;transform:skewX(-12deg)}
.hero-role{font-size:1.1rem;font-weight:700;color:var(--ink-2);min-height:1.6em}.role-typer{color:var(--saffron-deep)}
.caret{display:inline-block;width:2px;height:1.2em;background:var(--teal);margin-inline-start:3px;vertical-align:middle;animation:blink 1s steps(1) infinite}@keyframes blink{50%{opacity:0}}
.hero-desc{color:var(--ink-2);max-width:52ch;margin:.9rem 0 1.5rem}.hero-actions{display:flex;gap:.8rem;flex-wrap:wrap}
.hero-meta{display:flex;gap:1.8rem;list-style:none;margin-top:2rem;flex-wrap:wrap}.hero-meta li{color:var(--ink-3);font-size:.88rem}.hero-meta b{display:block;font-family:var(--fd);font-size:1.4rem;color:var(--ink);font-weight:400}
.hero-visual{position:relative}.terminal{background:var(--teal-ink);border-radius:var(--r-lg);box-shadow:var(--shadow-lg);overflow:hidden;transform:rotate(-1.5deg);transition:.4s}.terminal:hover{transform:rotate(0) scale(1.015)}
.terminal-bar{display:flex;align-items:center;gap:7px;padding:.8rem 1.1rem;background:rgba(255,255,255,.05)}.terminal-bar span{width:11px;height:11px;border-radius:50%}
.terminal-bar span:nth-child(1){background:#ff5f57}.terminal-bar span:nth-child(2){background:#febc2e}.terminal-bar span:nth-child(3){background:#28c840}
.terminal-bar em{margin-inline-start:auto;color:#7fb5ac;font-style:normal;font-size:.75rem;letter-spacing:1px}
.terminal-code{padding:1.3rem 1.4rem;direction:ltr;text-align:left;font-family:Consolas,monospace;font-size:.83rem;line-height:2;color:#c9e8e2;overflow-x:auto;white-space:pre}
.tk-k{color:#7dd3c0}.tk-s{color:#f0c674}.tk-v{color:#9adcff}.tk-c{color:#5d837b}.tk-f{color:#e8a33d}
.hero-avatar{position:absolute;bottom:-2rem;inset-inline-start:-1.2rem;width:126px;height:126px;border-radius:50%;object-fit:cover;border:5px solid var(--paper);box-shadow:var(--shadow-md);transform:rotate(4deg);transition:.35s}.hero-avatar:hover{transform:rotate(-3deg) scale(1.06)}
.marquee{background:var(--teal-ink);color:#bfe8df;overflow:hidden;padding:.9rem 0;border-block:3px solid var(--saffron)}
.marquee-track{display:flex;gap:2.5rem;width:max-content;animation:marquee 32s linear infinite}.marquee:hover .marquee-track{animation-play-state:paused}
.marquee-track span{display:inline-flex;align-items:center;gap:2.5rem;font-family:var(--fd);font-size:1.15rem;white-space:nowrap}.marquee-track i{color:var(--saffron);font-style:normal}
@keyframes marquee{to{transform:translateX(50%)}}
.stats-band{background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));color:#fff;padding:3rem 0}.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem}.stat-item{text-align:center}
.stat-num{font-family:var(--fd);font-size:clamp(2.3rem,5vw,3.3rem);color:var(--saffron);line-height:1.2}.stat-label{color:#a8d5cb;font-size:.9rem}
.skills-grid{display:grid;grid-template-columns:1fr 1fr;gap:3rem}.skill-row{margin-bottom:1.4rem}
.skill-head{display:flex;justify-content:space-between;font-weight:700;font-size:.92rem;margin-bottom:.45rem}.skill-head b{color:var(--teal);font-family:var(--fd);font-weight:400;font-size:1.05rem}
.bar{height:10px;background:#e2ebe7;border-radius:999px;overflow:hidden}.bar-fill{height:100%;width:0;background:linear-gradient(90deg,var(--teal),var(--turq));border-radius:999px;transition:width 1.3s cubic-bezier(.22,.9,.35,1);position:relative}
.bar-fill::after{content:'';position:absolute;inset-inline-end:0;top:0;bottom:0;width:12px;background:var(--saffron);border-radius:999px}
.timeline{position:relative;padding-inline-start:2rem;max-width:720px}.timeline::before{content:'';position:absolute;inset-inline-start:6px;top:6px;bottom:6px;width:2px;background:linear-gradient(180deg,var(--turq),var(--saffron))}
.t-item{position:relative;padding-bottom:2rem}.t-item::before{content:'';position:absolute;inset-inline-start:-32px;top:6px;width:14px;height:14px;border-radius:50%;background:var(--saffron);border:3px solid var(--paper);box-shadow:0 0 0 2px var(--teal)}
.t-date{display:inline-block;background:rgba(12,127,112,.1);color:var(--teal-deep);font-size:.78rem;font-weight:700;padding:.15rem .8rem;border-radius:999px;margin-bottom:.4rem}
.t-item h3{font-size:1.08rem}.t-item p{color:var(--ink-2);font-size:.94rem}
.filter-bar{display:flex;gap:.5rem;flex-wrap:wrap;margin:1.4rem 0 1.8rem}
.filter-btn{border:1.5px solid var(--line);background:var(--surface);color:var(--ink-2);padding:.42rem 1.2rem;border-radius:999px;font-family:inherit;font-weight:700;font-size:.85rem;cursor:pointer;transition:.2s}
.filter-btn:hover{border-color:var(--teal);color:var(--teal)}.filter-btn.is-active{background:var(--teal);border-color:var(--teal);color:#fff}
.portfolio-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.6rem}
.project-card{background:var(--surface);border-radius:var(--r-md);overflow:hidden;border:1px solid var(--line);transition:.35s;position:relative}
.project-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-lg);border-color:transparent}
.project-media{overflow:hidden;aspect-ratio:16/10}.project-media img{width:100%;height:100%;object-fit:cover;transition:transform .6s}.project-card:hover .project-media img{transform:scale(1.07)}
.project-body{padding:1.1rem 1.2rem 1.3rem}.project-tags{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.55rem}
.tag{font-size:.72rem;font-weight:700;background:rgba(20,184,166,.12);color:var(--teal-deep);padding:.12rem .7rem;border-radius:999px}.tag-gold{background:rgba(232,163,61,.16);color:var(--saffron-deep)}
.project-body h3{font-size:1.05rem;margin-bottom:.25rem}.project-body p{color:var(--ink-2);font-size:.87rem}
.project-year{position:absolute;top:.9rem;inset-inline-start:.9rem;background:rgba(6,35,31,.75);color:#fff;font-size:.75rem;padding:.15rem .7rem;border-radius:999px;backdrop-filter:blur(4px)}
.project-link{display:inline-flex;align-items:center;gap:.3rem;font-weight:700;font-size:.85rem;margin-top:.6rem;color:var(--teal)}.project-link::after{content:'←';transition:.25s}.project-link:hover::after{transform:translateX(-4px)}
.is-hidden{display:none}
.shop-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.6rem}
.product-card{background:var(--surface);border-radius:var(--r-md);overflow:hidden;border:1px solid var(--line);transition:.35s;display:flex;flex-direction:column}
.product-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-lg);border-color:transparent}
.product-media{position:relative;aspect-ratio:4/3;overflow:hidden;background:#e8efec}.product-media img{width:100%;height:100%;object-fit:cover;transition:transform .6s}.product-card:hover .product-media img{transform:scale(1.06)}
.product-stock{position:absolute;top:.8rem;inset-inline-end:.8rem;background:#22c55e;color:#fff;font-size:.72rem;font-weight:700;padding:.15rem .7rem;border-radius:999px}.product-stock.out{background:#94a3b8}
.product-body{padding:1.1rem 1.2rem 1.3rem;display:flex;flex-direction:column;flex:1}.product-body h3{font-size:1.02rem;margin-bottom:.25rem}.product-body p{color:var(--ink-2);font-size:.85rem;flex:1}
.product-foot{display:flex;justify-content:space-between;align-items:center;margin-top:.8rem;padding-top:.8rem;border-top:1px dashed var(--line)}.price{font-family:var(--fd);font-size:1.2rem;color:var(--teal-deep)}
.page-head{padding:4rem 0 2rem}.page-head h1{font-family:var(--fd);font-size:clamp(2.2rem,5vw,3.2rem);line-height:1.3}.breadcrumb{color:var(--ink-3);font-size:.85rem;margin-bottom:.4rem}
.about-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:3rem;align-items:center}.about-photo{position:relative}.about-photo img{border-radius:var(--r-lg);box-shadow:var(--shadow-lg)}
.about-photo::before{content:'';position:absolute;top:-14px;inset-inline-end:-14px;width:120px;height:120px;background:var(--saffron);border-radius:var(--r-lg);z-index:-1;opacity:.85}
.values{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-top:1.6rem}.value{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.1rem 1.2rem;transition:.25s}
.value:hover{transform:translateY(-4px);box-shadow:var(--shadow-sm);border-color:var(--turq)}.value h4{font-size:1rem;margin-bottom:.2rem}.value p{color:var(--ink-2);font-size:.85rem}
.auth-wrap{width:min(520px,92%);margin:3.5rem auto;background:var(--surface);border-radius:var(--r-lg);padding:2.6rem;box-shadow:var(--shadow-lg);border:1px solid var(--line)}
.auth-title{font-family:var(--fd);font-size:2rem;margin-bottom:.2rem}.auth-sub{color:var(--ink-2);font-size:.92rem;margin-bottom:1.6rem}.auth-alt{text-align:center;margin-top:1.3rem;font-size:.9rem;color:var(--ink-2)}
.form-field{margin-bottom:1.1rem}.form-field label{display:block;font-weight:700;font-size:.88rem;margin-bottom:.4rem}.form-field .hint{font-weight:400;color:var(--ink-3);font-size:.78rem}
input[type=text],input[type=email],input[type=password],input[type=url],input[type=number],select,textarea{width:100%;font-family:inherit;font-size:.95rem;padding:.75rem 1rem;border:1.5px solid var(--line);border-radius:var(--r-sm);background:#fbfdfc;color:var(--ink);transition:.2s}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--teal);box-shadow:0 0 0 4px rgba(12,127,112,.12);background:#fff}
textarea{min-height:130px;resize:vertical}
.panel-head{display:flex;align-items:center;gap:1.2rem;background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));color:#fff;border-radius:var(--r-lg);padding:2rem 2.2rem;margin-bottom:2rem}
.avatar-circle{width:74px;height:74px;border-radius:50%;background:var(--saffron);color:var(--teal-ink);display:grid;place-items:center;font-family:var(--fd);font-size:1.9rem;flex-shrink:0}
.panel-head h1{font-family:var(--fd);font-size:1.7rem;font-weight:400}.panel-head p{color:#a8d5cb;font-size:.9rem}
.role-badge{display:inline-block;background:rgba(232,163,61,.2);color:var(--saffron);border:1px solid rgba(232,163,61,.4);font-size:.75rem;font-weight:700;padding:.1rem .8rem;border-radius:999px;margin-top:.4rem}
.panel-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.6rem;align-items:start}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.8rem;box-shadow:var(--shadow-sm)}
.card h2{font-family:var(--fd);font-size:1.4rem;margin-bottom:1.1rem;display:flex;align-items:center;gap:.6rem}.card h2::before{content:'';width:8px;height:22px;background:var(--saffron);border-radius:4px}
.info-list{list-style:none}.info-list li{display:flex;justify-content:space-between;gap:1rem;padding:.6rem 0;border-bottom:1px dashed var(--line);font-size:.92rem}.info-list li:last-child{border-bottom:0}.info-list span{color:var(--ink-3)}
.admin-tabs{display:flex;gap:.4rem;border-bottom:2px solid var(--line);margin-bottom:2rem;overflow-x:auto}
.admin-tab{padding:.7rem 1.4rem;font-weight:700;color:var(--ink-3);border-bottom:3px solid transparent;margin-bottom:-2px;white-space:nowrap;transition:.2s}
.admin-tab:hover{color:var(--teal)}.admin-tab.is-active{color:var(--teal);border-color:var(--saffron)}
.stat-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:1.2rem;margin-bottom:2rem}
.stat-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.4rem 1.5rem;position:relative;overflow:hidden;transition:.25s}
.stat-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}.stat-card::before{content:'';position:absolute;top:0;inset-inline-start:0;width:4px;height:100%;background:var(--teal)}
.stat-card.gold::before{background:var(--saffron)}.stat-card.rose::before{background:var(--rose)}.stat-card.turq::before{background:var(--turq)}
.stat-card .num{font-family:var(--fd);font-size:2.2rem;line-height:1.2}.stat-card .lbl{color:var(--ink-3);font-size:.85rem}
.table-wrap{overflow-x:auto;background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md)}
table{width:100%;border-collapse:collapse;min-width:640px}
th{background:#eef4f1;color:var(--ink-2);font-size:.82rem;text-align:right;padding:.9rem 1.1rem;font-weight:700}
td{padding:.85rem 1.1rem;border-top:1px solid var(--line);font-size:.9rem;vertical-align:middle}tr:hover td{background:#f7faf8}
.thumb{width:52px;height:40px;object-fit:cover;border-radius:6px;border:1px solid var(--line)}
.badge{font-size:.74rem;font-weight:700;padding:.15rem .75rem;border-radius:999px;display:inline-block}
.badge-admin{background:rgba(232,163,61,.18);color:var(--saffron-deep)}.badge-user{background:rgba(20,184,166,.14);color:var(--teal-deep)}
.badge-ok{background:rgba(34,197,94,.14);color:#15803d}.badge-no,.badge-draft{background:rgba(148,163,184,.18);color:#64748b}
.row-actions{display:flex;gap:.4rem;flex-wrap:wrap}
.page-title-row{display:flex;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1.6rem;flex-wrap:wrap}.page-title-row h1{font-family:var(--fd);font-size:1.9rem}
.empty-state{text-align:center;padding:3rem 1rem;color:var(--ink-3)}
.user-cell{display:flex;align-items:center;gap:.7rem}.user-cell .mini{width:38px;height:38px;border-radius:50%;background:var(--teal);color:#fff;display:grid;place-items:center;font-family:var(--fd);font-size:1rem;flex-shrink:0}
.contact-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:3rem;align-items:start}
.cta-band{background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));border-radius:var(--r-lg);padding:2.8rem 2.4rem;color:#fff;display:flex;justify-content:space-between;align-items:center;gap:2rem}
.cta-band h2{font-family:var(--fd);font-size:clamp(1.5rem,3.5vw,2.2rem)}.cta-band p{color:#a8d5cb}
.site-footer{background:var(--teal-ink);color:#9fc9c0;margin-top:5rem}
.footer-inner{display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:2.5rem;padding:3.2rem 0 2.2rem}.site-footer .logo{color:#fff}
.footer-links h4{color:#fff;font-size:.95rem;margin-bottom:.8rem}.footer-links a{display:block;color:#9fc9c0;font-size:.88rem;padding:.25rem 0;transition:.2s}.footer-links a:hover{color:var(--saffron);transform:translateX(-4px)}
.footer-bottom{display:flex;justify-content:space-between;gap:1rem;border-top:1px solid rgba(255,255,255,.08);padding:1.2rem 0;font-size:.8rem;flex-wrap:wrap}
.toast-wrap{position:fixed;bottom:1.2rem;inset-inline-start:1.2rem;z-index:1000;display:flex;flex-direction:column;gap:.6rem;max-width:min(340px,90vw)}
.toast{display:flex;align-items:center;gap:.7rem;background:var(--teal-ink);color:#fff;padding:.85rem 1.2rem;border-radius:var(--r-sm);box-shadow:var(--shadow-lg);font-size:.88rem;font-weight:600;opacity:0;transform:translateY(14px);transition:.35s;border-inline-start:4px solid var(--turq)}
.toast.show{opacity:1;transform:none}.toast-success{border-color:#22c55e}.toast-error{border-color:var(--rose)}.toast-info{border-color:var(--turq)}.toast-warning{border-color:var(--saffron)}
.toast-icon{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:.72rem;flex-shrink:0;background:rgba(255,255,255,.14)}
.reveal{opacity:0;transform:translateY(26px);transition:opacity .7s ease,transform .7s ease;transition-delay:var(--d,0s)}.reveal.in{opacity:1;transform:none}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}.reveal{opacity:1;transform:none}}
@media(max-width:980px){
.nav-toggle{display:flex}
.main-nav{position:fixed;inset-block:0;inset-inline-end:0;width:min(320px,84%);background:var(--surface);flex-direction:column;align-items:stretch;padding:5.5rem 1.6rem 2rem;gap:.4rem;transform:translateX(-105%);transition:.35s;box-shadow:var(--shadow-lg);z-index:110}
.main-nav.open{transform:translateX(0)}
.nav-auth{margin:1rem 0 0;padding:1rem 0 0;border-inline-start:0;border-top:1px solid var(--line);flex-wrap:wrap}
.nav-link{font-size:1.05rem;padding:.8rem .6rem}
.hero-grid,.skills-grid,.contact-grid,.panel-grid,.about-grid{grid-template-columns:1fr}
.hero-visual{margin-top:1.5rem}.portfolio-grid,.shop-grid{grid-template-columns:repeat(2,1fr)}
.stats-grid,.stat-cards{grid-template-columns:repeat(2,1fr)}.footer-inner{grid-template-columns:1fr 1fr}.cta-band{flex-direction:column;text-align:center}
}
@media(max-width:620px){.portfolio-grid,.shop-grid,.values{grid-template-columns:1fr}.section{padding:3.6rem 0}.hero{padding:2.8rem 0 4rem}.hero-avatar{width:100px;height:100px;bottom:-1.5rem}.card{padding:1.4rem}.footer-inner{grid-template-columns:1fr}.auth-wrap{padding:1.8rem 1.4rem}.panel-head{flex-direction:column;text-align:center}}
</style>
</head>
<body>
<header class="site-header">
  <div class="scroll-progress" id="scrollProgress"></div>
  <div class="container header-inner">
    <a class="logo" href="<?= url() ?>">مهدی رضایی<i class="logo-dot"></i></a>
    <nav class="main-nav" id="mainNav" aria-label="منوی اصلی">
      <?php foreach($nav as [$p,$label]): ?>
        <a class="nav-link<?= $page===$p?' is-active':'' ?>" href="<?= url($p) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
      <div class="nav-auth">
      <?php if($u): ?>
        <?php if($u['role']==='admin'): ?><a class="btn btn-ghost btn-sm" href="<?= url('admin') ?>">پنل مدیریت</a><?php endif; ?>
        <a class="btn btn-outline btn-sm" href="<?= url('panel') ?>">پنل کاربری</a>
        <form method="post" class="inline-form"><input type="hidden" name="action" value="logout"><?= csrf_field() ?><button class="btn btn-soft btn-sm">خروج</button></form>
      <?php else: ?>
        <a class="btn btn-ghost btn-sm" href="<?= url('login') ?>">ورود</a>
        <a class="btn btn-primary btn-sm" href="<?= url('register') ?>">ثبت‌نام</a>
      <?php endif; ?>
      </div>
    </nav>
    <button class="nav-toggle" id="navToggle" aria-label="منو" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>
<main>
<?php $content(); ?>
</main>
<footer class="site-footer">
  <div class="container footer-inner">
    <div><p class="logo">مهدی رضایی<i class="logo-dot"></i></p><p>ساخت وب‌سایت‌های سریع، امن و زیبا با PHP خالص.</p></div>
    <div class="footer-links"><h4>دسترسی سریع</h4><a href="<?= url('portfolio') ?>">نمونه‌کارها</a><a href="<?= url('shop') ?>">فروشگاه</a><a href="<?= url('contact') ?>">تماس</a></div>
    <div class="footer-links"><h4>ارتباط</h4><a href="mailto:me@mahdirezaei.dev">me@mahdirezaei.dev</a><a href="tel:+989120000000">۰۹۱۲-۰۰-۰۰۰۰</a></div>
  </div>
  <div class="footer-bottom container"><span>© <?= fa_num(date('Y')) ?> مهدی رضایی</span><span>ساخته‌شده با PHP خالص ♥</span></div>
</footer>
<div class="toast-wrap" id="toastWrap" aria-live="polite"></div>
<script>
window.__TOASTS__=<?= json_encode(take_flash(),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG) ?>;
const TI={success:'✓',error:'✕',info:'ℹ',warning:'⚠'};
function showToast(t,m){const w=document.getElementById('toastWrap');const el=document.createElement('div');el.className='toast toast-'+t;el.innerHTML='<span class="toast-icon">'+(TI[t]||'')+'</span><span>'+m+'</span>';w.appendChild(el);requestAnimationFrame(()=>el.classList.add('show'));setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),400)},4200);}
(__TOASTS__||[]).forEach(t=>showToast(t.type,t.message));
const toFa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const navToggle=document.getElementById('navToggle'),mainNav=document.getElementById('mainNav');
navToggle.addEventListener('click',()=>{const o=mainNav.classList.toggle('open');navToggle.classList.toggle('open',o);navToggle.setAttribute('aria-expanded',o);});
mainNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{mainNav.classList.remove('open');navToggle.classList.remove('open');}));
const pb=document.getElementById('scrollProgress');
addEventListener('scroll',()=>{const mx=document.documentElement.scrollHeight-innerHeight;pb.style.width=(mx>0?(scrollY/mx)*100:0)+'%';},{passive:true});
const ro=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');ro.unobserve(e.target);}})},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>ro.observe(el));
const bo=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.style.width=e.target.dataset.level+'%';bo.unobserve(e.target);}})},{threshold:.4});
document.querySelectorAll('.bar-fill').forEach(el=>bo.observe(el));
const co=new IntersectionObserver(es=>{es.forEach(e=>{if(!e.isIntersecting)return;const el=e.target,tg=parseInt(el.dataset.count,10)||0,st=performance.now(),du=1400;const tick=n=>{const p=Math.min((n-st)/du,1);el.textContent=toFa(Math.round(tg*(1-Math.pow(1-p,3))));if(p<1)requestAnimationFrame(tick);};requestAnimationFrame(tick);co.unobserve(el);})},{threshold:.5});
document.querySelectorAll('[data-count]').forEach(el=>co.observe(el));
const roleEl=document.getElementById('roleTyper');
if(roleEl){const roles=JSON.parse(roleEl.dataset.roles||'[]');let ri=0,ci=0,del=false;(function tick(){const w=roles[ri]||'';ci+=del?-1:1;roleEl.textContent=w.slice(0,ci);let d=del?45:95;if(!del&&ci===w.length){d=1800;del=true;}else if(del&&ci===0){del=false;ri=(ri+1)%roles.length;d=350;}setTimeout(tick,d);})();}
const fbs=document.querySelectorAll('.filter-btn');
if(fbs.length){fbs.forEach(b=>b.addEventListener('click',()=>{fbs.forEach(x=>x.classList.remove('is-active'));b.classList.add('is-active');const tg=b.dataset.filter;document.querySelectorAll('.project-card').forEach(c=>{const s=tg==='all'||c.dataset.tags.split(',').includes(tg);c.classList.toggle('is-hidden',!s);});}));}
document.querySelectorAll('form[data-confirm]').forEach(f=>{f.addEventListener('submit',ev=>{if(!confirm(f.dataset.confirm))ev.preventDefault();});});
</script>
<?php clear_old(); ?>
</body>
</html>
<?php }

/* ============================================================
   صفحات
   ============================================================ */
function page_home():void{ layout('صفحهٔ اصلی',function(){ $preview=array_slice(projects(),0,3); ?>
<section class="hero"><div class="container hero-grid">
  <div class="reveal">
    <p class="status-chip"><span class="pulse-dot"></span> آمادهٔ همکاری پروژه‌ای</p>
    <h1 class="hero-name">مهدی <span>رضایی</span></h1>
    <p class="hero-role">من <span id="roleTyper" class="role-typer" data-roles='["توسعه‌دهندهٔ Full-Stack","طراح رابط کاربری","متخصص PHP و MySQL","علاقه‌مند به تجارت الکترونیک"]'></span><span class="caret"></span></p>
    <p class="hero-desc">بیش از ۶ سال است که وب‌سایت‌ها و فروشگاه‌های سریع، امن و قابل‌اتکا می‌سازم؛ از طراحی رابط کاربری تا بک‌اند PHP و دیتابیس.</p>
    <div class="hero-actions"><a class="btn btn-primary" href="<?= url('portfolio') ?>">مشاهدهٔ نمونه‌کارها</a><a class="btn btn-outline" href="<?= url('contact') ?>">تماس با من</a></div>
    <ul class="hero-meta"><li><b>۶+</b> سال تجربه</li><li><b>۴۸</b> پروژهٔ موفق</li><li><b>تهران</b> / ریموت</li></ul>
  </div>
  <div class="hero-visual reveal" style="--d:.15s">
    <div class="terminal"><div class="terminal-bar"><span></span><span></span><span></span><em>developer.php</em></div>
<pre class="terminal-code"><code><span class="tk-c">// developer.php</span>
<span class="tk-k">class</span> <span class="tk-f">Developer</span> {
  <span class="tk-k">public</span> <span class="tk-v">$name</span>  = <span class="tk-s">'Mahdi Rezaei'</span>;
  <span class="tk-k">public array</span> <span class="tk-v">$stack</span> = [<span class="tk-s">'PHP'</span>, <span class="tk-s">'MySQL'</span>, <span class="tk-s">'JS'</span>];
  <span class="tk-k">public function</span> <span class="tk-f">build</span>(<span class="tk-v">$idea</span>) {
    <span class="tk-k">return new</span> <span class="tk-f">Product</span>(<span class="tk-v">$idea</span>); <span class="tk-c">// idea → product</span>
  }
}</code></pre></div>
    <img class="hero-avatar" src="https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/159cf4230-fe5e-4267-9fbc-7395b3870c8d.png" alt="مهدی رضایی">
  </div>
</div></section>
<div class="marquee" aria-hidden="true"><div class="marquee-track">
  <span>HTML5 <i>✦</i> CSS3 <i>✦</i> JavaScript <i>✦</i> PHP <i>✦</i> MySQL <i>✦</i> Laravel <i>✦</i> React <i>✦</i> Tailwind <i>✦</i> Git <i>✦</i> REST API <i>✦</i> UI/UX <i>✦</i></span>
  <span>HTML5 <i>✦</i> CSS3 <i>✦</i> JavaScript <i>✦</i> PHP <i>✦</i> MySQL <i>✦</i> Laravel <i>✦</i> React <i>✦</i> Tailwind <i>✦</i> Git <i>✦</i> REST API <i>✦</i> UI/UX <i>✦</i></span>
</div></div>
<section class="stats-band"><div class="container stats-grid">
  <div class="stat-item reveal"><div class="stat-num"><span data-count="6">۰</span>+</div><div class="stat-label">سال تجربه</div></div>
  <div class="stat-item reveal" style="--d:.1s"><div class="stat-num"><span data-count="48">۰</span></div><div class="stat-label">پروژهٔ تحویل‌شده</div></div>
  <div class="stat-item reveal" style="--d:.2s"><div class="stat-num"><span data-count="32">۰</span></div><div class="stat-label">مشتری راضی</div></div>
  <div class="stat-item reveal" style="--d:.3s"><div class="stat-num"><span data-count="1200">۰</span>+</div><div class="stat-label">فنجان قهوه</div></div>
</div></section>
<section class="section"><div class="container">
  <div class="section-head reveal"><span class="kicker">مهارت‌ها</span><h2 class="section-title">ابزارهایی که با آن‌ها می‌سازم</h2></div>
  <div class="skills-grid">
    <div class="reveal">
      <div class="skill-row"><div class="skill-head"><span>PHP / MySQL</span><b>۹۲٪</b></div><div class="bar"><div class="bar-fill" data-level="92"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>HTML / CSS / Tailwind</span><b>۹۵٪</b></div><div class="bar"><div class="bar-fill" data-level="95"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>JavaScript / React</span><b>۸۵٪</b></div><div class="bar"><div class="bar-fill" data-level="85"></div></div></div>
    </div>
    <div class="reveal" style="--d:.15s">
      <div class="skill-row"><div class="skill-head"><span>طراحی UI/UX (Figma)</span><b>۷۸٪</b></div><div class="bar"><div class="bar-fill" data-level="78"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>Laravel</span><b>۸۸٪</b></div><div class="bar"><div class="bar-fill" data-level="88"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>Git / DevOps پایه</span><b>۷۰٪</b></div><div class="bar"><div class="bar-fill" data-level="70"></div></div></div>
    </div>
  </div>
</div></section>
<section class="section section-alt"><div class="container">
  <div class="section-head reveal"><span class="kicker">مسیر حرفه‌ای</span><h2 class="section-title">تجربهٔ کاری</h2></div>
  <div class="timeline">
    <div class="t-item reveal"><span class="t-date">۱۴۰۱ — اکنون</span><h3>توسعه‌دهندهٔ ارشد Full-Stack — دیجی‌کامرس</h3><p>معماری و توسعهٔ فروشگاه‌های بزرگ و رهبری فنی تیم.</p></div>
    <div class="t-item reveal" style="--d:.1s"><span class="t-date">۱۳۹۸ — ۱۴۰۱</span><h3>توسعه‌دهندهٔ بک‌اند — استارتاپ کارینو</h3><p>طراحی REST API، مدیریت دیتابیس و سیستم پرداخت.</p></div>
    <div class="t-item reveal" style="--d:.2s"><span class="t-date">۱۳۹۷ — ۱۳۹۸</span><h3>توسعه‌دهندهٔ فرانت‌اند — آژانس وب‌یار</h3><p>پیاده‌سازی رابط کاربری ریسپانسیو برای ۲۰+ پروژه.</p></div>
  </div>
</div></section>
<section class="section"><div class="container">
  <div class="section-head reveal"><span class="kicker">نمونه‌کارها</span><h2 class="section-title">گزیده‌ای از پروژه‌های اخیر</h2></div>
  <div class="portfolio-grid">
  <?php foreach($preview as $p): ?>
    <article class="project-card reveal">
      <span class="project-year"><?= e($p['year']) ?></span>
      <div class="project-media"><img src="<?= e($p['image']) ?>" alt="<?= e($p['title']) ?>" loading="lazy"></div>
      <div class="project-body">
        <div class="project-tags"><?php foreach($p['tags'] as $t): ?><span class="tag<?= $t==='shop'?' tag-gold':'' ?>"><?= e(TAG_LABEL[$t]??$t) ?></span><?php endforeach; ?></div>
        <h3><?= e($p['title']) ?></h3><p><?= e($p['desc']) ?></p>
        <a class="project-link" href="<?= url('portfolio') ?>">مشاهدهٔ پروژه</a>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
  <p style="margin-top:2rem" class="reveal"><a class="btn btn-outline" href="<?= url('portfolio') ?>">همهٔ نمونه‌کارها</a></p>
</div></section>
<section class="section"><div class="container">
  <div class="cta-band reveal"><div><h2>ایده‌ای در ذهن دارید؟</h2><p>بیایید دربارهٔ پروژه بعدی‌تان گفت‌وگو کنیم.</p></div><a class="btn btn-saffron" href="<?= url('contact') ?>">شروع همکاری</a></div>
</div></section>
<?php }); }

function page_about():void{ layout('دربارهٔ من',function(){ ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / دربارهٔ من</p><h1>کمی بیشتر دربارهٔ من</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container about-grid">
  <div class="about-photo reveal"><img src="https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/159cf4230-fe5e-4267-9fbc-7395b3870c8d.png" alt="مهدی رضایی"></div>
  <div class="reveal" style="--d:.1s">
    <span class="kicker">معرفی</span>
    <h2 class="section-title">توسعه‌دهنده‌ای که به جزئیات اهمیت می‌دهد</h2>
    <p class="section-lead">من مهدی رضایی هستم؛ توسعه‌دهندهٔ Full-Stack ساکن تهران. عاشق ساخت محصولاتی‌ام که هم زیبا باشند و هم درست کار کنند.</p>
    <div class="values">
      <div class="value"><h4>کد تمیز</h4><p>ساختار ماژولار و قابل نگهداری.</p></div>
      <div class="value"><h4>امنیت اول</h4><p>اعتبارسنجی و دفاع در هر لایه.</p></div>
      <div class="value"><h4>تحویل به‌موقع</h4><p>برنامه‌ریزی شفاف و منظم.</p></div>
      <div class="value"><h4>یادگیری مداوم</h4><p>به‌روز با تکنولوژی‌های روز.</p></div>
    </div>
  </div>
</div></section>
<?php }); }

function page_portfolio():void{ layout('نمونه‌کارها',function(){ $filters=['all'=>'همه','web'=>'وب‌سایت','shop'=>'فروشگاه','app'=>'اپلیکیشن','ui'=>'رابط کاربری']; ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / نمونه‌کارها</p><h1>نمونه‌کارهای من</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <div class="filter-bar reveal"><?php foreach($filters as $k=>$l): ?><button class="filter-btn<?= $k==='all'?' is-active':'' ?>" data-filter="<?= e($k) ?>"><?= e($l) ?></button><?php endforeach; ?></div>
  <div class="portfolio-grid">
  <?php foreach(projects() as $p): ?>
    <article class="project-card reveal" data-tags="<?= e(implode(',',$p['tags'])) ?>">
      <span class="project-year"><?= e($p['year']) ?></span>
      <div class="project-media"><img src="<?= e($p['image']) ?>" alt="<?= e($p['title']) ?>" loading="lazy"></div>
      <div class="project-body">
        <div class="project-tags"><?php foreach($p['tags'] as $t): ?><span class="tag<?= $t==='shop'?' tag-gold':'' ?>"><?= e(TAG_LABEL[$t]??$t) ?></span><?php endforeach; ?></div>
        <h3><?= e($p['title']) ?></h3><p><?= e($p['desc']) ?></p>
        <a class="project-link" href="<?= url('contact') ?>">درخواست مشابه</a>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
</div></section>
<?php }); }

function page_shop():void{ layout('فروشگاه',function(){
  $products=db()->query("SELECT * FROM products WHERE status='published' ORDER BY created_at DESC")->fetchAll(); ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / فروشگاه</p><h1>فروشگاه محصولات دیجیتال</h1><p class="section-lead">این محصولات مستقیم از دیتابیس خوانده می‌شوند و از پنل مدیریت قابل CRUD هستند.</p></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <?php if(!$products): ?><div class="empty-state card">هنوز محصولی منتشر نشده است.</div>
  <?php else: ?><div class="shop-grid">
    <?php foreach($products as $p): ?>
    <article class="product-card reveal">
      <div class="product-media"><img src="<?= e($p['image']??'') ?>" alt="<?= e($p['title']) ?>" loading="lazy">
        <span class="product-stock<?= (int)$p['stock']>0?'':' out' ?>"><?= (int)$p['stock']>0?'موجود':'ناموجود' ?></span></div>
      <div class="product-body">
        <h3><?= e($p['title']) ?></h3><p><?= e(mb_substr((string)$p['description'],0,70)) ?>…</p>
        <div class="product-foot"><span class="price"><?= money($p['price']) ?></span><a class="btn btn-sm btn-primary" href="<?= url('contact') ?>">استعلام سفارش</a></div>
      </div>
    </article>
    <?php endforeach; ?>
  </div><?php endif; ?>
</div></section>
<?php }); }

function page_contact():void{ layout('تماس با من',function(){ ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / تماس با من</p><h1>بیایید گفت‌وگو کنیم</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container contact-grid">
  <div class="reveal">
    <span class="kicker">راه‌های ارتباطی</span><h2 class="section-title">در دسترس‌ام</h2>
    <p class="section-lead">برای پروژه، مشاوره یا حتی یک سلام پیام دهید. پیام‌ها در جدول messages ذخیره و در داشبورد مدیر نمایش داده می‌شوند.</p>
    <ul class="info-list"><li><span>ایمیل</span><b>me@mahdirezaei.dev</b></li><li><span>تلفن</span><b>۰۹۱۲-۰۰-۰۰۰۰</b></li><li><span>تلگرام</span><b>@mahdirezaei</b></li><li><span>موقعیت</span><b>تهران، ایران</b></li></ul>
  </div>
  <div class="card reveal" style="--d:.1s">
    <h2>ارسال پیام</h2>
    <form method="post">
      <input type="hidden" name="action" value="contact"><?= csrf_field() ?>
      <div class="form-field"><label for="c-name">نام شما</label><input id="c-name" type="text" name="name" value="<?= old('name') ?>" required></div>
      <div class="form-field"><label for="c-email">ایمیل</label><input id="c-email" type="email" name="email" value="<?= old('email') ?>" required></div>
      <div class="form-field"><label for="c-subject">موضوع</label><input id="c-subject" type="text" name="subject" value="<?= old('subject') ?>" required></div>
      <div class="form-field"><label for="c-body">پیام</label><textarea id="c-body" name="body" required><?= old('body') ?></textarea></div>
      <button class="btn btn-primary btn-block">ارسال پیام</button>
    </form>
  </div>
</div></section>
<?php }); }

function page_login():void{ layout('ورود',function(){ if(current_user()) redirect(url('panel')); ?>
<div class="auth-wrap reveal">
  <h1 class="auth-title">ورود به حساب</h1>
  <p class="auth-sub">با نام کاربری یا ایمیل خود وارد شوید. (مدیر: admin / Admin@123)</p>
  <form method="post">
    <input type="hidden" name="action" value="login"><?= csrf_field() ?>
    <div class="form-field"><label for="l-id">نام کاربری یا ایمیل</label><input id="l-id" type="text" name="identifier" value="<?= old('identifier') ?>" required autofocus></div>
    <div class="form-field"><label for="l-pass">رمز عبور</label><input id="l-pass" type="password" name="password" required></div>
    <button class="btn btn-primary btn-block">ورود</button>
  </form>
  <p class="auth-alt">حساب ندارید؟ <a href="<?= url('register') ?>">ثبت‌نام کنید</a></p>
</div>
<?php }); }

function page_register():void{ layout('ثبت‌نام',function(){ if(current_user()) redirect(url('panel')); ?>
<div class="auth-wrap reveal">
  <h1 class="auth-title">ساخت حساب کاربری</h1>
  <p class="auth-sub">برای دسترسی به پنل کاربری و خرید از فروشگاه ثبت‌نام کنید.</p>
  <form method="post">
    <input type="hidden" name="action" value="register"><?= csrf_field() ?>
    <div class="form-field"><label for="r-name">نام و نام خانوادگی</label><input id="r-name" type="text" name="name" value="<?= old('name') ?>" required></div>
    <div class="form-field"><label for="r-user">نام کاربری <span class="hint">(انگلیسی)</span></label><input id="r-user" type="text" name="username" value="<?= old('username') ?>" required></div>
    <div class="form-field"><label for="r-email">ایمیل</label><input id="r-email" type="email" name="email" value="<?= old('email') ?>" required></div>
    <div class="form-field"><label for="r-pass">رمز عبور <span class="hint">(حداقل ۸ کاراکتر)</span></label><input id="r-pass" type="password" name="password" required></div>
    <div class="form-field"><label for="r-pass2">تکرار رمز عبور</label><input id="r-pass2" type="password" name="password_confirm" required></div>
    <button class="btn btn-primary btn-block">ثبت‌نام</button>
  </form>
  <p class="auth-alt">حساب دارید؟ <a href="<?= url('login') ?>">وارد شوید</a></p>
</div>
<?php }); }

function page_panel():void{ require_login(); $u=current_user(); layout('پنل کاربری',function()use($u){ ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <div class="panel-head reveal">
    <div class="avatar-circle"><?= e(mb_substr($u['name'],0,1)) ?></div>
    <div><h1>سلام، <?= e($u['name']) ?> 👋</h1><p>عضویت از <?= fa_num(date('Y/m/d',strtotime($u['created_at']))) ?></p>
    <span class="role-badge"><?= $u['role']==='admin'?'مدیر':'کاربر' ?></span></div>
  </div>
  <div class="panel-grid">
    <div class="card reveal"><h2>ویرایش اطلاعات</h2>
      <form method="post"><input type="hidden" name="action" value="profile"><?= csrf_field() ?>
        <div class="form-field"><label for="p-name">نام و نام خانوادگی</label><input id="p-name" type="text" name="name" value="<?= old('name',$u['name']) ?>" required></div>
        <div class="form-field"><label for="p-email">ایمیل</label><input id="p-email" type="email" name="email" value="<?= old('email',$u['email']) ?>" required></div>
        <button class="btn btn-primary btn-block">ذخیره تغییرات</button>
      </form>
    </div>
    <div class="card reveal" style="--d:.1s"><h2>تغییر رمز عبور</h2>
      <form method="post"><input type="hidden" name="action" value="password"><?= csrf_field() ?>
        <div class="form-field"><label for="p-cur">رمز عبور فعلی</label><input id="p-cur" type="password" name="current" required></div>
        <div class="form-field"><label for="p-new">رمز عبور جدید <span class="hint">(حداقل ۸ کاراکتر)</span></label><input id="p-new" type="password" name="password" required></div>
        <div class="form-field"><label for="p-new2">تکرار رمز عبور جدید</label><input id="p-new2" type="password" name="password_confirm" required></div>
        <button class="btn btn-saffron btn-block">به‌روزرسانی رمز</button>
      </form>
    </div>
    <div class="card reveal" style="--d:.2s"><h2>اطلاعات حساب</h2>
      <ul class="info-list">
        <li><span>نام کاربری</span><b><?= e($u['username']) ?></b></li>
        <li><span>نقش</span><b><?= $u['role']==='admin'?'مدیر':'کاربر' ?></b></li>
        <li><span>وضعیت</span><b style="color:#15803d">فعال</b></li>
        <li><span>تاریخ عضویت</span><b><?= fa_num(date('Y/m/d',strtotime($u['created_at']))) ?></b></li>
      </ul>
    </div>
    <div class="card reveal" style="--d:.3s"><h2>دسترسی سریع</h2>
      <div style="display:flex;gap:.6rem;flex-wrap:wrap">
        <a class="btn btn-outline btn-sm" href="<?= url('shop') ?>">فروشگاه</a>
        <a class="btn btn-outline btn-sm" href="<?= url('portfolio') ?>">نمونه‌کارها</a>
        <a class="btn btn-outline btn-sm" href="<?= url('contact') ?>">تماس</a>
      </div>
    </div>
  </div>
</div></section>
<?php }); }

function admin_tabs(string $active):void{ ?>
<div class="admin-tabs">
  <a class="admin-tab<?= $active==='dash'?' is-active':'' ?>" href="<?= url('admin') ?>">داشبورد</a>
  <a class="admin-tab<?= $active==='products'?' is-active':'' ?>" href="<?= url('admin_products') ?>">محصولات</a>
  <a class="admin-tab<?= $active==='users'?' is-active':'' ?>" href="<?= url('admin_users') ?>">کاربران</a>
</div>
<?php }

function page_admin():void{ require_admin(); layout('داشبورد مدیریت',function(){
  $s=['users'=>(int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
      'products'=>(int)db()->query('SELECT COUNT(*) FROM products')->fetchColumn(),
      'messages'=>(int)db()->query('SELECT COUNT(*) FROM messages')->fetchColumn(),
      'unread'=>(int)db()->query('SELECT COUNT(*) FROM messages WHERE is_read=0')->fetchColumn()];
  $recent=db()->query('SELECT * FROM messages ORDER BY created_at DESC LIMIT 5')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('dash'); ?>
  <div class="stat-cards">
    <div class="stat-card reveal"><div class="num"><?= fa_num($s['users']) ?></div><div class="lbl">کل کاربران</div></div>
    <div class="stat-card gold reveal" style="--d:.08s"><div class="num"><?= fa_num($s['products']) ?></div><div class="lbl">محصولات</div></div>
    <div class="stat-card turq reveal" style="--d:.16s"><div class="num"><?= fa_num($s['messages']) ?></div><div class="lbl">پیام‌های تماس</div></div>
    <div class="stat-card rose reveal" style="--d:.24s"><div class="num"><?= fa_num($s['unread']) ?></div><div class="lbl">خوانده‌نشده</div></div>
  </div>
  <div class="page-title-row reveal"><h1>آخرین پیام‌ها</h1><a class="btn btn-primary btn-sm" href="<?= url('product_create') ?>">+ محصول جدید</a></div>
  <?php if(!$recent): ?><div class="empty-state card">هنوز پیامی دریافت نشده است.</div>
  <?php else: ?><div class="table-wrap reveal"><table>
    <thead><tr><th>نام</th><th>موضوع</th><th>تاریخ</th><th>وضعیت</th></tr></thead><tbody>
    <?php foreach($recent as $m): ?><tr>
      <td><?= e($m['name']) ?><br><small style="color:var(--ink-3)"><?= e($m['email']) ?></small></td>
      <td><?= e($m['subject']) ?></td>
      <td><?= fa_num(date('Y/m/d',strtotime($m['created_at']))) ?></td>
      <td><?= (int)$m['is_read']?'<span class="badge badge-ok">خوانده</span>':'<span class="badge badge-no">جدید</span>' ?></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

function page_admin_products():void{ require_admin(); layout('مدیریت محصولات',function(){
  $products=db()->query('SELECT * FROM products ORDER BY created_at DESC')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('products'); ?>
  <div class="page-title-row"><h1>محصولات <span style="color:var(--ink-3);font-size:1rem">(<?= fa_num(count($products)) ?>)</span></h1>
  <a class="btn btn-primary btn-sm" href="<?= url('product_create') ?>">+ محصول جدید</a></div>
  <?php if(!$products): ?><div class="empty-state card">هنوز محصولی ثبت نشده است.</div>
  <?php else: ?><div class="table-wrap"><table>
    <thead><tr><th>تصویر</th><th>عنوان</th><th>قیمت</th><th>موجودی</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($products as $p): ?><tr>
      <td><?= $p['image']?'<img class="thumb" src="'.e($p['image']).'" alt="">':'—' ?></td>
      <td><b><?= e($p['title']) ?></b><br><small style="color:var(--ink-3)"><?= e($p['slug']) ?></small></td>
      <td><?= money($p['price']) ?></td><td><?= fa_num($p['stock']) ?></td>
      <td><?= $p['status']==='published'?'<span class="badge badge-ok">منتشر</span>':'<span class="badge badge-draft">پیش‌نویس</span>' ?></td>
      <td><div class="row-actions">
        <a class="btn btn-outline btn-sm" href="<?= url('product_edit&id='.$p['id']) ?>">ویرایش</a>
        <form method="post" class="inline-form" data-confirm="این محصول حذف شود؟">
          <input type="hidden" name="action" value="product_delete"><?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button>
        </form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

function product_form(?array $editing):void{ layout($editing?'ویرایش محصول':'محصول جدید',function()use($editing){ ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('products'); ?>
  <div class="page-title-row"><h1><?= $editing?'ویرایش محصول':'محصول جدید' ?></h1><a class="btn btn-ghost btn-sm" href="<?= url('admin_products') ?>">بازگشت به لیست</a></div>
  <div class="card"><form method="post">
    <input type="hidden" name="action" value="product_save"><?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($editing['id']??0) ?>">
    <div class="panel-grid">
      <div>
        <div class="form-field"><label for="pr-title">عنوان محصول</label><input id="pr-title" type="text" name="title" value="<?= old('title',$editing['title']??'') ?>" required></div>
        <div class="form-field"><label for="pr-slug">اسلاگ <span class="hint">(اختیاری؛ خودکار ساخته می‌شود)</span></label><input id="pr-slug" type="text" name="slug" value="<?= old('slug',$editing['slug']??'') ?>"></div>
        <div class="form-field"><label for="pr-desc">توضیحات</label><textarea id="pr-desc" name="description"><?= old('description',$editing['description']??'') ?></textarea></div>
      </div>
      <div>
        <div class="form-field"><label for="pr-price">قیمت (تومان)</label><input id="pr-price" type="number" name="price" min="0" value="<?= old('price',(string)($editing['price']??0)) ?>" required></div>
        <div class="form-field"><label for="pr-stock">موجودی</label><input id="pr-stock" type="number" name="stock" min="0" value="<?= old('stock',(string)($editing['stock']??0)) ?>" required></div>
        <div class="form-field"><label for="pr-image">نشانی تصویر <span class="hint">(URL)</span></label><input id="pr-image" type="url" name="image" value="<?= old('image',$editing['image']??'') ?>"></div>
        <div class="form-field"><label for="pr-status">وضعیت</label><select id="pr-status" name="status">
          <?php $cur=old('status',$editing['status']??'published'); ?>
          <option value="published"<?= $cur==='published'?' selected':'' ?>>منتشرشده</option>
          <option value="draft"<?= $cur==='draft'?' selected':'' ?>>پیش‌نویس</option>
        </select></div>
      </div>
    </div>
    <button class="btn btn-primary">ذخیره محصول</button>
  </form></div>
</div></section>
<?php }); }

function page_product_create():void{ require_admin(); product_form(null); }
function page_product_edit():void{ require_admin();
  $st=db()->prepare('SELECT * FROM products WHERE id=? LIMIT 1'); $st->execute([(int)($_GET['id']??0)]); $p=$st->fetch();
  if(!$p){ flash('error','محصول یافت نشد.'); redirect(url('admin_products')); }
  product_form($p);
}

function page_admin_users():void{ require_admin(); layout('مدیریت کاربران',function(){
  $users=db()->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('users'); ?>
  <div class="page-title-row"><h1>کاربران <span style="color:var(--ink-3);font-size:1rem">(<?= fa_num(count($users)) ?>)</span></h1></div>
  <div class="table-wrap"><table>
    <thead><tr><th>کاربر</th><th>ایمیل</th><th>نقش</th><th>وضعیت</th><th>عضویت</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($users as $usr): ?><tr>
      <td><div class="user-cell"><span class="mini"><?= e(mb_substr($usr['name'],0,1)) ?></span>
        <div><b><?= e($usr['name']) ?></b><br><small style="color:var(--ink-3)">@<?= e($usr['username']) ?></small></div></div></td>
      <td><?= e($usr['email']) ?></td>
      <td><?= $usr['role']==='admin'?'<span class="badge badge-admin">مدیر</span>':'<span class="badge badge-user">کاربر</span>' ?></td>
      <td><?= (int)$usr['status']?'<span class="badge badge-ok">فعال</span>':'<span class="badge badge-no">غیرفعال</span>' ?></td>
      <td><?= fa_num(date('Y/m/d',strtotime($usr['created_at']))) ?></td>
      <td><div class="row-actions">
        <form method="post" class="inline-form"><input type="hidden" name="action" value="user_role"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-outline btn-sm"><?= $usr['role']==='admin'?'تبدیل به کاربر':'ارتقا به مدیر' ?></button></form>
        <form method="post" class="inline-form"><input type="hidden" name="action" value="user_status"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-ghost btn-sm"><?= (int)$usr['status']?'غیرفعال‌سازی':'فعال‌سازی' ?></button></form>
        <form method="post" class="inline-form" data-confirm="این کاربر حذف شود؟"><input type="hidden" name="action" value="user_delete"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button></form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div>
</div></section>
<?php }); }

/* ============================================================
   روتر GET
   ============================================================ */
$routes=[
  'home'=>'page_home','about'=>'page_about','portfolio'=>'page_portfolio','shop'=>'page_shop','contact'=>'page_contact',
  'login'=>'page_login','register'=>'page_register','panel'=>'page_panel',
  'admin'=>'page_admin','admin_products'=>'page_admin_products','admin_users'=>'page_admin_users',
  'product_create'=>'page_product_create','product_edit'=>'page_product_edit',
];
$page=$_GET['page']??'home';
$fn=$routes[$page]??'page_home';
$fn();