CREATE DATABASE IF NOT EXISTS portfolio_shop DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_persian_ci;
USE portfolio_shop;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  username VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  status TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  slug VARCHAR(170) NOT NULL,
  description TEXT NULL,
  price DECIMAL(12,0) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  image VARCHAR(500) NULL,
  status ENUM('published','draft') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_products_slug (slug),
  KEY idx_products_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  subject VARCHAR(190) NOT NULL,
  body TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- کاربر مدیر (رمز: Admin@123)
INSERT INTO users (name, username, email, password_hash, role) VALUES
('مهدی رضایی','admin','admin@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');

-- محصولات نمونه
INSERT INTO products (title, slug, description, price, stock, image, status) VALUES
('قالب فروشگاهی آذین','azarin-shop-template','قالب HTML/CSS فروشگاهی راست‌چین، ریسپانسیو و آمادهٔ سفارشی‌سازی.',890000,12,'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/1ddc99331-d21f-4af2-bf64-bae3a4b1c4b9.png','published'),
('اسکریپت مدیریت محتوای سبک','lite-cms-script','اسکریپت PHP سبک برای مدیریت صفحات و مقالات بدون فریم‌ورک سنگین.',1450000,7,'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/11e32c596-af47-4db7-86f5-c24a4d24c582.png','published'),
('کیت رابط کاربری فیروزه','turquoise-ui-kit','بیش از ۸۰ کامپوننت آمادهٔ فیگما به‌همراه خروجی HTML/CSS تمیز.',650000,20,'https://image.qwenlm.ai/public_source/3d24138e-a490-41b6-96b0-1f54d9b39170/116a33a15-51be-4f03-8790-fbf46e670d85.png','published');