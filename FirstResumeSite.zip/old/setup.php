<?php
// یک‌بار بعد از install.sql اجرا شود، سپس حذف شود
$pdo = new PDO('mysql:host=127.0.0.1;dbname=portfolio_shop;charset=utf8mb4', 'root', '',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
if ((int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0) {
    $pdo->prepare('INSERT INTO users (name, username, email, password_hash, role) VALUES (?,?,?,?,?)')
        ->execute(['مهدی رضایی', 'admin', 'admin@example.com', password_hash('Admin@123', PASSWORD_DEFAULT), 'admin']);
    echo '<meta charset="utf-8"><h2>✅ ادمین ساخته شد: admin / Admin@123</h2><p><b>حالا این فایل را حذف کن.</b></p>';
} else {
    echo '<meta charset="utf-8"><p>ادمین از قبل وجود دارد.</p>';
}