<?php
/* ============================================================
   GoldenDevs — نقشهٔ سایت XML (پویا: صفحات ثابت + مقالات + دموها)
   خروجی: /resume/sitemap.php
   ============================================================ */
require __DIR__.'/config.php';

header('Content-Type: application/xml; charset=utf-8');

$scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
$host=(string)($_SERVER['HTTP_HOST']??'localhost');
$dir=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/'))),'/\\');
$base=$scheme.'://'.$host.$dir;

$urls=[];
$add=function(string $loc,string $freq,string $pri,string $last='') use (&$urls){
    $urls[]=['loc'=>$loc,'freq'=>$freq,'pri'=>$pri,'last'=>$last];
};
$add($base.'/', 'weekly','1.0');
$add($base.'/index.php?page=portfolio','monthly','0.8');
$add($base.'/index.php?page=shop','daily','0.9');
$add($base.'/index.php?page=topics','weekly','0.8');
$add($base.'/index.php?page=about','monthly','0.5');
$add($base.'/index.php?page=contact','monthly','0.5');

/* مقالات آموزشی */
$topics=['html5','css3','javascript','php','mysql','seo','security','ui-ux'];
foreach($topics as $t) $add($base.'/index.php?page=topic&t='.urlencode($t),'monthly','0.7');

/* دموها و محصولات منتشرشده */
$rows=[];
try{
    $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $rows=$pdo->query("SELECT id,slug,updated_at FROM products WHERE status='published'")->fetchAll();
}catch(Throwable $e){ $rows=[]; }
foreach($rows as $r){
    $add($base.'/index.php?page=demo&id='.(int)$r['id'],'weekly','0.8',str_replace(' ','T',substr((string)$r['updated_at'],0,19)));
}

echo '<?xml version="1.0" encoding="UTF-8"?>'."\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach($urls as $u): ?>
  <url>
    <loc><?= htmlspecialchars($u['loc'],ENT_QUOTES,'UTF-8') ?></loc>
    <?php if($u['last']!==''): ?><lastmod><?= $u['last'] ?></lastmod><?php endif; ?>
    <changefreq><?= $u['freq'] ?></changefreq>
    <priority><?= $u['pri'] ?></priority>
  </url>
<?php endforeach; ?>
</urlset>
