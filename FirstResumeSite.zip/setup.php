<?php
// قابل اجرا در هر زمان؛ فقط در صورت نبودِ ادمین، یکی می‌سازد
$pdo = new PDO('mysql:host=127.0.0.1;dbname=portfolio_shop;charset=utf8mb4', 'root', '',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

$admins = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();

if ($admins === 0) {
    $pdo->prepare("DELETE FROM users WHERE username='admin' OR email='admin@example.com'")->execute();
    $pdo->prepare('INSERT INTO users (name, username, email, password_hash, role) VALUES (?,?,?,?,?)')
        ->execute(['حسین امیان', 'admin', 'admin@example.com', password_hash('Admin@123', PASSWORD_DEFAULT), 'admin']);
    echo '<meta charset="utf-8" dir="rtl"><h2>ادمین ساخته شد</h2>'
       . '<p>ورود: <b>admin</b> / <b>Admin@123</b></p>'
       . '<p style="color:#b00"><b>حالا این فایل را حذف کنید.</b></p>';
} else {
    echo '<meta charset="utf-8" dir="rtl"><p>' . $admins . ' ادمین فعال وجود دارد؛ نیازی به ساخت نیست.</p>';
} 
// ORD-260730-1BE0F8