CREATE DATABASE IF NOT EXISTS portfolio_shop DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_persian_ci;
USE portfolio_shop;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  username VARCHAR(40) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  status TINYINT(1) NOT NULL DEFAULT 1,
  avatar VARCHAR(500) NULL,
  job_title VARCHAR(100) NULL,
  last_seen DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  slug VARCHAR(170) NOT NULL,
  description TEXT NULL,
  price DECIMAL(12,0) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  image VARCHAR(500) NULL,
  status ENUM('published','draft') NOT NULL DEFAULT 'published',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_products_slug (slug),
  KEY idx_products_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL,
  subject VARCHAR(190) NOT NULL,
  body TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ref_id VARCHAR(20) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  address VARCHAR(500) NOT NULL,
  note TEXT NULL,
  total DECIMAL(12,0) NOT NULL DEFAULT 0,
  status ENUM('pending','paid','shipped','done','cancelled') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_ref (ref_id),
  KEY idx_orders_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  title VARCHAR(150) NOT NULL,
  qty INT UNSIGNED NOT NULL DEFAULT 1,
  price DECIMAL(12,0) NOT NULL DEFAULT 0,
  line_total DECIMAL(12,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_order_items_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS chat_sessions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  token CHAR(32) NOT NULL,
  user_id INT UNSIGNED NULL,
  guest_name VARCHAR(100) NULL,
  guest_email VARCHAR(190) NULL,
  mode ENUM('ai','human') NOT NULL DEFAULT 'ai',
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_chat_sessions_token (token),
  KEY idx_chat_sessions_user (user_id),
  KEY idx_chat_sessions_status (status,updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

CREATE TABLE IF NOT EXISTS chat_messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id INT UNSIGNED NULL,
  user_id INT UNSIGNED NULL,
  role ENUM('user','bot','admin') NOT NULL DEFAULT 'user',
  body TEXT NULL,
  question TEXT NULL,
  answer TEXT NULL,
  seen_by_user TINYINT(1) NOT NULL DEFAULT 0,
  seen_by_admin TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_chat_user (user_id),
  KEY idx_chat_session (session_id,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- کاربر مدیر (رمز اولیه: Admin@123 — بلافاصله پس از نصب عوضش کنید؛ سایت تا تغییر رمز برای مدیر قفل می‌شود)
INSERT INTO users (name, username, email, password_hash, role, job_title) VALUES
('حسین امیان','admin','admin@example.com','$2y$10$.K3ciVMTr0ShvOxmxxibiO7y3xQPRmxrcS2qmvPakWagikfT4k/3S','admin','مدیر و توسعه‌دهنده');

-- محصولات نمونه (تصاویر محلی؛ بعداً با اسکرین‌شات واقعی محصول جایگزین کنید)
INSERT INTO products (title, slug, description, price, stock, image, status) VALUES
('قالب فروشگاهی آذین','azarin-shop-template','قالب HTML/CSS فروشگاهی راست‌چین، ریسپانسیو و آمادهٔ سفارشی‌سازی.',890000,12,'assets/images/product-azarin.svg','published'),
('اسکریپت مدیریت محتوای سبک','lite-cms-script','اسکریپت PHP سبک برای مدیریت صفحات و مقالات بدون فریم‌ورک سنگین.',1450000,7,'assets/images/product-litecms.svg','published'),
('کیت رابط کاربری فیروزه','turquoise-ui-kit','بیش از ۸۰ کامپوننت آمادهٔ فیگما به‌همراه خروجی HTML/CSS تمیز.',650000,20,'assets/images/product-turquoise.svg','published');