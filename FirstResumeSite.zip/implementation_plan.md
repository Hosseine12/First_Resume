# GoldenDevs — Review & Implementation Plan

## خلاصه (Summary)
بررسی عمیق اپ تکفایلی `index.php` (۲۱۰۰+ خط PHP 8 + MySQL) انجام و مجموعهای از بهبودهای امنیتی و UI/UX پیادهسازی شد.

---

## ۱) یافتههای بررسی (Review Findings)

### امنیت — موارد موجود و درست
- **CSP** از قبل فعال است (`default-src 'self'`, nonce برای اسکریپت/استایل `frame-ancestors 'none'`).
- **CSRF** در همهٔ فرمها (`csrf_field` + `verify_csrf`).
- **Rate limit** سشنمحور برای login/chat/contact.
- **RBAC** (`is_admin`, `require_admin`).
- **PDO پارامتری** در همهٔ کوئریها **تراکنش + `SELECT ... FOR UPDATE`** در تسویه برای جلوگیری از منفیشدن موجودی.
- کوکی سشن با `HttpOnly` و `Secure`.

### امنیت — توصیهها / گام بعدی
- رمز عبور پیشفرض ادمین (`Admin@123`) باید اجباری عوض شود (تغییر در اولین ورود یا از طریق SQL).
- کلیدهای AI خالیاند (`AI_ENABLED=false`) بهتر است از متغیر محیطی خوانده شوند نه ثابت در کد.
- اعتبار DB هنوز بهصورت ثابت در فایل است توصیه میشود به `config.php` + `.env` منتقل شود و از repository خارج شود.

### UI/UX
- SVG از قبل در جاهای زیادی استفاده میشود (favicon آیکن سبد/چت/قلب پسزمینه).
- در بخشهای محتوایی (کارت محصول آمار کیکرها منو) ایموجی وجود نداشت → اضافه شد.
- منوی موبایل کشویی داشت ولی منوی دسکتاپ بخش «آموزش/موضوعات/ارتباط» را مخفی میکرد → با منوی کشویی «بیشتر» یکسان شد.
- کشوی موبایل بخشهای تکمیلی را نشان نمیداد (باگ اولویت CSS) → اصلاح شد.

### سبد خرید و موجودی
- منطق سمت سرور درست است: تعداد محدود به موجودی (`cart_add`/`cart_set`) دکمهٔ «+» هنگام رسیدن به موجودی غیرفعال و تراکنش FOR UPDATE.
- ولی UI به کاربر «نزدیک بودن به انتهای موجودی» را نشان نمیداد → نشان کمموجودی و هشدار داخل سبد اضافه شد.

---

## ۲) تغییرات اعمالشده (Changes Applied)
1. **ایموجی در منوی اصلی**: 🏠 خانه / 👤 دربارهٔ من / 🗂 نمونهکارها / 🛒 فروشگاه / 📚 آموزش / 📬 تماس با من.
2. **منوی کشویی دسکتاپ «بیشتر ▾»**: در دسکتاپ (≥۹۸۱px) بخش موضوعات دسترسی سریع و اطلاعات تماس بهصورت منوی کشویی نمایش داده میشود همان محتوایی که موبایل دارد.
3. **منوی موبایل غنیتر**: بخشهای تکمیلی (موضوعات دسترسی سریع جزئیات تماس) هم در کشوی موبایل نمایش داده میشود.
4. **ایموجی در کیکرها و آمار**: «🖼️ نمونهکارها» «👋 معرفی» «📬 راههای ارتباطی» آمار hero با 🎯🚀📍.
5. **نشان وضعیت موجودی در فروشگاه**: 🟢 موجود / 🔴 ناموجود در موجودی کم (≤۵) پسزمینهٔ نارنجی (`.low`).
6. **هشدار موجودی داخل سبد**: وقتی موجودی ≤۵ زیر عنوان محصول «📦 فقط N تا در انبار مانده» نمایش داده میشود.
7. **ایموجی در فوتر** و عنوانهای منوی کشویی (📚⚡💬).

---

## ۳) فایلهای مرتبط
- `index.php` — تغییرات UI/UX اعمال و با `php -l` تایید شد (بدون خطای syntax).
- `.htaccess` — موجود برای هدرهای امنیتی تکمیلی (+CSP بهعنوان redundant) و محافظت از db/config در صورت استقرار روی Apache.

---

## ۴) گامهای بعدی پیشنهادی (Next Steps)
- [ ] تغییر اجباری رمز ادمین پیشفرض.
- [ ] انتقال اعتبار DB و کلیدهای AI به `config.php`/`.env`.
- [ ] هدرهای `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy` در `.htaccess`.
- [ ] تست end-to-end (ورود ← فروشگاه ← سبد ← تسویه ← پرداخت ← پنل) روی XAMPP.
- [ ] بررسی جایگزینی تصاویر PNG خارجی نمونهکارها با SVG محلی/آپلود.

++ if u need any tools or skills install it and open my current chrome browser window and check the ui,ux,etc like an
full-stack dev and cybersecurity engineer and tell me what can u see (i know that current model dosnt support vison ) a
nd check all of pages,buttons and forms and etc works good and have a good conection with my db(check front fisrt and t
hen, check back) and in mobile mode, we have a hamburger menu and in desktop viwe, we have different menu and i think t
he moble menu is better for both mode (u can see menu in the codes or resize the window or f12 or any way u think bette
r and faster for this task ) and my cline is open now but my last chat and sesstion for task isnot open r u sure u can
see the real plan,task mode status? its not important now and u can create a todo list or rules or etc for yourself or
continue from last cp and u need to check mobile menu why isnot working good(blur other parts but dosnot have options b
ut desktop mode have it and and u should be fix that ) and if u need tell me anything in persian letters im in terminal
 and it will bad render in this mode so writee a explains or etc in a md or txt file and tell me reade that...

## ۵) وضعیت امروز (verify & fix)
- ✅ **باگ منوی موبایل رفع شد (مرحله ۱).** ریشه: `backdrop-filter:blur(10px)` روی `.site-header` باعث می‌شد کشوی `position:fixed` فقط داخل هدر (~115px) قفل شود → blur/بکدراپ می‌اومد ولی آپشن‌ها (1122px محتوا) داخل یک نوار 115px اسکرول می‌شدن و دیده نمی‌شدن. با حذف backdrop-filter از هدر، کشو به ارتفاع کامل صفحه باز شد.
- ✅ **منوی یکپارچه PC+موبایل (مرحله ۲ — خواستهٔ جدید).** آیکن همبرگری ☰ کنار لوگو در همه عرض‌ها + کشوی تمام‌قد از سمت راست (RTL)؛ دکمهٔ «بیشتر» و dropdown دسکتاپ حذف شد. کشو همیشه بسته لود می‌شه؛ ESC/بک‌دراپ/کلیک‌لینک می‌بندهش؛ پرش اسکرول‌بار با `scrollbar-gutter:stable` رفع شد؛ لینک‌های تکراری منو (نمونه‌کارها/فروشگاه/تماس/همهٔ موضوعات + هدر دسترسی‌سریع) حذف شدن (فوتر دست‌نخورده). ~۴۰ خط CSS/JS مرده پاک شد؛ `php -l` OK. تست خودکار 390px+1440px با اسکرین‌شات: کشو flush-right تمام‌قد، همه گزینه‌ها با اسکرول داخلی، هر ۸ صفحه HTTP 200 بدون خطای PHP.
- ✅ چک فرانت+بک+دیتابیس روی `http://localhost/resume/`: همهٔ صفحات 200، دادهٔ واقعی از DB رندر می‌شه (۱۰ پروژه / ۶ محصول / ۱۲ موضوع)، فرم ورود + CSRF سالم، هدرهای امنیتی فعال.
- 📋 گزارش کامل فارسی توی `_report_fa.md`.
- ⏳ باقی مونده از گام‌های `implementation_plan.md`: تغییر اجباری رمز ادمین، انتقال اعتبار به .env/config، تست E2E پرداخت، جایگزینی PNG با SVG.
- 💡 تقسیم کار پیشنهادی: کد/ادیت → Cline؛ تست UI/DB → Hermes (مرورگر خودکار).