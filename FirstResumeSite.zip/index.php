﻿<?php
/* ============================================================
   GoldenDevs — Portfolio + Shop (PHP 8 + MySQL)
   برند: گلدن‌دِوز | توسعه‌دهنده: حسین امیان
   ============================================================ */
require __DIR__.'/config.php'; /* دیتابیس و کلیدها خارج از سورس اصلی */
/* ---- برند ---- */
const BRAND_NAME='GoldenDevs', BRAND_FA='گلدن‌دِوز', OWNER_NAME='حسین امیان', BRAND_SLOGAN='توسعه‌دهندگان طلایی';
/* ---- دستیار هوشمند ---- */
const BOT_NAME='زرین';
/* ---- AI: مقادیر در config.php (کلیدها فقط سمت سرور) ---- */
/* حافظهٔ گفتگو */
const AI_MEMORY_TURNS=5;
/* پوشهٔ دانش و لاگ */
const KB_DIR=__DIR__.'/kb', CHAT_LOG_DIR=__DIR__.'/storage/chat-logs';
/* جواب‌های پیشفرض چت */
const AI_PLACEHOLDER='دستیار هوشمند هنوز به سرویس پاسخ‌گویی وصل نشده. لطفاً سوالات متداول رو ببین یا «گفتگو با پشتیبانی انسانی» رو انتخاب کن.';
const AI_UNKNOWN='این مورد در اطلاعاتی که دارم نیست و نمی‌خوام حدس بزنم. اجازه بده به پشتیبانی انسانی وصلت کنم.';
const FAQ=[
 ['q'=>'چطوری خرید کنم؟','a'=>'محصول رو به سبد اضافه کن، اطلاعات تسویه رو ثبت کن و پرداخت (شبیهسازی) رو انجام بده. سفارش از «پنل کاربری ← سفارشهای من» قابل پیگیریه.'],
 ['q'=>'پرداخت چطور انجام میشه؟','a'=>'فعلاً درگاه شبیهسازی‌شده است و هیچ تراکنش واقعی انجام نمیشه. بهزودی به درگاه بانکی واقعی وصل میشه.'],
 ['q'=>'کالاهای دیجیتال چطور تحویل داده میشن؟','a'=>'بعد از تأیید سفارش، لینک دانلود در صفحهٔ سفارشها قرار میگیره.'],
 ['q'=>'میتونم سفارشم رو لغو کنم؟','a'=>'تا قبل از پردازش بله؛ از طریق فرم تماس درخواست بده.'],
 ['q'=>'چطور پروژه سفارش بدم؟','a'=>'از فرم تماس یا شمارهٔ داخل فوتر پیام بده؛ یک جلسهٔ کوتاه برای بررسی نیازها برگزار میکنیم و بعد از توافق، پروژه شروع میشه.'],
 ['q'=>'زمان تحویل پروژه چقدره؟','a'=>'بستگی به دامنهٔ کار داره؛ سایت تک‌صفحه‌ای چند روز، فروشگاه کامل چند هفته. بعد از بررسی نیازها زمان دقیق اعلام میشه.'],
 ['q'=>'پشتیبانی بعد از تحویل دارید؟','a'=>'بله، رفع اشکال‌های مربوط به تحویل رایگانه و توسعهٔ امکانات جدید طبق توافق جداگانه انجام میشه.'],
];
/* ---- موضوعات آموزشی/بلاگ (برای SEO؛ هر مورد یک صفحهٔ داخلی) ---- */
const TOPICS=[
 'html5'=>['title'=>'HTML5','lead'=>'ساختار معنایی، دسترس‌پذیری و پایهٔ سئوی فنی.','body'=>'HTML5 پایهٔ هر صفحهٔ وب است. استفاده از تگ‌های معنایی مثل header، nav، main، article و footer به مرورگر، صفحه‌خوان و موتور جست‌وجو می‌گوید هر بخش چه نقشی دارد. همین انتخاب‌های ساده، هم دسترس‌پذیری را بالا می‌برد و هم سئوی فنی را.'],
 'css3'=>['title'=>'CSS3','lead'=>'چیدمان مدرن با Grid و Flexbox، متغیرها و انیمیشن روان.','body'=>'CSS3 با Flexbox و Grid کار چیدمان را از هک‌های قدیمی نجات داد. متغیرهای CSS نگهداری تم را ساده می‌کنند و با clamp() می‌توان تایپوگرافی واقعاً ریسپانسیو ساخت. برای پروژه‌های راست‌چین، خصوصیت‌های منطقی مثل margin-inline و inset-inline-end بهترین انتخاب‌اند.'],
 'javascript'=>['title'=>'JavaScript','lead'=>'تعامل سمت کلاینت بدون کند کردن صفحه.','body'=>'جاوااسکریپت وقتی بهترین نتیجه را می‌دهد که کم و هدفمند نوشته شود. IntersectionObserver جای اسکرول‌لیسنرهای سنگین را می‌گیرد، fetch جایگزین درخواست‌های قدیمی می‌شود و افزودن رفتار روی HTMLِ ازپیش‌رندرشده باعث می‌شود صفحه بدون جاوااسکریپت هم کار کند.'],
 'php'=>['title'=>'PHP','lead'=>'بک‌اند سریع و امن با PHP مدرن.','body'=>'PHP 8 با تایپ‌های سخت‌گیرانه، match و ویژگی‌های تازه، زبان جدی و تمیزی است. الگوی درست: اعتبارسنجی ورودی، استفاده از PDO با کوئری پارامتری، اجرای منطق حساس (قیمت، موجودی) فقط سمت سرور و هرگز اعتماد به دادهٔ فرم.'],
 'mysql'=>['title'=>'MySQL','lead'=>'طراحی جدول، ایندکس و تراکنش‌های درست.','body'=>'کیفیت کوئری‌ها به طراحی جدول بستگی دارد. برای فارسی از utf8mb4 استفاده کنید، روی ستون‌های شرط و join ایندکس بگذارید و برای عملیات چندمرحله‌ای مثل ثبت سفارش از تراکنش و SELECT ... FOR UPDATE استفاده کنید تا موجودی منفی نشود.'],
 'seo'=>['title'=>'سئوی فنی','lead'=>'سرعت، ساختار و داده‌های ساخت‌یافته.','body'=>'سئوی فنی یعنی کمک به موتور جست‌وجو برای فهم صفحه: تگ عنوان و توضیحات یکتا، یک H1 در هر صفحه، URL خوانا، لینک داخلی معنادار، تصاویر با alt و سرعت بارگذاری بالا. افزودن JSON-LD هم به نمایش بهتر در نتایج کمک می‌کند.'],
 'security'=>['title'=>'امنیت وب','lead'=>'CSRF، XSS، تزریق SQL و سخت‌سازی هدرها.','body'=>'امنیت لایه‌لایه است: توکن CSRF روی هر فرم، خروجی escape‌شده برای جلوگیری از XSS، کوئری پارامتری برای جلوگیری از SQL Injection، هش رمز با password_hash، محدودسازی تلاش‌ها و هدرهایی مثل CSP و X-Content-Type-Options.'],
 'ui-ux'=>['title'=>'UI/UX','lead'=>'رابط قابل‌فهم، دسترس‌پذیر و بدون سردرگمی.','body'=>'تجربهٔ کاربری خوب از وضوح می‌آید: سلسله‌مراتب بصری روشن، بازخورد فوری برای هر عمل، اندازهٔ لمسی مناسب موبایل، کنتراست کافی و احترام به prefers-reduced-motion. رابط باید مسیر بعدی کاربر را واضح نشان دهد.'],
];
const DUMMY_HASH='$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

function db(): PDO {
    static $pdo=null;
    if($pdo===null){
        try{ $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
        }catch(PDOException $e){ http_response_code(500); exit('خطا در اتصال به دیتابیس. ابتدا install.sql را اجرا کنید.'); }
    }
    return $pdo;
}
/* ساخت خودکار جدول‌های فروشگاه */
function ensure_schema():void{
    db()->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        ref_id VARCHAR(30) NOT NULL,
        total DECIMAL(12,0) NOT NULL DEFAULT 0,
        status ENUM('pending','paid','shipped','done','cancelled') NOT NULL DEFAULT 'paid',
        phone VARCHAR(20) NULL, address TEXT NULL, note TEXT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_orders_ref (ref_id),
        KEY idx_orders_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    db()->exec("CREATE TABLE IF NOT EXISTS order_items (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        order_id INT UNSIGNED NOT NULL,
        product_id INT UNSIGNED NOT NULL,
        title VARCHAR(150) NOT NULL,
        qty INT NOT NULL DEFAULT 1,
        price DECIMAL(12,0) NOT NULL DEFAULT 0,
        KEY idx_oi_order (order_id),
        KEY idx_oi_product (product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    db()->exec("CREATE TABLE IF NOT EXISTS chat_messages (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    /* گفتگوهای دنباله‌دار: هر نشست یک ردیف، هر پیام یک ردیف در chat_messages */
    db()->exec("CREATE TABLE IF NOT EXISTS chat_sessions (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        token CHAR(32) NOT NULL,
        user_id INT UNSIGNED NULL,
        guest_name VARCHAR(100) NULL,
        guest_email VARCHAR(190) NULL,
        mode ENUM('ai','human') NOT NULL DEFAULT 'ai',
        status ENUM('open','closed') NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_chat_sessions_token (token),
        KEY idx_chat_sessions_user (user_id),
        KEY idx_chat_sessions_status (status,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    /* مهاجرت chat_messages به ساختار نشست‌محور (سازگار با نسخهٔ قدیمی) */
    $st=db()->prepare("SELECT COLUMN_NAME,IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_messages'");
    $st->execute(); $cols=[]; foreach($st->fetchAll() as $r){ $cols[$r['COLUMN_NAME']]=$r['IS_NULLABLE']; }
    if(!isset($cols['session_id'])) try{ db()->exec("ALTER TABLE chat_messages ADD COLUMN session_id INT UNSIGNED NULL AFTER id, ADD KEY idx_chat_session (session_id,id)"); }catch(PDOException $e){}
    if(!isset($cols['role']))       try{ db()->exec("ALTER TABLE chat_messages ADD COLUMN role ENUM('user','bot','admin') NOT NULL DEFAULT 'user' AFTER user_id"); }catch(PDOException $e){}
    if(!isset($cols['body']))       try{ db()->exec("ALTER TABLE chat_messages ADD COLUMN body TEXT NULL AFTER role"); }catch(PDOException $e){}
    if(!isset($cols['seen_by_user']))  try{ db()->exec("ALTER TABLE chat_messages ADD COLUMN seen_by_user TINYINT(1) NOT NULL DEFAULT 0"); }catch(PDOException $e){}
    if(!isset($cols['seen_by_admin'])) try{ db()->exec("ALTER TABLE chat_messages ADD COLUMN seen_by_admin TINYINT(1) NOT NULL DEFAULT 0"); }catch(PDOException $e){}
    if(($cols['question']??'YES')==='NO') try{ db()->exec("ALTER TABLE chat_messages MODIFY question TEXT NULL"); }catch(PDOException $e){}
    if(($cols['answer']??'YES')==='NO')   try{ db()->exec("ALTER TABLE chat_messages MODIFY answer TEXT NULL"); }catch(PDOException $e){}
    /* دسترس‌پذیری ادمین‌ها برای نمایش در ویجت چت */
    $st=db()->prepare("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users'");
    $st->execute(); $ucols=array_column($st->fetchAll(),'COLUMN_NAME');
    if(!in_array('avatar',$ucols,true))    try{ db()->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(500) NULL"); }catch(PDOException $e){}
    if(!in_array('job_title',$ucols,true)) try{ db()->exec("ALTER TABLE users ADD COLUMN job_title VARCHAR(100) NULL"); }catch(PDOException $e){}
    if(!in_array('last_seen',$ucols,true)) try{ db()->exec("ALTER TABLE users ADD COLUMN last_seen DATETIME NULL"); }catch(PDOException $e){}
    /* افزودن ایندکس به DBهای نسخهٔ قدیمی (اگر از قبل نباشد) */
    $st=db()->prepare("SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders'");
    $st->execute(); $idx=array_column($st->fetchAll(),'INDEX_NAME');
    if(!in_array('uq_orders_ref',$idx,true)){ try{ db()->exec("ALTER TABLE orders ADD UNIQUE KEY uq_orders_ref (ref_id)"); }catch(PDOException $e){} }
    if(!in_array('idx_orders_user',$idx,true)){ try{ db()->exec("ALTER TABLE orders ADD KEY idx_orders_user (user_id)"); }catch(PDOException $e){} }
    /* سیستم لایسنس و سریال‌نامبر */
    db()->exec("CREATE TABLE IF NOT EXISTS licenses (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        product_id INT UNSIGNED NOT NULL,
        order_id INT UNSIGNED NULL,
        serial VARCHAR(40) NOT NULL,
        max_activations INT UNSIGNED NOT NULL DEFAULT 3,
        expires_at DATE NULL,
        status ENUM('active','revoked','expired') NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_licenses_serial (serial),
        KEY idx_licenses_product (product_id),
        KEY idx_licenses_order (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
    db()->exec("CREATE TABLE IF NOT EXISTS activations (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        license_id INT UNSIGNED NOT NULL,
        domain VARCHAR(250) NOT NULL,
        ip VARCHAR(45) NULL,
        activated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_activations_license (license_id),
        KEY idx_activations_domain (domain)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");
}

if(session_status()===PHP_SESSION_NONE){
    ini_set('session.use_strict_mode','1');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','httponly'=>true,'samesite'=>'Lax',
        'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')]);
    session_start();
}
/* ---------- هدرهای امنیتی ---------- */
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
if(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

ensure_schema();

/* ---------- کمکی‌ها ---------- */
function e(?string $v):string{ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function fa_num($v):string{ return str_replace(range('0','9'),['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],(string)$v); }
function money($p):string{ return fa_num(number_format((float)$p)).' تومان'; }
/* ---------- تاریخ شمسی ---------- */
function to_jalali(int $ts):array{
    $gy=(int)date('Y',$ts); $gm=(int)date('n',$ts); $gd=(int)date('j',$ts);
    $gdm=[0,31,59,90,120,151,181,212,243,273,304,334];
    $gy2=($gm>2)?($gy+1):$gy;
    $days=355666+365*$gy+intdiv($gy2+3,4)-intdiv($gy2+99,100)+intdiv($gy2+399,400)+$gd+$gdm[$gm-1];
    $jy=-1595+33*intdiv($days,12053); $days%=12053;
    $jy+=4*intdiv($days,1461); $days%=1461;
    if($days>365){ $jy+=intdiv($days-1,365); $days=($days-1)%365; }
    if($days<186){ $jm=1+intdiv($days,31); $jd=1+($days%31); }
    else{ $jm=7+intdiv($days-186,30); $jd=1+(($days-186)%30); }
    return [$jy,$jm,$jd];
}
function adate(?string $ts_str,bool $with_time=false):string{
    $ts=strtotime((string)$ts_str); if(!$ts) return '—';
    [$jy,$jm,$jd]=to_jalali($ts);
    $mn=['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
    $s=fa_num($jd).' '.$mn[$jm].' '.fa_num($jy);
    if($with_time) $s.=' — '.fa_num(date('H:i',$ts));
    return $s;
}
function j_year():string{ return fa_num(to_jalali(time())[0]); }
/* آدرس canonical برای سئو (بدون پارامترهای اضافی) */
function canonical_url():string{
    $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
    $host=(string)($_SERVER['HTTP_HOST']??'localhost');
    $path=(string)(parse_url((string)($_SERVER['REQUEST_URI']??'/'),PHP_URL_PATH)?:'/');
    $keep=[];
    foreach(['page','t','id'] as $k) if(isset($_GET[$k])&&$_GET[$k]!=='') $keep[$k]=(string)$_GET[$k];
    return $scheme.'://'.$host.$path.($keep?'?'.http_build_query($keep):'');
}
/* نشانی پایهٔ سایت (برای تصاویر در دادهٔ ساخت‌یافته) */
function site_base_url():string{
    $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
    $host=(string)($_SERVER['HTTP_HOST']??'localhost');
    $dir=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/'))),'/\\');
    return $scheme.'://'.$host.$dir;
}
function redirect(string $to):void{ header('Location: '.$to); exit; }
function url(string $page=''):string{ return $page===''?'index.php':'index.php?page='.$page; }
function slugify(string $t):string{ $t=preg_replace('/[^\p{L}\p{N}_\-]+/u','-',trim($t)); return trim((string)preg_replace('/-{2,}/','-',$t),'-'); }
function flash(string $type,string $msg):void{ $_SESSION['_flash'][]=['type'=>$type,'message'=>$msg]; }
function take_flash():array{ $i=$_SESSION['_flash']??[]; unset($_SESSION['_flash']); return $i; }
function keep_old():void{ $d=$_POST; unset($d['password'],$d['password_confirm'],$d['current'],$d['csrf'],$d['action']); $_SESSION['_old']=$d; }
function old(string $k,string $d=''):string{ return e((string)($_SESSION['_old'][$k]??$d)); }
function clear_old():void{ unset($_SESSION['_old']); }
function csp_nonce():string{ static $n=null; if($n===null) $n=bin2hex(random_bytes(16)); return $n; }

function csrf_token():string{ if(empty($_SESSION['_csrf'])) $_SESSION['_csrf']=bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field():string{ return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf():void{
    if(!hash_equals((string)($_SESSION['_csrf']??''),(string)($_POST['csrf']??''))){
        flash('error','خطای اعتبارسنجی فرم (CSRF).'); redirect(url());
    }
}
function safe_redirect_url(string $to):string{
    if(preg_match('#^index\.php([?#].*)?$#',$to)||$to===''||$to[0]==='/') return $to;
    return url();
}
/* ---------- Rate Limit (سشنمحور) ---------- */
function rate_limit(string $key,int $max=5,int $window=900):bool{
    $k='_rl_'.$key; $now=time();
    $attempts=array_filter($_SESSION[$k]??[],fn($t)=>$t>$now-$window);
    if(count($attempts)>=$max){ $_SESSION[$k]=$attempts; return false; }
    $attempts[]=$now; $_SESSION[$k]=$attempts; return true;
}

function validate(array $data,array $rules):array{
    $errors=[];
    foreach($rules as $f=>$set){
        $v=trim((string)($data[$f]??''));
        foreach(preg_split('/[|,]/',$set) as $r){
            $r=trim($r); if($r==='') continue;
            [$n,$p]=array_pad(explode(':',$r,2),2,null);
            if($n!=='required'&&$v==='') continue;
            switch($n){
                case 'required': if($v==='') $errors[$f][]='این فیلد الزامی است.'; break;
                case 'email': if(!filter_var($v,FILTER_VALIDATE_EMAIL)) $errors[$f][]='ایمیل معتبر نیست.'; break;
                case 'min': if(mb_strlen($v)<(int)$p) $errors[$f][]='حداقل '.fa_num($p).' کاراکتر لازم است.'; break;
                case 'max': if(mb_strlen($v)>(int)$p) $errors[$f][]='حداکثر '.fa_num($p).' کاراکتر مجاز است.'; break;
                case 'numeric': if(!is_numeric($v)) $errors[$f][]='مقدار باید عددی باشد.'; break;
                case 'phone': if(!preg_match('/^09\d{9}$/',preg_replace('/[^0-9]/','',$v))) $errors[$f][]='شمارهٔ موبایل معتبر نیست (مثال: 09123456789).'; break;
                case 'username': if(!preg_match('/^[A-Za-z0-9_]{3,40}$/',$v)) $errors[$f][]='نام کاربری فقط حروف انگلیسی، عدد و _.'; break;
                case 'url': if(!filter_var($v,FILTER_VALIDATE_URL)) $errors[$f][]='نشانی تصویر معتبر نیست.'; break;
            }
        }
    }
    return $errors;
}
function dump_errors(array $errors):void{ foreach($errors as $l) foreach($l as $m) flash('error',$m); }

/* ---------- احراز هویت و RBAC ---------- */
function current_user():?array{
    static $u=false;
    if($u===false){
        $u=null;
        if(!empty($_SESSION['user_id'])){
            $st=db()->prepare('SELECT id,name,username,email,role,status,created_at FROM users WHERE id=? LIMIT 1');
            $st->execute([(int)$_SESSION['user_id']]);
            $row=$st->fetch();
            if($row && (int)$row['status']===1) $u=$row; else { session_destroy(); $_SESSION=[]; }
        }
    }
    return $u;
}
function is_admin():bool{ $u=current_user(); return $u && $u['role']==='admin'; }
/* ثبت آخرین فعالیت ادمین (حداکثر هر ۶۰ ثانیه) برای نشانگر آنلاین در ویجت چت */
function touch_admin_presence():void{
    $u=current_user();
    if(!$u || $u['role']!=='admin') return;
    if((int)($_SESSION['_seen_at']??0) > time()-60) return;
    $_SESSION['_seen_at']=time();
    try{ db()->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$u['id']]); }catch(Throwable $e){}
}
function login_user(array $u):void{ session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; }
function logout_user():void{ $_SESSION=[]; if(ini_get('session.use_cookies')) setcookie(session_name(),'',time()-3600,'/'); session_destroy(); }
function require_login():void{ if(!current_user()){ flash('error','ابتدا وارد شوید.'); redirect(url('login')); } }
function require_admin():void{ require_login(); if(!is_admin()){ flash('error','دسترسی غیرمجاز.'); redirect(url('panel')); } }

/* ---------- سبد خرید (Session) ---------- */
function cart():array{ return $_SESSION['cart']??[]; }
function cart_count():int{ return array_sum(array_map('intval',cart())); }
function stock_of(int $id):int{
    $st=db()->prepare('SELECT stock FROM products WHERE id=? AND status="published" LIMIT 1');
    $st->execute([$id]); $s=$st->fetchColumn(); return $s===false?0:(int)$s;
}
function cart_add(int $id,int $qty=1):void{
    $cur=max(0,(int)($_SESSION['cart'][$id]??0));
    $_SESSION['cart'][$id]=min($cur+max(1,$qty),max($cur,stock_of($id)),99);
    if($_SESSION['cart'][$id]<=0) unset($_SESSION['cart'][$id]);
}
function cart_set(int $id,int $qty):void{
    if($qty<=0){ unset($_SESSION['cart'][$id]); return; }
    $_SESSION['cart'][$id]=min($qty,stock_of($id),99);
    if($_SESSION['cart'][$id]<=0) unset($_SESSION['cart'][$id]);
}
function cart_remove(int $id):void{ unset($_SESSION['cart'][$id]); }
function cart_items():array{
    static $cache=null;
    if($cache!==null) return $cache;
    $cache=[];
    $c=cart(); if(!$c) return $cache;
    $ids=array_map('intval',array_keys($c));
    $marks=implode(',',array_fill(0,count($ids),'?'));
    $st=db()->prepare("SELECT * FROM products WHERE id IN ($marks) AND status='published'");
    $st->execute($ids);
    foreach($st->fetchAll() as $r){ $cache[]=['p'=>$r,'qty'=>min((int)$c[(int)$r['id']],(int)$r['stock'],99)]; }
    return $cache;
}
function cart_total():float{ $t=0; foreach(cart_items() as $i) $t+=(float)$i['p']['price']*$i['qty']; return $t; }

/* ---------- دادهٔ نمونه‌کارها ---------- */
function projects():array{ return [
 ['title'=>'فروشگاه اینترنتی فروشینو','tags'=>['shop','web'],'year'=>'۱۴۰۳','desc'=>'فروشگاه کامل با سبد خرید، درگاه پرداخت و پنل مدیریت.','image'=>'assets/images/project-foroushino.svg'],
 ['title'=>'اپلیکیشن مدیریت کارها «کارینو»','tags'=>['app','ui'],'year'=>'۱۴۰۳','desc'=>'اپ موبایل برای مدیریت وظایف روزانه و تقویم تیمی.','image'=>'assets/images/project-karino.svg'],
 ['title'=>'سامانهٔ رزرو رستوران زعفران','tags'=>['web','ui'],'year'=>'۱۴۰۲','desc'=>'وب‌سایت رزرو میز با منوی دیجیتال و پنل مدیریت شعب.','image'=>'assets/images/project-zaferan.svg'],
 ['title'=>'پلتفرم آموزش آنلاین دانشجو','tags'=>['web','app'],'year'=>'۱۴۰۲','desc'=>'سامانهٔ دوره‌های ویدیویی با آزمون، گواهی و پنل مدرس.','image'=>'assets/images/project-daneshjo.svg'],
 ['title'=>'کیف پول دیجیتال آفتاب','tags'=>['app'],'year'=>'۱۴۰۱','desc'=>'اپ فین‌تک با انتقال وجه و احراز هویت دومرحله‌ای.','image'=>'assets/images/project-aos.svg'],
 ['title'=>'سامانهٔ رزرو سفر سفرنیک','tags'=>['web','shop'],'year'=>'۱۴۰۱','desc'=>'پلتفرم رزرو تور و اقامتگاه با جستجوی پیشرفته.','image'=>'assets/images/project-safarnik.svg'],
];}
const TAG_LABEL=['shop'=>'فروشگاه','web'=>'وب‌سایت','app'=>'اپلیکیشن','ui'=>'رابط کاربری'];
/* برچسب و تگ کارت‌های دموی صفحهٔ اصلی بر اساس اسلاگ محصول */
const DEMO_TYPE=[
 'azarin-shop-template'=>['label'=>'قالب فروشگاهی','tags'=>['RTL','سبد خرید','ریسپانسیو']],
 'lite-cms-script'=>['label'=>'اسکریپت PHP','tags'=>['MySQL','پنل مدیریت','سبک']],
 'turquoise-ui-kit'=>['label'=>'کیت رابط کاربری','tags'=>['Design Tokens','HTML/CSS','۸۰+ کامپوننت']],
];
const ORDER_STATUS=['pending'=>'در انتظار','paid'=>'پرداخت‌شده','shipped'=>'ارسال‌شده','done'=>'تحویل‌شده','cancelled'=>'لغو‌شده'];

/* ============================================================
   گفتگوی دنباله‌دار: نشست، حافظه، لاگ JSON و دانشِ دستیار
   ============================================================ */
/* نشست جاری را برمی‌گرداند؛ فقط در صورت نیاز می‌سازد. */
function chat_session(bool $create=false):?array{
    static $cache=null;
    if($cache!==null && !$create) return $cache;
    $tok=(string)($_SESSION['chat_token']??'');
    if($tok!==''){
        $st=db()->prepare('SELECT * FROM chat_sessions WHERE token=? LIMIT 1');
        $st->execute([$tok]);
        if($row=$st->fetch()){
            /* اگر کاربر بعد از شروع گفتگو وارد شد، نشست به او متصل شود */
            $me=current_user();
            if($me && $row['user_id']===null){
                db()->prepare('UPDATE chat_sessions SET user_id=? WHERE id=?')->execute([$me['id'],$row['id']]);
                $row['user_id']=$me['id'];
            }
            return $cache=$row;
        }
    }
    if(!$create) return $cache=null;
    $me=current_user();
    $tok=bin2hex(random_bytes(16));
    db()->prepare('INSERT INTO chat_sessions (token,user_id,mode) VALUES (?,?,?)')->execute([$tok,$me?$me['id']:null,'ai']);
    $_SESSION['chat_token']=$tok;
    $st=db()->prepare('SELECT * FROM chat_sessions WHERE token=? LIMIT 1');
    $st->execute([$tok]);
    return $cache=$st->fetch()?:null;
}
/* یک پیام را در گفتگو ثبت می‌کند. */
function chat_log_message(int $sid,string $role,string $body):int{
    $role=in_array($role,['user','bot','admin'],true)?$role:'user';
    db()->prepare('INSERT INTO chat_messages (session_id,user_id,role,body,question,answer,seen_by_user,seen_by_admin) VALUES (?,?,?,?,?,?,?,?)')
        ->execute([$sid,($u=current_user())?$u['id']:null,$role,$body,
                   $role==='user'?$body:null,$role==='user'?null:$body,
                   $role==='user'?1:0,$role==='user'?0:1]);
    $mid=(int)db()->lastInsertId();
    db()->prepare('UPDATE chat_sessions SET updated_at=NOW() WHERE id=?')->execute([$sid]);
    return $mid;
}
/* آخرین پیام‌های گفتگو برای نمایش و برای حافظهٔ مدل. */
function chat_history(int $sid,int $limit=50):array{
    $st=db()->prepare('SELECT id,role,body,created_at FROM chat_messages WHERE session_id=? ORDER BY id ASC LIMIT '.max(1,$limit));
    $st->execute([$sid]);
    return $st->fetchAll();
}
/* لاگ JSON کوچک برای هر گفتگو (قابل استفاده به‌عنوان بکاپ/مرور دستی). */
function chat_write_json_log(array $sess,array $turns):void{
    if(!is_dir(CHAT_LOG_DIR) && !@mkdir(CHAT_LOG_DIR,0775,true)) return;
    $file=CHAT_LOG_DIR.'/'.preg_replace('/[^a-f0-9]/','',$sess['token']).'.json';
    $payload=['token'=>$sess['token'],'user_id'=>$sess['user_id'],'mode'=>$sess['mode'],
              'updated_at'=>date('c'),'turns'=>array_map(fn($t)=>['role'=>$t['role'],'body'=>$t['body'],'at'=>$t['created_at']],$turns)];
    @file_put_contents($file,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),LOCK_EX);
    /* محافظت از پوشهٔ لاگ در صورت قرارگیری زیر document root */
    $ht=CHAT_LOG_DIR.'/.htaccess';
    if(!is_file($ht)) @file_put_contents($ht,"Require all denied\n");
}
/* دانشِ دستیار: محصولات واقعی + فایل‌های kb/ (txt|md|csv|json). PDF/Excel باید به متن تبدیل شوند. */
function ai_knowledge():string{
    $parts=[];
    try{
        $rows=db()->query("SELECT title,price,stock,description FROM products WHERE status='published' ORDER BY id")->fetchAll();
        if($rows){
            $lines=[];
            foreach($rows as $r){
                $lines[]='- '.$r['title'].' | قیمت: '.number_format((float)$r['price']).' تومان | موجودی: '.(int)$r['stock']
                        .' | توضیح: '.mb_substr(trim((string)$r['description']),0,220);
            }
            $parts[]="فهرست محصولات فعلی فروشگاه:\n".implode("\n",$lines);
        }
    }catch(Throwable $e){}
    $faq=[];
    foreach(FAQ as $f) $faq[]='- پرسش: '.$f['q'].' | پاسخ: '.$f['a'];
    if($faq) $parts[]="سوالات متداول:\n".implode("\n",$faq);
    if(is_dir(KB_DIR)){
        foreach(glob(KB_DIR.'/*.{txt,md,csv,json}',GLOB_BRACE)?:[] as $f){
            $txt=trim((string)@file_get_contents($f));
            if($txt!=='') $parts[]='فایل دانش «'.basename($f).'»:'."\n".mb_substr($txt,0,6000);
        }
    }
    return implode("\n\n",$parts);
}
/* پرامپت سیستمی: فقط بر پایهٔ دانشِ داده‌شده پاسخ بده، حدس نزن. */
function ai_system_prompt():string{
    $kb=ai_knowledge();
    $p="تو «".BOT_NAME."» هستی، دستیار هوشمند ".BRAND_NAME." (وب‌سایت ".OWNER_NAME.").\n"
      ."قواعد پاسخ‌گویی:\n"
      ."۱) فقط بر پایهٔ «اطلاعات مرجع» زیر پاسخ بده.\n"
      ."۲) اگر پاسخ در اطلاعات مرجع نبود، صریح بگو نمی‌دانی و پیشنهاد بده کاربر به پشتیبانی انسانی وصل شود. هرگز قیمت، زمان تحویل، موجودی یا هر عدد را حدس نزن یا از خودت نساز.\n"
      ."۳) فارسی، کوتاه، محترمانه و بدون اغراق بنویس.\n"
      ."۴) وعدهٔ مالی یا حقوقی نده و شرایط جدید از خودت اضافه نکن.\n";
    $p.="\n=== اطلاعات مرجع ===\n".($kb!==''?$kb:'(اطلاعات مرجعی ثبت نشده است.)')."\n=== پایان اطلاعات مرجع ===";
    return $p;
}
/* فراخوانی سرویس AI با حافظهٔ چند پیام آخر. */
function ai_reply(string $question,array $turns):?string{
    if(!AI_ENABLED||AI_API_URL==='') return null;
    $key=AI_API_KEY!=='' ? AI_API_KEY : (trim((string)@file_get_contents(__DIR__.'/c.txt')) ?: '');
    if($key==='') return null;
    $msgs=[['role'=>'system','content'=>ai_system_prompt()]];
    $mem=array_slice($turns,-1*max(1,AI_MEMORY_TURNS*2));
    foreach($mem as $t){
        if(($t['body']??'')==='') continue;
        $msgs[]=['role'=>$t['role']==='user'?'user':'assistant','content'=>(string)$t['body']];
    }
    $msgs[]=['role'=>'user','content'=>$question];
    $ctx=stream_context_create(['http'=>['method'=>'POST','timeout'=>25,'ignore_errors'=>true,
        'header'=>"Content-Type: application/json\r\nAuthorization: Bearer $key\r\n",
        'content'=>json_encode(['model'=>AI_MODEL,'messages'=>$msgs,'temperature'=>0.2],JSON_UNESCAPED_UNICODE)]]);
    $raw=@file_get_contents(AI_API_URL,false,$ctx);
    if($raw===false) return null;
    $data=json_decode($raw,true);
    $ans=trim((string)($data['choices'][0]['message']['content'] ?? ''));
    return $ans!==''?$ans:null;
}
/* ادمین‌های قابل نمایش در هدر ویجت چت (۵ دقیقه = آنلاین). */
function support_agents():array{
    try{
        $rows=db()->query("SELECT name,avatar,job_title,last_seen FROM users WHERE role='admin' AND status=1 ORDER BY (last_seen IS NULL), last_seen DESC LIMIT 4")->fetchAll();
    }catch(Throwable $e){ return []; }
    foreach($rows as &$r){
        $ts=$r['last_seen']?strtotime((string)$r['last_seen']):0;
        $r['online']=$ts>0 && (time()-$ts)<300;
        $r['initial']=mb_substr(trim((string)$r['name']),0,1);
    }
    return $rows;
}

/* ============================================================
   رسیدگی به POSTها
   ============================================================ */
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $action=$_POST['action']??'';

    if($action==='logout'){ logout_user(); session_start(); flash('info','با موفقیت خارج شدید.'); redirect(url()); }

    /* ---------- ویجت چت: دستیار هوشمند + پشتیبانی انسانی ---------- */
    if(in_array($action,['ask_ai','chat_start','chat_send','chat_poll'],true)){
        header('Content-Type: application/json;charset=utf-8');
        header('Cache-Control: no-store');
        $json=function(bool $ok,array $extra=[],string $msg=''):void{
            echo json_encode(['ok'=>$ok,'message'=>$msg]+$extra,JSON_UNESCAPED_UNICODE); exit;
        };
        if(($_SERVER['HTTP_X_REQUESTED_WITH']??'')!=='XMLHttpRequest') $json(false);

        /* شروع/تعیین حالت گفتگو: هوش مصنوعی یا پشتیبانی انسانی */
        if($action==='chat_start'){
            $mode=($_POST['mode']??'ai')==='human'?'human':'ai';
            $sess=chat_session(true);
            if(!$sess) $json(false,[],'ایجاد گفتگو ممکن نشد.');
            if($sess['mode']!==$mode){
                db()->prepare('UPDATE chat_sessions SET mode=?,status=? WHERE id=?')->execute([$mode,'open',$sess['id']]);
                $sess['mode']=$mode;
            }
            if($mode==='human'){
                $name=trim((string)($_POST['name']??'')); $email=trim((string)($_POST['email']??''));
                if($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) $json(false,[],'ایمیل معتبر نیست.');
                if($name!==''||$email!==''){
                    db()->prepare('UPDATE chat_sessions SET guest_name=?,guest_email=? WHERE id=?')
                        ->execute([mb_substr($name,0,100)?:null,mb_substr($email,0,190)?:null,$sess['id']]);
                }
                if(!chat_history($sess['id'],1)){
                    chat_log_message((int)$sess['id'],'bot','پیامت ثبت شد و برای تیم پشتیبانی ارسال میشه. هر وقت پاسخ بدن، همینجا می‌بینی.');
                }
            }
            $hist=chat_history((int)$sess['id'],80);
            $json(true,['mode'=>$sess['mode'],'history'=>array_map(fn($t)=>['id'=>(int)$t['id'],'role'=>$t['role'],'body'=>(string)$t['body'],'at'=>adate($t['created_at'],true)],$hist)]);
        }

        /* دریافت پیام‌های جدید (پاسخ ادمین در حالت انسانی) */
        if($action==='chat_poll'){
            $sess=chat_session();
            if(!$sess) $json(true,['mode'=>'ai','messages'=>[]]);
            $after=(int)($_POST['after']??0);
            $st=db()->prepare('SELECT id,role,body,created_at FROM chat_messages WHERE session_id=? AND id>? ORDER BY id ASC LIMIT 50');
            $st->execute([$sess['id'],$after]);
            $rows=$st->fetchAll();
            if($rows) db()->prepare('UPDATE chat_messages SET seen_by_user=1 WHERE session_id=? AND role<>? AND id<=?')
                          ->execute([$sess['id'],'user',(int)end($rows)['id']]);
            $json(true,['mode'=>$sess['mode'],'messages'=>array_map(fn($t)=>['id'=>(int)$t['id'],'role'=>$t['role'],'body'=>(string)$t['body'],'at'=>adate($t['created_at'],true)],$rows)]);
        }

        /* ارسال پیام کاربر */
        $q=trim((string)($_POST['q']??''));
        if($q===''||mb_strlen($q)>2000) $json(false,[],'متن پیام معتبر نیست.');

        if($action==='chat_send'){ /* حالت پشتیبانی انسانی */
            if(!rate_limit('chat_human',30,900)) $json(false,[],'تعداد پیامها زیاد است؛ چند دقیقه دیگر تلاش کن.');
            $sess=chat_session(true);
            if(!$sess) $json(false,[],'ثبت پیام ممکن نشد.');
            if($sess['mode']!=='human'){ db()->prepare('UPDATE chat_sessions SET mode=? WHERE id=?')->execute(['human',$sess['id']]); $sess['mode']='human'; }
            $mid=chat_log_message((int)$sess['id'],'user',$q);
            chat_write_json_log($sess,chat_history((int)$sess['id'],200));
            $json(true,['mode'=>'human','id'=>$mid]);
        }

        /* حالت دستیار هوشمند */
        if(!rate_limit('chat',20,900)) $json(false,[],'تعداد سوالها زیاد است؛ چند دقیقه دیگر دوباره بپرس.');
        $sess=chat_session(true);
        if(!$sess) $json(false,[],'ثبت گفتگو ممکن نشد.');
        if($sess['mode']!=='ai'){ db()->prepare('UPDATE chat_sessions SET mode=? WHERE id=?')->execute(['ai',$sess['id']]); $sess['mode']='ai'; }
        $turns=chat_history((int)$sess['id'],AI_MEMORY_TURNS*2);
        chat_log_message((int)$sess['id'],'user',$q);
        $ans=ai_reply($q,$turns) ?? AI_PLACEHOLDER;
        $mid=chat_log_message((int)$sess['id'],'bot',$ans);
        chat_write_json_log($sess,chat_history((int)$sess['id'],200));
        $json(true,['mode'=>'ai','id'=>$mid],$ans);
    }

    if($action==='register'){
        if(!rate_limit('register',10,900)){ flash('error','تعداد تلاشها زیاد است؛ چند دقیقه دیگر تلاش کنید.'); redirect(url('register')); }
        $errors=validate($_POST,['name'=>'required|max:100','username'=>'required|username','email'=>'required|email|max:190','password'=>'required|min:8|max:200']);
        if(trim($_POST['password']??'')!==trim($_POST['password_confirm']??'')) $errors['password_confirm'][]='تکرار رمز مطابقت ندارد.';
        if(!$errors){
            $st=db()->prepare('SELECT id FROM users WHERE username=? OR email=? LIMIT 1');
            $st->execute([trim($_POST['username']),trim($_POST['email'])]);
            if($st->fetch()) $errors['username'][]='این نام کاربری یا ایمیل قبلاً ثبت شده.';
        }
        if(!$errors){
            db()->prepare('INSERT INTO users (name,username,email,password_hash,role) VALUES (?,?,?,?,?)')
                ->execute([trim($_POST['name']),trim($_POST['username']),trim($_POST['email']),password_hash($_POST['password'],PASSWORD_DEFAULT),'user']);
            login_user(['id'=>db()->lastInsertId()]);
            flash('success','ثبت‌نام انجام شد. خوش آمدید!'); redirect(url('panel'));
        }
        dump_errors($errors); keep_old(); redirect(url('register'));
    }

    if($action==='login'){
        if(!rate_limit('login',5,600)){ flash('error','تعداد تلاشهای ورود زیاد است؛ ۱۰ دقیقه دیگر تلاش کنید.'); keep_old(); redirect(url('login')); }
        $id=trim($_POST['identifier']??''); $pass=$_POST['password']??'';
        $st=db()->prepare('SELECT * FROM users WHERE username=? OR email=? LIMIT 1');
        $st->execute([$id,$id]); $u=$st->fetch();
        $ok=$u ? password_verify($pass,$u['password_hash']) : password_verify($pass,DUMMY_HASH);
        if(!$u||!$ok){ flash('error','اطلاعات ورود اشتباه است.'); keep_old(); redirect(url('login')); }
        if((int)$u['status']!==1){ flash('error','حساب شما غیرفعال شده است.'); redirect(url('login')); }
        unset($_SESSION['_rl_login']);
        login_user($u); flash('success','خوش آمدید، '.$u['name'].'!');
        /* اگر رمز مدیر هنوز همان رمز پیش‌فرض نصب است، تا تغییر نکند بقیهٔ سایت قفل می‌شود */
        if($u['role']==='admin' && password_verify('Admin@123',$u['password_hash'])){
            $_SESSION['must_change_pw']=true;
            flash('warning','امنیت: رمز عبور شما هنوز پیش‌فرض نصب است. لطفاً همین حالا تغییرش دهید.');
            redirect(url('panel'));
        }
        redirect($u['role']==='admin'?url('admin'):url('panel'));
    }

    if($action==='contact'){
        if(!rate_limit('contact',5,900)){ flash('error','تعداد پیامها زیاد است؛ کمی بعد تلاش کنید.'); redirect(url('contact')); }
        $errors=validate($_POST,['name'=>'required|max:100','email'=>'required|email','subject'=>'required|max:190','body'=>'required|max:3000']);
        if(!$errors){
            db()->prepare('INSERT INTO messages (name,email,subject,body) VALUES (?,?,?,?)')
                ->execute([trim($_POST['name']),trim($_POST['email']),trim($_POST['subject']),trim($_POST['body'])]);
            flash('success','پیام شما ارسال شد.');
        } else { dump_errors($errors); keep_old(); }
        redirect(url('contact'));
    }

    /* ----- سبد خرید ----- */
    if($action==='add_to_cart'){
        $pid=(int)($_POST['id']??0);
        $st=db()->prepare('SELECT stock FROM products WHERE id=? AND status="published" LIMIT 1'); $st->execute([$pid]);
        $stock=$st->fetchColumn();
        if($stock===false){ flash('error','محصول یافت نشد.'); redirect(url('shop')); }
        if((int)$stock<=0){ flash('warning','این محصول ناموجود است.'); redirect(url('shop')); }
        cart_add($pid,1);
        flash('success','به سبد خرید اضافه شد.');
        redirect(url('shop'));
    }
    if($action==='cart_update'){
        foreach((array)($_POST['qty']??[]) as $pid=>$q) cart_set((int)$pid,(int)$q);
        flash('success','سبد خرید بهروزرسانی شد.');
        redirect(url('cart'));
    }
    if($action==='cart_remove'){ cart_remove((int)($_POST['id']??0)); flash('info','از سبد حذف شد.'); redirect(url('cart')); }

    /* ----- تسویه‌حساب و پرداخت ----- */
    if($action==='checkout_info'){
        require_login();
        if(!cart_items()){ flash('error','سبد خرید خالیه.'); redirect(url('shop')); }
        $errors=validate($_POST,['phone'=>'required|phone','address'=>'required|min:10|max:500','note'=>'max:500']);
        if($errors){ dump_errors($errors); keep_old(); redirect(url('checkout')); }
        $_SESSION['checkout_info']=['phone'=>trim($_POST['phone']),'address'=>trim($_POST['address']),'note'=>trim($_POST['note']??'')];
        redirect(url('payment'));
    }
    if($action==='pay'){
        require_login();
        if(!rate_limit('pay',10,900)){ flash('error','تعداد تلاشها زیاد است؛ کمی بعد تلاش کنید.'); redirect(url('cart')); }
        $me=current_user();
        $info=$_SESSION['checkout_info']??[];
        if(!isset($info['phone'],$info['address'])){ flash('error','ابتدا اطلاعات تسویه را کامل کنید.'); redirect(url('checkout')); }
        $pdo=db(); $pdo->beginTransaction(); $oid=0;
        try{
            $c=cart(); if(!$c) throw new RuntimeException('empty');
            /* قفل ردیفها تا در پرداخت همزمان، بیش از موجودی فروش نرود */
            $ids=array_map('intval',array_keys($c));
            $marks=implode(',',array_fill(0,count($ids),'?'));
            $st=$pdo->prepare("SELECT id,title,price,stock,status FROM products WHERE id IN ($marks) FOR UPDATE");
            $st->execute($ids);
            $rows=[]; foreach($st->fetchAll() as $r){ $rows[(int)$r['id']]=$r; }
            $items=[]; $total=0;
            foreach($ids as $pid){
                $r=$rows[$pid]??null;
                if(!$r || $r['status']!=='published') throw new RuntimeException('unavailable');
                $qty=min((int)$c[$pid],(int)$r['stock'],99);
                if($qty<=0) throw new RuntimeException('nostock:'.$r['title']);
                $qty=max($qty,1);
                $items[]=[$pid,(string)$r['title'],$qty,(float)$r['price']];
                $total+=(float)$r['price']*$qty;
            }
            $ref='ORD-'.date('ymd').'-'.strtoupper(substr(bin2hex(random_bytes(3)),0,6));
            $pdo->prepare('INSERT INTO orders (user_id,ref_id,total,status,phone,address,note) VALUES (?,?,?,?,?,?,?)')
                ->execute([(int)$me['id'],$ref,$total,'paid',$info['phone'],$info['address'],substr($info['note']??'',0,2000)]);
            $oid=(int)$pdo->lastInsertId();
            $ins=$pdo->prepare('INSERT INTO order_items (order_id,product_id,title,qty,price) VALUES (?,?,?,?,?)');
            $dec=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?');
            foreach($items as [$pid,$title,$qty,$price]){
                $ins->execute([$oid,$pid,$title,$qty,$price]);
                $dec->execute([$qty,$pid,$qty]);
            }
            $pdo->commit();
        }catch(Throwable $ex){
            if($pdo->inTransaction()) $pdo->rollBack();
            $m=$ex->getMessage();
            flash('error',str_starts_with($m,'nostock:')?'موجودی کافی نیست: «'.substr($m,8).'»':'خطا در ثبت سفارش.');
            redirect(url('cart'));
        }
        unset($_SESSION['cart'],$_SESSION['checkout_info']);
        flash('success','پرداخت با موفقیت انجام شد!');
        redirect(url('order_success&id='.$oid));
    }
    if($action==='cancel_pay'){ unset($_SESSION['checkout_info']); flash('info','پرداخت لغو شد.'); redirect(url('cart')); }

    if($action==='order_status'){
        require_admin();
        $s=$_POST['status']??'paid';
        if(array_key_exists($s,ORDER_STATUS)){
            db()->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$s,(int)($_POST['id']??0)]);
            flash('success','وضعیت سفارش تغییر کرد.');
        }
        redirect(url('admin_orders'));
    }

    if($action==='profile'){
        require_login(); $me=current_user();
        $errors=validate($_POST,['name'=>'required|max:100','email'=>'required|email']);
        if(!$errors){
            $st=db()->prepare('SELECT id FROM users WHERE email=? AND id<>? LIMIT 1');
            $st->execute([trim($_POST['email']),$me['id']]);
            if($st->fetch()) $errors['email'][]='این ایمیل توسط کاربر دیگری استفاده شده.';
        }
        if(!$errors){ db()->prepare('UPDATE users SET name=?,email=? WHERE id=?')->execute([trim($_POST['name']),trim($_POST['email']),$me['id']]); flash('success','اطلاعات به‌روزرسانی شد.'); }
        else { dump_errors($errors); keep_old(); }
        redirect(url('panel'));
    }
    if($action==='password'){
        require_login(); $me=current_user();
        $errors=validate($_POST,['current'=>'required','password'=>'required|min:8']);
        if(trim($_POST['password']??'')!==trim($_POST['password_confirm']??'')) $errors['password_confirm'][]='تکرار رمز مطابقت ندارد.';
        if($errors){ dump_errors($errors); redirect(url('panel')); }
        $st=db()->prepare('SELECT password_hash FROM users WHERE id=?'); $st->execute([$me['id']]);
        if(!password_verify($_POST['current'],$st->fetchColumn())) flash('error','رمز فعلی اشتباه است.');
        else { db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($_POST['password'],PASSWORD_DEFAULT),$me['id']]); unset($_SESSION['must_change_pw']); flash('success','رمز عبور تغییر کرد.'); }
        redirect(url('panel'));
    }

    if($action==='product_save'){
        require_admin();
        $id=(int)($_POST['id']??0);
        $errors=validate($_POST,['title'=>'required|max:150','price'=>'required|numeric','stock'=>'required|numeric','image'=>'url|max:500']);
        if((float)($_POST['price']??0)<0) $errors['price'][]='قیمت منفی مجاز نیست.';
        if((int)($_POST['stock']??0)<0) $errors['stock'][]='موجودی منفی مجاز نیست.';
        if($errors){ dump_errors($errors); keep_old(); redirect(url($id?'product_edit&id='.$id:'product_create')); }
        $title=trim($_POST['title']);
        $slug=slugify(trim($_POST['slug']??''))?:slugify($title); $base=$slug; $i=1;
        $st=db()->prepare('SELECT id FROM products WHERE slug=? AND id<>? LIMIT 1');
        while(true){ $st->execute([$slug,$id]); if(!$st->fetch()) break; $slug=$base.'-'.(++$i); }
        $params=[$title,$slug,trim($_POST['description']??''),(float)$_POST['price'],(int)$_POST['stock'],
                 trim($_POST['image']??'')?:null,($_POST['status']??'published')==='draft'?'draft':'published'];
        if($id>0){ $params[]=$id; db()->prepare('UPDATE products SET title=?,slug=?,description=?,price=?,stock=?,image=?,status=? WHERE id=?')->execute($params); flash('success','محصول ویرایش شد.'); }
        else { db()->prepare('INSERT INTO products (title,slug,description,price,stock,image,status) VALUES (?,?,?,?,?,?,?)')->execute($params); flash('success','محصول ثبت شد.'); }
        redirect(url('admin_products'));
    }
    if($action==='product_delete'){
        require_admin();
        db()->prepare('DELETE FROM products WHERE id=?')->execute([(int)($_POST['id']??0)]);
        flash('success','محصول حذف شد.'); redirect(url('admin_products'));
    }

    if(in_array($action,['user_role','user_status','user_delete'],true)){
        require_admin(); $me=current_user();
        $tid=(int)($_POST['id']??0);
        $st=db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1'); $st->execute([$tid]); $t=$st->fetch();
        if(!$t) flash('error','کاربر یافت نشد.');
        elseif($tid===(int)$me['id']) flash('error','این عملیات روی خودتان مجاز نیست.');
        elseif($action==='user_role'){
            if($t['role']==='admin'){
                $n=(int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status=1")->fetchColumn();
                if($n<=1) flash('error','حداقل یک مدیر فعال باید بماند.');
                else { db()->prepare('UPDATE users SET role=? WHERE id=?')->execute(['user',$tid]); flash('success','نقش تغییر کرد.'); }
            } else { db()->prepare('UPDATE users SET role=? WHERE id=?')->execute(['admin',$tid]); flash('success','به مدیر ارتقا یافت.'); }
        }
        elseif($action==='user_status'){ db()->prepare('UPDATE users SET status=1-status WHERE id=?')->execute([$tid]); flash('success','وضعیت تغییر کرد.'); }
        elseif($action==='user_delete'){ db()->prepare('DELETE FROM users WHERE id=?')->execute([$tid]); flash('success','کاربر حذف شد.'); }
        redirect(url('admin_users'));
    }

    if(in_array($action,['message_read','message_unread','message_delete','chat_delete','chat_session_delete','chat_reply'],true)){
        require_admin();
        $tid=(int)($_POST['id']??0);
        if($action==='chat_reply'){
            $sid=(int)($_POST['session_id']??0);
            $body=trim((string)($_POST['body']??''));
            $st=db()->prepare('SELECT id FROM chat_sessions WHERE id=? LIMIT 1'); $st->execute([$sid]);
            if(!$st->fetch()) flash('error','گفتگو یافت نشد.');
            elseif($body===''||mb_strlen($body)>2000) flash('error','متن پاسخ معتبر نیست.');
            else{
                db()->prepare("INSERT INTO chat_messages (session_id,user_id,role,body,answer,seen_by_user,seen_by_admin) VALUES (?,?,'admin',?,?,0,1)")
                    ->execute([$sid,current_user()['id'],$body,$body]);
                db()->prepare("UPDATE chat_sessions SET mode='human',updated_at=NOW() WHERE id=?")->execute([$sid]);
                flash('success','پاسخ ارسال شد.');
            }
            redirect(url('admin_messages').'&s='.$sid);
        }
        if($action==='chat_session_delete'){
            db()->prepare('DELETE FROM chat_messages WHERE session_id=?')->execute([$tid]);
            db()->prepare('DELETE FROM chat_sessions WHERE id=?')->execute([$tid]);
            flash('success','گفتگو حذف شد.');
        }
        elseif($action==='chat_delete'){ db()->prepare('DELETE FROM chat_messages WHERE id=?')->execute([$tid]); flash('success','پیام گفتگو حذف شد.'); }
        elseif($action==='message_delete'){ db()->prepare('DELETE FROM messages WHERE id=?')->execute([$tid]); flash('success','پیام حذف شد.'); }
        elseif($action==='message_read'){ db()->prepare('UPDATE messages SET is_read=1 WHERE id=?')->execute([$tid]); flash('success','پیام خوانده شد.'); }
        else { db()->prepare('UPDATE messages SET is_read=0 WHERE id=?')->execute([$tid]); flash('success','پیام خواندهنشده شد.'); }
        redirect(url('admin_messages'));
    }
}

/* ============================================================
   ICONOGRAPHY: SVG icons (replaces decorative emoji)
   ============================================================ */
function fi(string $n,int $s=18):string{
    static $p=[
      'home'  =>'<path d="M3 10.6 12 3l9 7.6V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
      'user'  =>'<circle cx="12" cy="7.5" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
      'image' =>'<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.5"/><path d="m21 15-5-5-9 9"/>',
      'cart'  =>'<circle cx="9" cy="20" r="1.2"/><circle cx="17" cy="20" r="1.2"/><path d="M3 3h2l2.6 12.4a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21 6H6"/>',
      'book'  =>'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
      'mail'  =>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
      'bolt'  =>'<path d="M13 2 4 14h6l-1 8 9-12h-6z"/>',
      'chat'  =>'<path d="M21 15a2 2 0 0 1-2 2H8l-5 4V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
      'target'=>'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
      'check' =>'<circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.3 2.4 4.7-5"/>',
      'pin'   =>'<path d="M12 21c-4.4-4.7-7-8-7-11a7 7 0 0 1 14 0c0 3-2.6 6.3-7 11z"/><circle cx="12" cy="10" r="2.6"/>',
      'box'   =>'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5"/><path d="M12 13v8"/>',
      'search'=>'<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    ];
    $b=$p[$n]??'';
    return '<svg width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.$b.'</svg>';
}
/* ============================================================
   Layout
   ============================================================ */
function layout(string $title,callable $content,string $desc=''):void{
    touch_admin_presence();
    $page=(string)($_GET['page']??'home');
    /* اجبار به تغییر رمز پیش‌فرض ادمین: تا تغییر ندهد، هیچ صفحه‌ای جز پنل در دسترس نیست */
    if(!empty($_SESSION['must_change_pw']) && !in_array($page,['panel','logout'],true)){
        flash('warning','برای ادامه، ابتدا رمز عبور پیش‌فرض را از پنل کاربری عوض کنید.');
        redirect(url('panel'));
    }
    $u=current_user(); $cc=cart_count();
    $nav=[['home','خانه'],['about','دربارهٔ من'],['portfolio','نمونهکارها'],['shop','فروشگاه'],['topics','آموزش'],['contact','تماس با من']];
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-".csp_nonce()."'; style-src 'self' 'nonce-".csp_nonce()."'; style-src-attr 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'");
    ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<script nonce="<?= e(csp_nonce()) ?>">document.documentElement.classList.add('js')</script>
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<?php $noindex=!in_array($page,['home','about','portfolio','shop','topics','topic','contact','demo',''],true); ?>
<?php if($noindex): ?><meta name="robots" content="noindex, nofollow">
<?php endif; ?>
<meta name="description" content="<?= e($desc!==''?$desc:$title.' — '.BRAND_FA.' توسط '.OWNER_NAME.'. توسعه و طراحی وب‌سایت و فروشگاه اینترنتی با PHP، MySQL، UI/UX اختصاصی.') ?>">
<meta name="keywords" content="GoldenDevs, گلدن‌دِوز, <?= e(OWNER_NAME) ?>, طراحی وبسایت, فروشگاه اینترنتی, PHP, MySQL, برنامه‌نویسی, توسعه وب, سئو, قالب وردپرس, افزونه وردپرس, پلاگین وردپرس">
<meta name="author" content="<?= e(OWNER_NAME) ?>">
<meta name="theme-color" content="#0c7f70">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e(BRAND_NAME) ?>">
<meta property="og:title" content="<?= e($title) ?> | <?= e(BRAND_NAME) ?>">
<meta property="og:description" content="<?= e($title) ?> — <?= e(BRAND_FA) ?>. <?= e(BRAND_SLOGAN) ?> | <?= e(OWNER_NAME) ?>">
<meta property="og:locale" content="fa_IR">
<meta property="og:url" content="<?= e(canonical_url()) ?>">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="<?= e($title) ?> | <?= e(BRAND_NAME) ?>">
<meta name="twitter:description" content="<?= e($title) ?> — <?= e(BRAND_FA) ?>">
<link rel="canonical" href="<?= e(canonical_url()) ?>">
<link rel="icon" type="image/svg+xml" href='data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">GD</text></svg>'>
<title><?= e($title) ?> | <?= e(BRAND_NAME) ?> — <?= e(OWNER_NAME) ?></title>
<script type="application/ld+json" nonce="<?= e(csp_nonce()) ?>"><?= json_encode([
  '@context'=>'https://schema.org','@type'=>'ProfessionalService','name'=>BRAND_NAME,
  'alternateName'=>BRAND_FA,'slogan'=>BRAND_SLOGAN,
  'url'=>canonical_url(),
  'founder'=>['@type'=>'Person','name'=>OWNER_NAME,'jobTitle'=>'Full-Stack Developer','url'=>'https://goldendevs.ir'],
  'areaServed'=>'IR','inLanguage'=>'fa-IR',
  'description'=>'طراحی و ساخت وب‌سایت و فروشگاه اینترنتی با PHP، MySQL و رابط کاربری اختصاصی.',
  'sameAs'=>[],
  'knowsAbout'=>['PHP','MySQL','JavaScript','HTML','CSS','WordPress','Laravel','UI/UX','SEO']
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG) ?></script>
<link rel="stylesheet" href="assets/fonts/fonts.css">
<style nonce="<?= e(csp_nonce()) ?>">
:root{--paper:#f1f5f3;--surface:#fff;--ink:#0d2b26;--ink-2:#3f5f58;--ink-3:#71857f;--teal:#0c7f70;--teal-deep:#08574c;--teal-ink:#06231f;--turq:#14b8a6;--saffron:#e8a33d;--saffron-deep:#c9832a;--rose:#d96a5b;--line:#d5e0db;--shadow-sm:0 2px 8px rgba(8,60,52,.06);--shadow-md:0 10px 30px rgba(8,60,52,.10);--shadow-lg:0 24px 60px rgba(8,60,52,.16);--r-sm:8px;--r-md:14px;--r-lg:22px;--fd:'Lalezar','Vazirmatn',serif;--fb:'Vazirmatn',Tahoma,sans-serif}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;scrollbar-gutter:stable}
body{font-family:var(--fb);background:var(--paper);color:var(--ink);line-height:1.9;font-size:16px;overflow-x:hidden}
body::before{content:'';position:fixed;inset:0;z-index:-2;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='76' height='76' viewBox='0 0 76 76'%3E%3Cpath d='M38 4l8 15 16-5-5 16 15 8-15 8 5 16-16-5-8 15-8-15-16 5 5-16-15-8 15-8-5-16 16 5z' fill='none' stroke='%230c7f70' stroke-opacity='.06'/%3E%3C/svg%3E");background-size:84px}
body::after{content:'';position:fixed;inset:0;z-index:-1;pointer-events:none;background:radial-gradient(600px 420px at 92% -6%,rgba(20,184,166,.14),transparent 65%),radial-gradient(720px 520px at -10% 38%,rgba(232,163,61,.12),transparent 60%),radial-gradient(520px 420px at 70% 102%,rgba(12,127,112,.10),transparent 60%)}
img{max-width:100%;display:block}a{color:var(--teal);text-decoration:none}::selection{background:var(--saffron);color:var(--teal-ink)}
main{min-height:55vh}.container{width:min(1140px,92%);margin-inline:auto}.section{padding:5rem 0}
.section-alt{background:linear-gradient(180deg,rgba(255,255,255,.65),rgba(255,255,255,0));border-block:1px solid var(--line)}
.section-head{margin-bottom:2.2rem;max-width:60ch}.kicker{display:inline-flex;align-items:center;gap:.55rem;color:var(--teal);font-weight:700;font-size:.85rem}.kicker::before{content:'';width:26px;height:2px;background:var(--saffron)}
.section-title{font-family:var(--fd);font-size:clamp(1.9rem,4vw,2.7rem);line-height:1.45;margin:.4rem 0 .5rem}.section-lead{color:var(--ink-2)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;font-family:inherit;font-weight:700;font-size:.95rem;padding:.72rem 1.6rem;border-radius:var(--r-sm);border:2px solid transparent;cursor:pointer;transition:.25s;line-height:1.6}
.btn-primary{background:var(--teal);color:#fff;box-shadow:0 6px 18px rgba(12,127,112,.28)}.btn-primary:hover{background:var(--teal-deep);transform:translateY(-2px)}
.btn-outline{border-color:var(--teal);color:var(--teal)}.btn-outline:hover{background:var(--teal);color:#fff;transform:translateY(-2px)}
.btn-saffron{background:var(--saffron);color:var(--teal-ink)}.btn-saffron:hover{background:var(--saffron-deep);transform:translateY(-2px)}
.btn-ghost{color:var(--ink-2)}.btn-ghost:hover{color:var(--teal);background:rgba(12,127,112,.08)}
.btn-soft{background:rgba(217,106,91,.12);color:var(--rose)}.btn-soft:hover{background:var(--rose);color:#fff}
.btn-success{background:#16a34a;color:#fff}.btn-success:hover{background:#15803d;transform:translateY(-2px)}
.btn-sm{padding:.42rem 1rem;font-size:.85rem}.btn-block{width:100%}.btn:active{transform:scale(.98)}
.btn[disabled]{opacity:.5;cursor:not-allowed;transform:none!important}
.inline-form{display:inline}
.site-header{position:sticky;top:0;z-index:100;background:rgba(248,250,249,.96);border-bottom:1px solid var(--line)}
.scroll-progress{position:absolute;bottom:-1px;right:0;height:3px;width:0;background:linear-gradient(90deg,var(--saffron),var(--turq));z-index:101}
.header-inner{display:flex;align-items:center;justify-content:flex-start;gap:1rem;padding:.85rem 0}
.logo{font-family:var(--fd);font-size:1.55rem;color:var(--ink);display:inline-flex;align-items:baseline;line-height:1}
.logo-dot{width:8px;height:8px;background:var(--saffron);border-radius:2px;display:inline-block;margin-inline-start:5px;transform:rotate(45deg);transition:.3s}.logo:hover .logo-dot{transform:rotate(225deg);background:var(--turq)}
.main-nav{position:fixed;inset-block:0;inset-inline-start:0;width:min(330px,86vw);background:var(--paper);background-image:linear-gradient(180deg,#fff,var(--paper) 32%);display:flex;flex-direction:column;align-items:stretch;overflow-y:auto;padding:5.2rem 1.4rem 2rem;gap:.25rem;transform:translateX(105%);transition:transform .35s ease;box-shadow:var(--shadow-lg);z-index:110;border-inline-end:1px solid var(--line)}
.main-nav.open{transform:translateX(0)}
.nav-backdrop{position:fixed;inset:0;z-index:90;background:rgba(6,35,31,.55);opacity:0;transition:opacity .3s;pointer-events:none}
.nav-backdrop.open{opacity:1;pointer-events:auto}
.nav-link{position:relative;color:var(--ink-2);font-weight:600;font-size:.98rem;padding:.8rem .6rem;border-radius:var(--r-sm);transition:.2s}
.nav-link::after{content:'';position:absolute;bottom:2px;right:.6rem;left:.6rem;height:2px;background:var(--saffron);transform:scaleX(0);transform-origin:right;transition:.25s}
.nav-link:hover::after,.nav-link.is-active::after{transform:scaleX(1)}.nav-link.is-active{color:var(--teal)}
.nav-link:hover{background:rgba(12,127,112,.08)}
.nav-auth{display:flex;align-items:center;gap:.5rem;margin:1rem 0 0;padding:1rem 0 0;border-top:1px solid var(--line);flex-wrap:wrap}
.cart-link{position:relative;font-size:1.25rem;padding:.3rem .5rem;border-radius:var(--r-sm);transition:.2s}
.cart-link:hover{background:rgba(12,127,112,.08);transform:translateY(-2px)}
.cart-badge{position:absolute;top:-4px;inset-inline-start:-4px;background:var(--saffron);color:var(--teal-ink);font-size:.68rem;font-weight:800;min-width:18px;height:18px;border-radius:999px;display:grid;place-items:center;font-family:var(--fb)}
.nav-toggle{position:relative;display:flex;flex-direction:column;gap:5px;background:none;border:0;cursor:pointer;padding:8px;z-index:120}
.nav-toggle span{width:24px;height:2.5px;background:var(--ink);border-radius:2px;transition:.3s}
.nav-toggle.open span:nth-child(1){transform:translateY(7.5px) rotate(45deg)}.nav-toggle.open span:nth-child(2){opacity:0}.nav-toggle.open span:nth-child(3){transform:translateY(-7.5px) rotate(-45deg)}
.hero{padding:4rem 0 5rem}.hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:3rem;align-items:center}
.status-chip{display:inline-flex;align-items:center;gap:.55rem;background:var(--surface);border:1px solid var(--line);padding:.35rem 1rem;border-radius:999px;font-size:.82rem;font-weight:700;color:var(--teal-deep);box-shadow:var(--shadow-sm)}
.pulse-dot{width:9px;height:9px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 0 rgba(34,197,94,.5);animation:pulse 2s infinite}@keyframes pulse{70%{box-shadow:0 0 0 9px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.hero-name{font-family:var(--fd);font-size:clamp(3rem,9vw,5.4rem);line-height:1.12;margin:1rem 0 .4rem}.hero-name span{color:var(--teal);position:relative}
.hero-name span::after{content:'';position:absolute;bottom:8px;right:0;left:0;height:11px;background:rgba(232,163,61,.4);z-index:-1;transform:skewX(-12deg)}
.hero-role{font-size:1.1rem;font-weight:700;color:var(--ink-2);min-height:1.6em}.role-typer{color:var(--saffron-deep)}
.caret{display:inline-block;width:2px;height:1.2em;background:var(--teal);margin-inline-start:3px;vertical-align:middle;animation:blink 1s steps(1) infinite}@keyframes blink{50%{opacity:0}}
.hero-desc{color:var(--ink-2);max-width:52ch;margin:.9rem 0 1.5rem}.hero-actions{display:flex;gap:.8rem;flex-wrap:wrap}
.hero-meta{display:flex;gap:1.8rem;list-style:none;margin-top:2rem;flex-wrap:wrap}.hero-meta li{color:var(--ink-3);font-size:.88rem}.hero-meta b{display:block;font-family:var(--fd);font-size:1.4rem;color:var(--ink);font-weight:400}
.hero-visual{position:relative}.terminal{background:var(--teal-ink);border-radius:var(--r-lg);box-shadow:var(--shadow-lg);overflow:hidden;transform:rotate(-1.5deg);transition:.4s}.terminal:hover{transform:rotate(0) scale(1.015)}
.terminal-bar{display:flex;align-items:center;gap:7px;padding:.8rem 1.1rem;background:rgba(255,255,255,.05)}.terminal-bar span{width:11px;height:11px;border-radius:50%}
.terminal-bar span:nth-child(1){background:#ff5f57}.terminal-bar span:nth-child(2){background:#febc2e}.terminal-bar span:nth-child(3){background:#28c840}
.terminal-bar em{margin-inline-start:auto;color:#7fb5ac;font-style:normal;font-size:.75rem;letter-spacing:1px}
.terminal-code{padding:1.3rem 1.4rem;direction:ltr;text-align:left;font-family:Consolas,monospace;font-size:.83rem;line-height:2;color:#c9e8e2;overflow-x:auto;white-space:pre}
.tk-k{color:#7dd3c0}.tk-s{color:#f0c674}.tk-v{color:#9adcff}.tk-c{color:#5d837b}.tk-f{color:#e8a33d}
.hero-avatar{position:absolute;bottom:-2rem;inset-inline-start:-1.2rem;width:126px;height:126px;border-radius:50%;object-fit:cover;border:5px solid var(--paper);box-shadow:var(--shadow-md);transform:rotate(4deg);transition:.35s}.hero-avatar:hover{transform:rotate(-3deg) scale(1.06)}
.marquee{background:var(--teal-ink);color:#bfe8df;overflow:hidden;padding:.9rem 0;border-block:3px solid var(--saffron)}
.marquee-track{display:flex;gap:2.5rem;width:max-content;animation:marquee 32s linear infinite}.marquee:hover .marquee-track,.marquee:focus-within .marquee-track{animation-play-state:paused}
.marquee-track span{display:inline-flex;align-items:center;gap:2.5rem;font-family:var(--fd);font-size:1.15rem;white-space:nowrap}.marquee-track i{color:var(--saffron);font-style:normal}
.marquee-track a{color:#bfe8df;transition:.2s;border-bottom:1px dashed transparent;padding-bottom:2px}
.marquee-track a:hover,.marquee-track a:focus-visible{color:#fff;border-bottom-color:var(--saffron)}
@keyframes marquee{to{transform:translateX(50%)}}
/* موضوعات آموزشی (بلاگ داخلی) */
.topic-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:1.2rem}
.topic-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.4rem;box-shadow:var(--shadow-sm);transition:.25s;display:block}
.topic-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md);border-color:var(--teal)}
.topic-card h3{font-family:var(--fd);font-size:1.3rem;color:var(--ink);margin-bottom:.4rem}
.topic-card p{color:var(--ink-2);font-size:.88rem}
.article{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);padding:2rem;box-shadow:var(--shadow-sm);max-width:75ch;margin-inline:auto}
.article h1{font-family:var(--fd);font-size:clamp(1.8rem,4vw,2.5rem);margin-bottom:.5rem}
.article .lead{color:var(--teal-deep);font-weight:700;margin-bottom:1.2rem}
.article p{color:var(--ink-2);margin-bottom:1rem}
.breadcrumb{display:flex;gap:.4rem;flex-wrap:wrap;font-size:.82rem;color:var(--ink-3);margin-bottom:1.2rem}
.breadcrumb a{color:var(--teal)}
.topic-nav{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:2rem;padding-top:1.2rem;border-top:1px solid var(--line)}
.topic-nav a{background:#f7faf8;border:1px solid var(--line);border-radius:999px;padding:.35rem .9rem;font-size:.82rem;color:var(--ink-2);transition:.2s}
.topic-nav a:hover{background:var(--teal);color:#fff;border-color:var(--teal)}
.stats-band{background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));color:#fff;padding:3rem 0}.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem}.stat-item{text-align:center}
.stat-num{font-family:var(--fd);font-size:clamp(2.3rem,5vw,3.3rem);color:var(--saffron);line-height:1.2}.stat-label{color:#a8d5cb;font-size:.9rem}
.skills-grid{display:grid;grid-template-columns:1fr 1fr;gap:3rem}.skill-row{margin-bottom:1.4rem}
.skill-head{display:flex;justify-content:space-between;font-weight:700;font-size:.92rem;margin-bottom:.45rem}.skill-head b{color:var(--teal);font-family:var(--fd);font-weight:400;font-size:1.05rem}
.bar{height:10px;background:#e2ebe7;border-radius:999px;overflow:hidden}.bar-fill{height:100%;width:0;background:linear-gradient(90deg,var(--teal),var(--turq));border-radius:999px;transition:width 1.3s cubic-bezier(.22,.9,.35,1);position:relative}
.bar-fill::after{content:'';position:absolute;inset-inline-end:0;top:0;bottom:0;width:12px;background:var(--saffron);border-radius:999px}
.timeline{position:relative;padding-inline-start:2rem;max-width:720px}.timeline::before{content:'';position:absolute;inset-inline-start:6px;top:6px;bottom:6px;width:2px;background:linear-gradient(180deg,var(--turq),var(--saffron))}
.t-item{position:relative;padding-bottom:2rem}.t-item::before{content:'';position:absolute;inset-inline-start:-32px;top:6px;width:14px;height:14px;border-radius:50%;background:var(--saffron);border:3px solid var(--paper);box-shadow:0 0 0 2px var(--teal)}
.t-date{display:inline-block;background:rgba(12,127,112,.1);color:var(--teal-deep);font-size:.78rem;font-weight:700;padding:.15rem .8rem;border-radius:999px;margin-bottom:.4rem}
.t-item h3{font-size:1.08rem}.t-item p{color:var(--ink-2);font-size:.94rem}
.filter-bar{display:flex;gap:.5rem;flex-wrap:wrap;margin:1.4rem 0 1.8rem}
.filter-btn{border:1.5px solid var(--line);background:var(--surface);color:var(--ink-2);padding:.42rem 1.2rem;border-radius:999px;font-family:inherit;font-weight:700;font-size:.85rem;cursor:pointer;transition:.2s}
.filter-btn:hover{border-color:var(--teal);color:var(--teal)}.filter-btn.is-active{background:var(--teal);border-color:var(--teal);color:#fff}
.portfolio-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.6rem}
.project-card{background:var(--surface);border-radius:var(--r-md);overflow:hidden;border:1px solid var(--line);transition:.35s;position:relative}
.project-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-lg);border-color:transparent}
.project-media{overflow:hidden;aspect-ratio:16/10}.project-media img{width:100%;height:100%;object-fit:cover;transition:transform .6s}.project-card:hover .project-media img{transform:scale(1.07)}
.project-body{padding:1.1rem 1.2rem 1.3rem}.project-tags{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.55rem}
.tag{font-size:.72rem;font-weight:700;background:rgba(20,184,166,.12);color:var(--teal-deep);padding:.12rem .7rem;border-radius:999px}.tag-gold{background:rgba(232,163,61,.16);color:var(--saffron-deep)}
.project-body h3{font-size:1.05rem;margin-bottom:.25rem}.project-body p{color:var(--ink-2);font-size:.87rem}
.project-year{position:absolute;top:.9rem;inset-inline-start:.9rem;background:rgba(6,35,31,.75);color:#fff;font-size:.75rem;padding:.15rem .7rem;border-radius:999px;backdrop-filter:blur(4px)}
.project-link{display:inline-flex;align-items:center;gap:.3rem;font-weight:700;font-size:.85rem;margin-top:.6rem;color:var(--teal)}.project-link::after{content:'←';transition:.25s}.project-link:hover::after{transform:translateX(-4px)}
.is-hidden{display:none}
.shop-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.6rem}
.product-card{background:var(--surface);border-radius:var(--r-md);overflow:hidden;border:1px solid var(--line);transition:.35s;display:flex;flex-direction:column}
.product-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-lg);border-color:transparent}
.product-media{position:relative;aspect-ratio:4/3;overflow:hidden;background:#e8efec}.product-media img{width:100%;height:100%;object-fit:cover;transition:transform .6s}.product-card:hover .product-media img{transform:scale(1.06)}
.product-stock{position:absolute;top:.8rem;inset-inline-end:.8rem;background:#22c55e;color:#fff;font-size:.72rem;font-weight:700;padding:.15rem .7rem;border-radius:999px}.product-stock.out{background:#94a3b8}
.product-body{padding:1.1rem 1.2rem 1.3rem;display:flex;flex-direction:column;flex:1}.product-body h3{font-size:1.02rem;margin-bottom:.25rem}.product-body p{color:var(--ink-2);font-size:.85rem;flex:1}
.product-foot{display:flex;justify-content:space-between;align-items:center;margin-top:.8rem;padding-top:.8rem;border-top:1px dashed var(--line)}.price{font-family:var(--fd);font-size:1.2rem;color:var(--teal-deep)}
.page-head{padding:4rem 0 2rem}.page-head h1{font-family:var(--fd);font-size:clamp(2.2rem,5vw,3.2rem);line-height:1.3}.breadcrumb{color:var(--ink-3);font-size:.85rem;margin-bottom:.4rem}
.about-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:3rem;align-items:center}.about-photo{position:relative}.about-photo img{border-radius:var(--r-lg);box-shadow:var(--shadow-lg)}
.about-photo::before{content:'';position:absolute;top:-14px;inset-inline-end:-14px;width:120px;height:120px;background:var(--saffron);border-radius:var(--r-lg);z-index:-1;opacity:.85}
.values{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-top:1.6rem}.value{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.1rem 1.2rem;transition:.25s}
.value:hover{transform:translateY(-4px);box-shadow:var(--shadow-sm);border-color:var(--turq)}.value h4{font-size:1rem;margin-bottom:.2rem}.value p{color:var(--ink-2);font-size:.85rem}
.auth-wrap{width:min(520px,92%);margin:3.5rem auto;background:var(--surface);border-radius:var(--r-lg);padding:2.6rem;box-shadow:var(--shadow-lg);border:1px solid var(--line)}
.auth-title{font-family:var(--fd);font-size:2rem;margin-bottom:.2rem}.auth-sub{color:var(--ink-2);font-size:.92rem;margin-bottom:1.6rem}.auth-alt{text-align:center;margin-top:1.3rem;font-size:.9rem;color:var(--ink-2)}
.form-field{margin-bottom:1.1rem}.form-field label{display:block;font-weight:700;font-size:.88rem;margin-bottom:.4rem}.form-field .hint{font-weight:400;color:var(--ink-3);font-size:.78rem}
input[type=text],input[type=email],input[type=password],input[type=url],input[type=number],input[type=tel],select,textarea{width:100%;font-family:inherit;font-size:.95rem;padding:.75rem 1rem;border:1.5px solid var(--line);border-radius:var(--r-sm);background:#fbfdfc;color:var(--ink);transition:.2s}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--teal);box-shadow:0 0 0 4px rgba(12,127,112,.12);background:#fff}
textarea{min-height:130px;resize:vertical}
.panel-head{display:flex;align-items:center;gap:1.2rem;background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));color:#fff;border-radius:var(--r-lg);padding:2rem 2.2rem;margin-bottom:2rem}
.avatar-circle{width:74px;height:74px;border-radius:50%;background:var(--saffron);color:var(--teal-ink);display:grid;place-items:center;font-family:var(--fd);font-size:1.9rem;flex-shrink:0}
.panel-head h1{font-family:var(--fd);font-size:1.7rem;font-weight:400}.panel-head p{color:#a8d5cb;font-size:.9rem}
.role-badge{display:inline-block;background:rgba(232,163,61,.2);color:var(--saffron);border:1px solid rgba(232,163,61,.4);font-size:.75rem;font-weight:700;padding:.1rem .8rem;border-radius:999px;margin-top:.4rem}
.panel-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.6rem;align-items:start}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.8rem;box-shadow:var(--shadow-sm)}
.card h2{font-family:var(--fd);font-size:1.4rem;margin-bottom:1.1rem;display:flex;align-items:center;gap:.6rem}.card h2::before{content:'';width:8px;height:22px;background:var(--saffron);border-radius:4px}
.info-list{list-style:none}.info-list li{display:flex;justify-content:space-between;gap:1rem;padding:.6rem 0;border-bottom:1px dashed var(--line);font-size:.92rem}.info-list li:last-child{border-bottom:0}.info-list span{color:var(--ink-3)}
.admin-tabs{display:flex;gap:.4rem;border-bottom:2px solid var(--line);margin-bottom:2rem;overflow-x:auto}
.admin-tab{padding:.7rem 1.4rem;font-weight:700;color:var(--ink-3);border-bottom:3px solid transparent;margin-bottom:-2px;white-space:nowrap;transition:.2s}
.admin-tab:hover{color:var(--teal)}.admin-tab.is-active{color:var(--teal);border-color:var(--saffron)}
.stat-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:1.2rem;margin-bottom:2rem}
.stat-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.4rem 1.5rem;position:relative;overflow:hidden;transition:.25s}
.stat-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}.stat-card::before{content:'';position:absolute;top:0;inset-inline-start:0;width:4px;height:100%;background:var(--teal)}
.stat-card.gold::before{background:var(--saffron)}.stat-card.rose::before{background:var(--rose)}.stat-card.turq::before{background:var(--turq)}
.stat-card .num{font-family:var(--fd);font-size:2.2rem;line-height:1.2}.stat-card .lbl{color:var(--ink-3);font-size:.85rem}
.table-wrap{overflow-x:auto;background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md)}
table{width:100%;border-collapse:collapse;min-width:640px}
th{background:#eef4f1;color:var(--ink-2);font-size:.82rem;text-align:right;padding:.9rem 1.1rem;font-weight:700}
td{padding:.85rem 1.1rem;border-top:1px solid var(--line);font-size:.9rem;vertical-align:middle}tr:hover td{background:#f7faf8}
.thumb{width:52px;height:40px;object-fit:cover;border-radius:6px;border:1px solid var(--line)}
.badge{font-size:.74rem;font-weight:700;padding:.15rem .75rem;border-radius:999px;display:inline-block}
.badge-admin{background:rgba(232,163,61,.18);color:var(--saffron-deep)}.badge-user{background:rgba(20,184,166,.14);color:var(--teal-deep)}
.badge-ok{background:rgba(34,197,94,.14);color:#15803d}.badge-no,.badge-draft{background:rgba(148,163,184,.18);color:#64748b}
.badge-paid{background:rgba(34,197,94,.14);color:#15803d}.badge-pending{background:rgba(232,163,61,.18);color:var(--saffron-deep)}
.badge-shipped{background:rgba(20,184,166,.16);color:var(--teal-deep)}.badge-done{background:rgba(12,127,112,.16);color:var(--teal-deep)}
.badge-cancelled{background:rgba(217,106,91,.16);color:var(--rose)}
.row-actions{display:flex;gap:.4rem;flex-wrap:wrap}
.page-title-row{display:flex;justify-content:space-between;align-items:center;gap:1rem;margin-bottom:1.6rem;flex-wrap:wrap}.page-title-row h1{font-family:var(--fd);font-size:1.9rem}
.empty-state{text-align:center;padding:3rem 1rem;color:var(--ink-3)}
.user-cell{display:flex;align-items:center;gap:.7rem}.user-cell .mini{width:38px;height:38px;border-radius:50%;background:var(--teal);color:#fff;display:grid;place-items:center;font-family:var(--fd);font-size:1rem;flex-shrink:0}
.contact-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:3rem;align-items:start}
.cta-band{background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));border-radius:var(--r-lg);padding:2.8rem 2.4rem;color:#fff;display:flex;justify-content:space-between;align-items:center;gap:2rem}
.cta-band h2{font-family:var(--fd);font-size:clamp(1.5rem,3.5vw,2.2rem)}.cta-band p{color:#a8d5cb}
/* --- فروشگاه: سبد/پرداخت/سفارش --- */
.qty-input{width:64px;text-align:center;padding:.4rem .3rem}
.qty-group{display:inline-flex;align-items:center;gap:.3rem}
.qty-step{width:32px;height:36px;border:1.5px solid var(--line);background:var(--surface);color:var(--teal);font-size:1.1rem;font-weight:800;border-radius:8px;cursor:pointer;transition:.2s;line-height:1}
.qty-step:hover:not(:disabled){background:var(--teal);color:#fff;border-color:var(--teal)}
.qty-step:disabled{opacity:.35;cursor:not-allowed}
.qty-group .qty-input{border-radius:8px}
.cart-item{display:flex;align-items:center;gap:1rem;padding:1rem 0;border-bottom:1px dashed var(--line)}
.cart-item img{width:76px;height:60px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}
.cart-item .ci-info{flex:1}.cart-item .ci-info b{display:block}.cart-item .ci-info small{color:var(--ink-3)}
.ci-price{font-family:var(--fd);font-size:1.05rem;color:var(--teal-deep);min-width:120px;text-align:center}
.cart-summary{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:1.6rem;position:sticky;top:90px}
.cart-summary .total-row{display:flex;justify-content:space-between;font-weight:800;font-size:1.1rem;padding-top:.8rem;margin-top:.8rem;border-top:2px solid var(--line)}
.cart-summary .total-row b{font-family:var(--fd);color:var(--teal-deep);font-size:1.3rem}
.checkout-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:2rem;align-items:start}
.pay-gateway{max-width:520px;margin:2rem auto;background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--shadow-lg)}
.pay-head{background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;padding:1.4rem 1.8rem;text-align:center}
.pay-head .amount{font-family:var(--fd);font-size:2rem;margin-top:.3rem}
.pay-body{padding:1.8rem}
.pay-body .card-row{direction:ltr;text-align:center;font-family:Consolas,monospace;font-size:1.15rem;letter-spacing:2px;background:#f4f7f5;border:1.5px dashed var(--line);border-radius:var(--r-sm);padding:.8rem;margin-bottom:1.2rem;color:var(--ink-2)}
.pay-note{text-align:center;font-size:.78rem;color:var(--ink-3);margin-top:1rem}
.order-card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);margin-bottom:1.4rem;overflow:hidden;transition:.25s}
.order-card:hover{box-shadow:var(--shadow-md);transform:translateY(-3px)}
.order-head{display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;padding:1.1rem 1.4rem;background:#eef4f1;border-bottom:1px solid var(--line)}
.order-head .ref{font-family:Consolas,monospace;font-weight:700;color:var(--teal-deep)}
.order-items{padding:.6rem 1.4rem}
.order-items li{display:flex;justify-content:space-between;gap:1rem;padding:.45rem 0;border-bottom:1px dashed var(--line);font-size:.9rem;list-style:none}
.order-items li:last-child{border-bottom:0}
.order-total{display:flex;justify-content:space-between;padding:.9rem 1.4rem;font-weight:800;background:#fafcfb}
.order-total b{font-family:var(--fd);color:var(--teal-deep)}
.success-box{max-width:560px;margin:3rem auto;text-align:center;background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);padding:3rem 2.4rem;box-shadow:var(--shadow-lg)}
.success-icon{width:84px;height:84px;border-radius:50%;background:rgba(34,197,94,.14);color:#16a34a;display:grid;place-items:center;font-size:2.4rem;margin:0 auto 1.2rem;animation:pop .5s cubic-bezier(.2,1.4,.4,1)}
@keyframes pop{from{transform:scale(0)}to{transform:scale(1)}}
.site-footer{background:var(--teal-ink);color:#9fc9c0;margin-top:5rem}
.footer-inner{display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:2.5rem;padding:3.2rem 0 2.2rem}.site-footer .logo{color:#fff}
.footer-links h4{color:#fff;font-size:.95rem;margin-bottom:.8rem}.footer-links a{display:block;color:#9fc9c0;font-size:.88rem;padding:.25rem 0;transition:.2s}.footer-links a:hover{color:var(--saffron);transform:translateX(-4px)}
.footer-bottom{display:flex;justify-content:space-between;gap:1rem;border-top:1px solid rgba(255,255,255,.08);padding:1.2rem 0;font-size:.8rem;flex-wrap:wrap}
.toast-wrap{position:fixed;bottom:1.2rem;inset-inline-start:1.2rem;z-index:1000;display:flex;flex-direction:column;gap:.6rem;max-width:min(340px,90vw)}
.toast{display:flex;align-items:center;gap:.7rem;background:var(--teal-ink);color:#fff;padding:.85rem 1.2rem;border-radius:var(--r-sm);box-shadow:var(--shadow-lg);font-size:.88rem;font-weight:600;opacity:0;transform:translateY(14px);transition:.35s;border-inline-start:4px solid var(--turq)}
.toast.show{opacity:1;transform:none}.toast-success{border-color:#22c55e}.toast-error{border-color:var(--rose)}.toast-info{border-color:var(--turq)}.toast-warning{border-color:var(--saffron)}
.toast-icon{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:.72rem;flex-shrink:0;background:rgba(255,255,255,.14)}
/* انیمیشن reveal فقط وقتی JS فعال است (بدون JS صفحه کاملاً نمایان می‌ماند) */
html.js .reveal{opacity:0;transform:translateY(26px);transition:opacity .7s ease,transform .7s ease;transition-delay:var(--d,0s)}
html.js .reveal.in{opacity:1;transform:none}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}.reveal{opacity:1;transform:none}}
@media(max-width:980px){
.hero-grid,.skills-grid,.contact-grid,.panel-grid,.about-grid,.checkout-grid{grid-template-columns:1fr}
.hero-visual{margin-top:1.5rem}.portfolio-grid,.shop-grid{grid-template-columns:repeat(2,1fr)}
.stats-grid,.stat-cards{grid-template-columns:repeat(2,1fr)}.footer-inner{grid-template-columns:1fr 1fr}.cta-band{flex-direction:column;text-align:center}
.cart-summary{position:static}
}
@media(max-width:620px){.portfolio-grid,.shop-grid,.values{grid-template-columns:1fr}.section{padding:3.6rem 0}.hero{padding:2.8rem 0 4rem}.hero-avatar{width:100px;height:100px;bottom:-1.5rem}.card{padding:1.4rem}.footer-inner{grid-template-columns:1fr}.auth-wrap{padding:1.8rem 1.4rem}.panel-head{flex-direction:column;text-align:center}.cart-item{flex-wrap:wrap}.ci-price{min-width:auto}.header-inner{padding:.6rem 0}.nav-auth .btn{flex:1 1 auto;text-align:center}}
/* منوی کشویی مشترک موبایل و دسکتاپ */
.nav-extra{display:block;margin-top:1.1rem;padding-top:1rem;border-top:1px solid var(--line)}
.nav-extra h5{font-size:.78rem;color:var(--ink-3);font-weight:800;margin:.9rem .6rem .35rem;letter-spacing:.02em}
.nav-extra h5:first-child{margin-top:0}
.nav-extra a{display:block;color:var(--ink-2);font-size:.9rem;padding:.5rem .6rem;border-radius:var(--r-sm);transition:.2s}
.nav-extra a:hover{background:rgba(12,127,112,.08);color:var(--teal)}
.nav-extra .nav-chips{display:block;padding:.2rem 0}
.nav-extra .nav-chips a{background:#fff;border:1px solid var(--line);font-size:.8rem;padding:.32rem .7rem;border-radius:999px}
/* --- ویجت چت: سوالات متداول + پشتیبانی انسانی + دستیار هوشمند --- */
.chat-fab{position:fixed;bottom:1.2rem;inset-inline-end:1.2rem;z-index:900;width:56px;height:56px;border-radius:50%;background:var(--teal);color:#fff;border:0;cursor:pointer;box-shadow:var(--shadow-lg);display:grid;place-items:center;font-size:1.5rem;transition:.25s}
.chat-fab:hover{background:var(--teal-deep);transform:translateY(-3px) scale(1.05)}
.chat-fab .chat-dot{position:absolute;top:2px;inset-inline-end:2px;width:12px;height:12px;border-radius:50%;background:#22c55e;border:2px solid #fff;display:none}
.chat-fab.has-news .chat-dot{display:block}
.chat-panel{position:fixed;bottom:6.2rem;inset-inline-end:1.2rem;z-index:901;width:min(400px,calc(100vw - 2rem));height:min(580px,74vh);background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;overflow:hidden;opacity:0;transform:translateY(16px) scale(.98);pointer-events:none;transition:.3s;visibility:hidden}
.chat-panel.open{opacity:1;transform:none;pointer-events:auto;visibility:visible}
.chat-head{background:linear-gradient(135deg,var(--teal-deep),var(--teal-ink));color:#fff;padding:1rem 1.2rem;display:flex;align-items:center;justify-content:space-between;gap:.8rem}
.chat-head h3{font-family:var(--fd);font-size:1.15rem;line-height:1.3}
.chat-head small{color:#9fd1c6;font-size:.75rem}
.chat-back{background:rgba(255,255,255,.12);border:0;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:1rem;transition:.2s;display:none}
.chat-back.show{display:block}
.chat-back:hover{background:rgba(255,255,255,.25)}
.chat-head-actions{display:flex;align-items:center;gap:.4rem}
.chat-close{background:rgba(255,255,255,.12);border:0;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:1rem;transition:.2s}
.chat-close:hover{background:rgba(255,255,255,.25)}
.agent-bar{display:flex;align-items:center;gap:.55rem;padding:.6rem 1.2rem;background:rgba(255,255,255,.06);border-top:1px solid rgba(255,255,255,.08)}
.agent-avatars{display:flex}
.agent-av{width:30px;height:30px;border-radius:50%;background:var(--turq);color:var(--teal-ink);font-weight:800;font-size:.85rem;display:grid;place-items:center;border:2px solid var(--teal-ink);margin-inline-start:-8px;position:relative;overflow:hidden}
.agent-av:first-child{margin-inline-start:0}
.agent-av img{width:100%;height:100%;object-fit:cover}
.agent-av.is-online::after{content:'';position:absolute;bottom:0;inset-inline-end:0;width:9px;height:9px;border-radius:50%;background:#22c55e;border:2px solid var(--teal-ink)}
.agent-text{font-size:.74rem;color:#bfe8df;line-height:1.6}
.chat-body{flex:1;overflow-y:auto;padding:1rem;background:var(--surface)}
.chat-view{display:none}.chat-view.is-active{display:block}
.qa-item{border:1px solid var(--line);border-radius:var(--r-sm);margin-bottom:.6rem;overflow:hidden}
.qa-q{width:100%;background:#f7faf8;border:0;padding:.8rem 1rem;font-family:inherit;font-weight:800;font-size:.9rem;text-align:right;cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:.6rem;color:var(--ink);transition:.2s}
.qa-q:hover{background:#eef4f1;color:var(--teal)}
.qa-q i{font-style:normal;transition:.25s;color:var(--teal)}
.qa-q.open i{transform:rotate(180deg)}
.qa-a{max-height:0;overflow:hidden;transition:max-height .3s ease;color:var(--ink-2);font-size:.86rem;padding:0 1rem;background:#fff}
.qa-a.open{max-height:280px;padding-bottom:.8rem}
.chat-cta{margin-top:1rem;padding-top:1rem;border-top:1px dashed var(--line);text-align:center}
.chat-cta p{font-size:.85rem;color:var(--ink-2);margin-bottom:.7rem}
.chat-choices{display:grid;gap:.7rem;padding:.4rem 0}
.choice-card{display:flex;align-items:flex-start;gap:.8rem;width:100%;text-align:right;background:#f7faf8;border:1px solid var(--line);border-radius:var(--r-md);padding:1rem;cursor:pointer;font-family:inherit;transition:.22s}
.choice-card:hover{background:#fff;border-color:var(--teal);transform:translateY(-2px);box-shadow:var(--shadow-sm)}
.choice-ic{flex-shrink:0;width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-size:1.25rem;background:rgba(12,127,112,.12)}
.choice-card.gold .choice-ic{background:rgba(232,163,61,.18)}
.choice-tt{font-weight:800;font-size:.94rem;color:var(--ink);display:block;margin-bottom:.15rem}
.choice-ds{font-size:.78rem;color:var(--ink-3);line-height:1.65}
.chat-msgs{display:flex;flex-direction:column;gap:.7rem;min-height:190px}
.chat-msg{max-width:82%;padding:.7rem 1rem;border-radius:14px;font-size:.88rem;line-height:1.7;white-space:pre-wrap;word-break:break-word}
.chat-msg.bot{background:#eef4f1;color:var(--ink);border-bottom-right-radius:4px;align-self:flex-start}
.chat-msg.admin{background:#fdf3e3;color:var(--ink);border:1px solid rgba(232,163,61,.4);border-bottom-right-radius:4px;align-self:flex-start}
.chat-msg.user{background:var(--teal);color:#fff;border-bottom-left-radius:4px;align-self:flex-end}
.chat-msg .msg-who{display:block;font-size:.68rem;opacity:.75;margin-bottom:.25rem;font-weight:700}
.chat-typing{display:inline-flex;gap:4px;padding:.7rem 1rem;background:#eef4f1;border-radius:14px;align-self:flex-start}
.chat-typing span{width:7px;height:7px;border-radius:50%;background:var(--ink-3);animation:cht 1.2s infinite}
.chat-typing span:nth-child(2){animation-delay:.15s}.chat-typing span:nth-child(3){animation-delay:.3s}
@keyframes cht{0%,60%,100%{transform:translateY(0);opacity:.5}30%{transform:translateY(-4px);opacity:1}}
.chat-input-row{display:none;gap:.5rem;padding:.9rem;border-top:1px solid var(--line);background:#fafcfb}
.chat-input-row.show{display:flex}
.chat-input-row input{flex:1;padding:.6rem .9rem;font-size:.9rem}
.chat-send{flex-shrink:0}
.chat-note{font-size:.7rem;color:var(--ink-3);text-align:center;padding:.5rem .8rem .6rem;background:#fafcfb}
@media(max-width:620px){.chat-panel{bottom:5.6rem;height:min(500px,72vh)}.chat-fab{width:50px;height:50px;font-size:1.3rem}}

/* === بهبود UI/UX: نشان کم‌موجودی + ایموجی === */
.hero-meta em{font-style:normal;margin-inline-end:.35rem}
.product-stock.low{background:#fff8e6;color:#b57614;border-color:#f3d692}
.ci-stock{display:block;margin-top:.2rem;font-size:.75rem;color:#b57614}
.ci-stock.is-out{color:#c0392b}
/* آیکن‌ها: SVG جایگزین ایموجی */
.nav-extra .nav-chips a{background:transparent;border:0;border-radius:var(--r-sm);font-size:.9rem;padding:.5rem .6rem;color:var(--ink-2)}
.nav-extra .nav-chips a:hover{background:rgba(12,127,112,.08);color:var(--teal)}
/* Iconography: SVG icons replace emoji */
.main-nav .nav-link{display:inline-flex;align-items:center;gap:.45rem}
.main-nav .nav-link>svg{flex:none;margin-block:-1px}
.nav-extra h5,.footer-links h4{display:flex;align-items:center;gap:.45rem}
.nav-extra h5 svg,.footer-links h4 svg{flex:none}
.hero-meta em{display:inline-flex;align-items:center;vertical-align:middle}
.hero-meta em svg{flex:none}
.kicker>svg{flex:none}
.ci-stock{display:flex;align-items:center;gap:.4rem}
.ci-stock svg{flex:none}
.product-stock{display:inline-flex;align-items:center;gap:.35rem}
.product-stock::before{content:'';width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.95);flex:none}

/* هدر: نوار سرچ + اکشن‌ها (سبد/ورود/ثبت‌نام) */
.header-search{flex:1 1 auto;max-width:420px;min-width:0;margin-inline:auto;display:flex;align-items:center;gap:.5rem;background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:.34rem .55rem .34rem .9rem;box-shadow:var(--shadow-sm);transition:.25s}
.header-search:focus-within{border-color:var(--turq);box-shadow:0 0 0 3px rgba(20,184,166,.16)}
.header-search input{flex:1;min-width:0;border:0;background:transparent;font:inherit;font-size:.9rem;color:var(--ink);outline:none}
.header-search input::placeholder{color:var(--ink-3)}
.header-search input::-webkit-search-cancel-button{-webkit-appearance:none}
.header-search button{flex:none;border:0;cursor:pointer;background:var(--teal);color:#fff;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;transition:.2s}
.header-search button:hover{background:var(--teal-deep);transform:scale(1.06)}
.header-actions{display:flex;align-items:center;gap:.45rem;flex:none}
.header-actions .btn{white-space:nowrap}
/* دکمهٔ پشتیبانی داخل منوی همبرگری */
.nav-support{display:flex;align-items:center;gap:.5rem;width:100%;background:rgba(12,127,112,.08);color:var(--teal-deep);border:1px solid var(--line);font:inherit;font-size:.9rem;font-weight:700;padding:.62rem .7rem;border-radius:var(--r-sm);cursor:pointer;transition:.2s;text-align:start}
.nav-support:hover{background:rgba(12,127,112,.16)}
.nav-support svg{flex:none}
.nav-support-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;margin-inline-start:auto;flex:none}
@media(max-width:860px){.header-search{max-width:none}}
@media(max-width:760px){.header-actions .hide-sm{display:none}}
@media(max-width:430px){.header-inner{gap:.5rem}.logo{font-size:1.25rem}.header-search{padding-inline:.45rem .6rem}}

/* Demo grid: پیش‌نمایش قالب/افزونه */
.demo-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1.6rem;margin-top:1.5rem
}
.demo-card{
  background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);overflow:hidden;transition:.3s;display:flex;flex-direction:column
}
.demo-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md)}
.demo-media{position:relative;aspect-ratio:16/9;background:#e8efec;overflow:hidden}
.demo-media img{width:100%;height:100%;object-fit:cover;object-position:top center;transition:transform .5s}
.demo-card:hover .demo-media img{transform:scale(1.04)}
.demo-type{
  position:absolute;top:.8rem;inset-inline-start:.8rem;background:rgba(12,127,112,.92);color:#fff;font-size:.72rem;font-weight:700;padding:.2rem .8rem;border-radius:999px
}
.demo-body{padding:1.2rem 1.3rem 1.4rem;flex:1;display:flex;flex-direction:column}
.demo-tags{display:flex;gap:.35rem;flex-wrap:wrap;margin-bottom:.6rem}
.demo-tag{
  font-size:.7rem;font-weight:600;background:rgba(20,184,166,.1);color:var(--teal-deep);padding:.1rem .6rem;border-radius:999px
}
.demo-body h3{font-family:var(--fd);font-size:1.15rem;margin-bottom:.4rem}
.demo-body p{color:var(--ink-2);font-size:.88rem;flex:1;margin-bottom:1rem}
.demo-actions{display:flex;flex-wrap:wrap;gap:.5rem;padding-top:.8rem;border-top:1px dashed var(--line)}
.demo-actions .btn{font-size:.78rem;padding:.45rem .8rem}
.demo-actions .btn svg{margin:0}
/* --- فریم دموی داخلی (پیش‌نمایش زندهٔ محصولات) --- */
.demo-frame{background:#dfe9e5;border:1px solid var(--line);border-radius:var(--r-lg);overflow:hidden;box-shadow:var(--shadow-md)}
.demo-chrome{display:flex;align-items:center;gap:.6rem;background:#eef4f1;border-bottom:1px solid var(--line);padding:.55rem .9rem}
.demo-chrome .dots{display:flex;gap:5px;flex:none}
.demo-chrome .dots span{width:10px;height:10px;border-radius:50%}
.demo-chrome .url{flex:1;direction:ltr;text-align:left;background:#fff;border:1px solid var(--line);border-radius:999px;font-family:Consolas,monospace;font-size:.78rem;color:var(--ink-3);padding:.25rem .9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.demo-stage{background:#fff;min-height:420px}
.demo-watermark{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;background:var(--teal-ink);color:#cfe9e3;padding:.8rem 1.2rem;font-size:.85rem}
.demo-watermark b{color:#fff}
/* محتوای دموها */
.d-nav{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.9rem 1.4rem;border-bottom:1px solid #e5ecea;background:#fff;flex-wrap:wrap}
.d-logo{font-family:var(--fd);font-size:1.2rem;color:var(--teal-deep)}
.d-nav nav{display:flex;gap:1.1rem;font-size:.85rem;color:var(--ink-2)}
.d-hero{padding:2.2rem 1.4rem;background:linear-gradient(135deg,rgba(20,184,166,.12),rgba(232,163,61,.10));text-align:center}
.d-hero h2{font-family:var(--fd);font-size:1.6rem;color:var(--teal-ink)}
.d-hero p{color:var(--ink-2);font-size:.9rem;max-width:46ch;margin:.3rem auto 1rem}
.d-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:1rem;padding:1.4rem}
.d-card{border:1px solid #e2ebe7;border-radius:12px;overflow:hidden;background:#fff}
.d-thumb{aspect-ratio:4/3;display:grid;place-items:center;color:#fff;font-family:var(--fd);font-size:1.05rem}
.d-card .b{padding:.7rem .8rem}
.d-card .b b{display:block;font-size:.86rem;color:var(--ink)}
.d-card .b i{font-style:normal;color:var(--teal-deep);font-weight:700;font-size:.8rem}
.d-side{display:flex;min-height:380px}
.d-side aside{width:170px;background:#0b2f2a;color:#a8d5cb;padding:1.1rem .9rem;font-size:.85rem;display:flex;flex-direction:column;gap:.4rem}
.d-side aside b{color:#fff;font-family:var(--fd);font-size:1.05rem;margin-bottom:.5rem}
.d-side aside a{color:#a8d5cb;padding:.3rem .5rem;border-radius:8px}
.d-side aside a.on{background:rgba(255,255,255,.12);color:#fff}
.d-main{flex:1;padding:1.2rem;background:#f6faf8}
.d-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:.8rem;margin-bottom:1rem}
.d-stat{background:#fff;border:1px solid #e2ebe7;border-radius:12px;padding:.8rem .9rem}
.d-stat b{display:block;font-family:var(--fd);font-size:1.2rem;color:var(--teal-deep)}
.d-stat small{color:var(--ink-3);font-size:.75rem}
.d-rows{background:#fff;border:1px solid #e2ebe7;border-radius:12px;padding:.6rem .9rem}
.d-row{display:flex;justify-content:space-between;gap:1rem;padding:.55rem .2rem;border-bottom:1px dashed #e2ebe7;font-size:.85rem;color:var(--ink-2)}
.d-row:last-child{border-bottom:0}
.d-kit{padding:1.6rem;display:grid;grid-template-columns:1fr 1fr;gap:1.4rem;align-items:start}
.d-kit h3{font-family:var(--fd);color:var(--teal-ink);font-size:1.1rem}
.d-rowbtns{display:flex;gap:.6rem;flex-wrap:wrap;align-items:center}
.d-chip{background:rgba(20,184,166,.12);color:var(--teal-deep);font-size:.78rem;font-weight:700;padding:.2rem .8rem;border-radius:999px}
.d-inputs{display:grid;gap:.6rem;max-width:380px}
.d-inputs input,.d-inputs textarea{border:1.5px solid #e2ebe7;border-radius:10px;padding:.55rem .8rem;font:inherit;font-size:.88rem;background:#fbfdfc}
.d-panel{background:#fff;border:1px solid #e2ebe7;border-radius:14px;padding:1rem 1.2rem;box-shadow:0 6px 18px rgba(8,60,52,.06)}
@media(max-width:620px){.d-side aside{width:110px}.d-stats{grid-template-columns:1fr 1fr}.d-kit{grid-template-columns:1fr}}
</style>
</head>
<body>
<header class="site-header">
  <div class="scroll-progress" id="scrollProgress"></div>
  <div class="container header-inner">
    <button class="nav-toggle" id="navToggle" aria-label="منو" aria-expanded="false" aria-controls="mainNav"><span></span><span></span><span></span></button>
    <a class="logo" href="<?= url() ?>"><?= e(BRAND_FA) ?><i class="logo-dot"></i></a>
    <nav class="main-nav" id="mainNav" aria-label="منوی اصلی">
      <?php foreach($nav as [$p,$label]): ?>
        <a class="nav-link<?= $page===$p?' is-active':'' ?>" href="<?= url($p) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
<div class="nav-auth">
         <a class="cart-link" href="<?= url('cart') ?>" title="سبد خرید"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg><?php if($cc>0): ?><span class="cart-badge"><?= fa_num($cc) ?></span><?php endif; ?></a>
      <?php if($u): ?>
        <?php if($u['role']==='admin'): ?><a class="btn btn-ghost btn-sm" href="<?= url('admin') ?>">پنل مدیریت</a><?php endif; ?>
        <a class="btn btn-outline btn-sm" href="<?= url('panel') ?>">پنل کاربری</a>
        <form method="post" class="inline-form"><input type="hidden" name="action" value="logout"><?= csrf_field() ?><button class="btn btn-soft btn-sm">خروج</button></form>
      <?php else: ?>
        <a class="btn btn-outline btn-sm" href="<?= url('login') ?>">ورود</a>
        <a class="btn btn-primary btn-sm" href="<?= url('register') ?>">ثبت‌نام</a>
      <?php endif; ?>
      </div>
<div class="nav-extra">
        <h5><?= fi('chat',15) ?>پشتیبانی</h5>
        <button type="button" class="nav-support" id="navSupport"><?= fi('chat',16) ?><span>گفتگو با پشتیبانی و دستیار هوشمند</span><i class="nav-support-dot"></i></button>
        <h5><?= fi('book',15) ?>موضوعات آموزشی</h5>
        <div class="nav-chips">
          <?php foreach(TOPICS as $slug=>$t): ?><a href="<?= url('topic').'&t='.urlencode($slug) ?>"><?= e($t['title']) ?></a><?php endforeach; ?>
        </div>
        <h5><?= fi('mail',15) ?>ارتباط</h5>
        <a href="mailto:hossaine1alli2@gmail.com">hossaine1alli2@gmail.com</a>
        <a href="tel:+989928569102">۰۹۹۲۸۵۶۹۱۰۲</a>
      </div>
    </nav>
    <form class="header-search" method="get" action="<?= url() ?>" role="search">
      <input type="hidden" name="page" value="search">
      <input type="search" name="q" value="<?= e((string)($_GET['q']??'')) ?>" placeholder="جستجوی محصول، پروژه یا مقاله…" aria-label="جستجو در سایت" autocomplete="off">
      <button type="submit" aria-label="جستجو"><?= fi('search',15) ?></button>
    </form>
    <div class="header-actions">
      <a class="cart-link" href="<?= url('cart') ?>" title="سبد خرید" aria-label="سبد خرید"><?= fi('cart',22) ?><?php if($cc>0): ?><span class="cart-badge"><?= fa_num($cc) ?></span><?php endif; ?></a>
      <?php if($u): ?>
        <?php if($u['role']==='admin'): ?><a class="btn btn-ghost btn-sm hide-sm" href="<?= url('admin') ?>">پنل مدیریت</a><?php endif; ?>
        <a class="btn btn-outline btn-sm hide-sm" href="<?= url('panel') ?>">پنل کاربری</a>
        <form method="post" class="inline-form hide-sm"><input type="hidden" name="action" value="logout"><?= csrf_field() ?><button class="btn btn-soft btn-sm">خروج</button></form>
      <?php else: ?>
        <a class="btn btn-outline btn-sm hide-sm" href="<?= url('login') ?>">ورود</a>
        <a class="btn btn-primary btn-sm hide-sm" href="<?= url('register') ?>">ثبت‌نام</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<div class="nav-backdrop" id="navBackdrop" aria-hidden="true"></div>
<main>
<?php $content(); ?>
</main>
<footer class="site-footer">
  <div class="container footer-inner">
    <div><p class="logo"><?= e(BRAND_FA) ?><i class="logo-dot"></i></p><p>ساخت وب‌سایت‌های سریع، امن و زیبا با PHP خالص. — <?= e(OWNER_NAME) ?></p></div>
    <div class="footer-links"><h4><?= fi('bolt',15) ?>دسترسی سریع</h4><a href="<?= url('portfolio') ?>">نمونه‌کارها</a><a href="<?= url('shop') ?>">فروشگاه</a><a href="<?= url('contact') ?>">تماس</a><a href="<?= url('topics') ?>">آموزش و مقالات</a></div>
    <div class="footer-links"><h4><?= fi('chat',15) ?>ارتباط</h4><a href="mailto:hossaine1alli2@gmail.com">hossaine1alli2@gmail.com</a><a href="tel:+989928569102">۰۹۹۲۸۵۶۹۱۰۲</a></div>
  </div>
  <div class="footer-bottom container"><span>© <?= j_year() ?> <?= e(BRAND_NAME) ?> — <?= e(OWNER_NAME) ?></span><span>ساخته‌شده با <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="color:var(--saffron);vertical-align:middle"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></span></div>
</footer>
<?php $agents=support_agents(); ?>
<button class="chat-fab" id="chatFab" aria-label="چت و پشتیبانی" aria-expanded="false"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><span class="chat-dot"></span></button>
<div class="chat-panel" id="chatPanel" role="dialog" aria-label="پشتیبانی">
  <div class="chat-head">
    <button class="chat-back" id="chatBack" aria-label="بازگشت"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 5 12 12 19"/></svg></button>
    <div><h3 id="chatTitle">پشتیبانی <?= e(BRAND_NAME) ?></h3><small id="chatSubtitle">سوالات متداول، پشتیبانی انسانی یا دستیار هوشمند</small></div>
    <div class="chat-head-actions">
      <button class="chat-close" id="chatClose" aria-label="بستن"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
  </div>
  <?php if($agents): ?>
  <div class="agent-bar">
    <div class="agent-avatars">
      <?php foreach($agents as $ag): ?>
      <span class="agent-av<?= $ag['online']?' is-online':'' ?>" title="<?= e($ag['name'].($ag['job_title']?' — '.$ag['job_title']:'')) ?>">
        <?php if($ag['avatar']): ?><img src="<?= e($ag['avatar']) ?>" alt="<?= e($ag['name']) ?>"><?php else: ?><?= e($ag['initial']) ?><?php endif; ?>
      </span>
      <?php endforeach; ?>
    </div>
    <span class="agent-text">
      <?php $on=array_values(array_filter($agents,fn($a)=>$a['online'])); ?>
      <?php if($on): ?><b style="color:#d7f5ec"><?= e($on[0]['name']) ?></b> و تیم پشتیبانی آنلاین هستند<?php else: ?>تیم پشتیبانی الان آفلاینه؛ پیامت ثبت میشه و پاسخ می‌گیری<?php endif; ?>
    </span>
  </div>
  <?php endif; ?>
  <div class="chat-body">
    <!-- گام ۱: سوالات متداول -->
    <div class="chat-view is-active" id="chatViewQa">
      <?php foreach(FAQ as $f): ?>
      <div class="qa-item">
        <button class="qa-q" aria-expanded="false"><span><?= e($f['q']) ?></span><i>▾</i></button>
        <div class="qa-a"><p><?= e($f['a']) ?></p></div>
      </div>
      <?php endforeach; ?>
      <?php if(!count(FAQ)): ?><p style="color:var(--ink-3);font-size:.85rem;text-align:center;padding:1rem">هنوز سوالی ثبت نشده.</p><?php endif; ?>
      <div class="chat-cta">
        <p>سوالت بین گزینه‌ها نبود؟</p>
        <button class="btn btn-primary btn-sm btn-block" id="chatGoChoices">ادامه و گفتگو</button>
      </div>
    </div>
    <!-- گام ۲: انتخاب مسیر -->
    <div class="chat-view" id="chatViewChoices">
      <div class="chat-choices">
        <button class="choice-card" data-chat-mode="human">
          <span class="choice-ic"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
          <span><span class="choice-tt">گفتگو با پشتیبانی انسانی</span><span class="choice-ds">پیامت ثبت میشه و تیم <?= e(BRAND_NAME) ?> همینجا جواب میده. تاریخچه گفتگو ذخیره میشه.</span></span>
        </button>
        <button class="choice-card gold" data-chat-mode="ai">
          <span class="choice-ic"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#e8b84b" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg></span>
          <span><span class="choice-tt">پرسیدن از دستیار هوشمند <?= e(BOT_NAME) ?></span><span class="choice-ds">پاسخ سریع دربارهٔ محصولات، قیمت و روند خرید — فقط بر پایهٔ اطلاعات ثبت‌شده.</span></span>
        </button>
      </div>
    </div>
    <!-- گام ۳: گفتگو -->
    <div class="chat-view" id="chatViewThread">
      <div class="chat-msgs" id="chatMsgs"></div>
    </div>
  </div>
  <div class="chat-input-row" id="chatInputRow">
    <input type="text" id="chatQuestion" maxlength="500" placeholder="پیامت رو بنویس…" aria-label="متن پیام" autocomplete="off">
    <button class="btn btn-primary btn-sm chat-send" id="chatSend">ارسال</button>
  </div>
  <div class="chat-note" id="chatNote">پاسخ‌ها جنبهٔ راهنمایی دارن. برای موضوعات فنی از فرم تماس هم می‌تونی استفاده کنی.</div>
</div>
<div class="toast-wrap" id="toastWrap" aria-live="polite"></div>
<script nonce="<?= e(csp_nonce()) ?>">
window.__TOASTS__=<?= json_encode(take_flash(),JSON_UNESCAPED_UNICODE|JSON_HEX_TAG) ?>;
const TI={success:'✓',error:'✕',info:'i',warning:'!'};
function showToast(t,m){const w=document.getElementById('toastWrap');const el=document.createElement('div');el.className='toast toast-'+t;const ic=document.createElement('span');ic.className='toast-icon';ic.textContent=TI[t]||'';const sp=document.createElement('span');sp.textContent=m;el.append(ic,sp);w.appendChild(el);requestAnimationFrame(()=>el.classList.add('show'));setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),400)},4200);}
(__TOASTS__||[]).forEach(t=>showToast(t.type,t.message));
const toFa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const fmtMoney=v=>toFa(Number(v||0).toLocaleString('en-US',{maximumFractionDigits:0}))+' تومان';
const navToggle=document.getElementById('navToggle'),mainNav=document.getElementById('mainNav'),navBackdrop=document.getElementById('navBackdrop');
function navSet(open){
  mainNav.classList.toggle('open',open);
  navToggle.classList.toggle('open',open);
  navToggle.setAttribute('aria-expanded',open);
  if(navBackdrop)navBackdrop.classList.toggle('open',open);
  document.body.style.overflow=open?'hidden':'';
}

/* منو همیشه در حالت بسته لود می‌شود (موبایل و دسکتاپ) */
navSet(false);
/* بستن منو هنگام بزرگ‌نمایی پنجره */
const mqDesktop=matchMedia('(min-width:981px)');
mqDesktop.addEventListener('change',e=>{if(e.matches&&mainNav.classList.contains('open'))navSet(false);});
navToggle.addEventListener('click',()=>navSet(!mainNav.classList.contains('open')));
if(navBackdrop)navBackdrop.addEventListener('click',()=>navSet(false));
mainNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>navSet(false)));
addEventListener('keydown',ev=>{if(ev.key==='Escape'&&mainNav.classList.contains('open'))navSet(false);});
const pb=document.getElementById('scrollProgress');
addEventListener('scroll',()=>{const mx=document.documentElement.scrollHeight-innerHeight;pb.style.width=(mx>0?(scrollY/mx)*100:0)+'%';},{passive:true});
if('IntersectionObserver' in window){
const ro=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');ro.unobserve(e.target);}})},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>ro.observe(el));
}else{
document.querySelectorAll('.reveal').forEach(el=>el.classList.add('in'));
}
/* شبکهٔ ایمنی: هر عنصر reveal که در اولین لود داخل دید است بی‌درنگ نمایان شود */
document.querySelectorAll('.reveal:not(.in)').forEach(el=>{const r=el.getBoundingClientRect();if(r.top<innerHeight&&r.bottom>0)el.classList.add('in');});
const bo=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.style.width=e.target.dataset.level+'%';bo.unobserve(e.target);}})},{threshold:.4});
document.querySelectorAll('.bar-fill').forEach(el=>bo.observe(el));
const co=new IntersectionObserver(es=>{es.forEach(e=>{if(!e.isIntersecting)return;const el=e.target,raw=el.dataset.count||'0',tg=parseFloat(raw)||0,dec=(raw.split('.')[1]||'').length,st=performance.now(),du=1400;const fmt=v=>toFa(dec?v.toFixed(dec):String(Math.round(v)));const tick=n=>{const p=Math.min((n-st)/du,1);el.textContent=fmt(tg*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(tick);else el.textContent=fmt(tg);};requestAnimationFrame(tick);co.unobserve(el);})},{threshold:.5});
document.querySelectorAll('[data-count]').forEach(el=>co.observe(el));
const roleEl=document.getElementById('roleTyper');
if(roleEl){const roles=JSON.parse(roleEl.dataset.roles||'[]');let ri=0,ci=0,del=false;(function tick(){const w=roles[ri]||'';ci+=del?-1:1;roleEl.textContent=w.slice(0,ci);let d=del?45:95;if(!del&&ci===w.length){d=1800;del=true;}else if(del&&ci===0){del=false;ri=(ri+1)%roles.length;d=350;}setTimeout(tick,d);})();}
const fbs=document.querySelectorAll('.filter-btn');
if(fbs.length){fbs.forEach(b=>b.addEventListener('click',()=>{fbs.forEach(x=>x.classList.remove('is-active'));b.classList.add('is-active');const tg=b.dataset.filter;document.querySelectorAll('.project-card').forEach(c=>{const s=tg==='all'||c.dataset.tags.split(',').includes(tg);c.classList.toggle('is-hidden',!s);});}));}
document.querySelectorAll('form[data-confirm]').forEach(f=>{f.addEventListener('submit',ev=>{if(!confirm(f.dataset.confirm))ev.preventDefault();});});
/* جمع زندهٔ سبد خرید */
function recalcRow(row){
  const price=parseFloat(row.dataset.price)||0;
  const max=parseInt(row.dataset.max,10)||99;
  const inp=row.querySelector('[data-qty]');
  let q=parseInt(inp.value,10); if(isNaN(q))q=0;
  q=Math.max(0,Math.min(q,max,99));
  if(q>0&&parseInt(inp.value,10)!==q){ inp.value=q; }
  row.querySelector('.qty-step[data-step="-1"]').disabled=q<=1;
  row.querySelector('.qty-step[data-step="1"]').disabled=q>=Math.min(max,99);
  row.querySelector('[data-line-total]').textContent=fmtMoney(price*q);
  const id=row.dataset.id;
  const sum=document.querySelector('[data-summary-row][data-id="'+id+'"]');
  if(sum){sum.querySelector('[data-sum-qty]').textContent=toFa(q);
    sum.querySelector('[data-sum-line]').textContent=fmtMoney(price*q);}
  let total=0;
  document.querySelectorAll('[data-cart-row]').forEach(r=>{
    const p=parseFloat(r.dataset.price)||0;
    const qq=parseInt(r.querySelector('[data-qty]').value,10)||0;
    total+=p*Math.max(0,qq);
  });
  const tt=document.querySelector('[data-total]'); if(tt)tt.textContent=fmtMoney(total);
}
const cartPage=document.getElementById('cartPage');
if(cartPage){
  cartPage.querySelectorAll('[data-cart-row]').forEach(row=>{
    const inp=row.querySelector('[data-qty]');
    inp.addEventListener('input',()=>recalcRow(row));
    row.querySelectorAll('.qty-step').forEach(b=>b.addEventListener('click',()=>{
      const d=parseInt(b.dataset.step,10)||0;
      inp.value=(parseInt(inp.value,10)||0)+d;
      recalcRow(row);
    }));
    recalcRow(row);
  });
}
/* سابمیت خودکار select وضعیت سفارش (بدون inline handler) */
document.querySelectorAll('select.auto-submit').forEach(s=>s.addEventListener('change',()=>s.form.submit()));
/* ============================================================
   ویجت چت: سوالات متداول → انتخاب مسیر → گفتگو (انسانی/دستیار)
   ============================================================ */
const chatFab=document.getElementById('chatFab'),chatPanel=document.getElementById('chatPanel'),
      chatClose=document.getElementById('chatClose'),chatBack=document.getElementById('chatBack'),
      chatTitle=document.getElementById('chatTitle'),chatSubtitle=document.getElementById('chatSubtitle'),
      chatNote=document.getElementById('chatNote'),chatInputRow=document.getElementById('chatInputRow'),
      chatInput=document.getElementById('chatQuestion'),chatSend=document.getElementById('chatSend'),
      chatMsgs=document.getElementById('chatMsgs'),
      navSupport=document.getElementById('navSupport');
const BOT_LABEL=<?= json_encode(BOT_NAME,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG) ?>;
const CHAT_CSRF=()=>(document.querySelector('meta[name="csrf-token"]')||{}).content||'';
let chatStep='qa', chatMode=null, chatLastId=0, chatPoller=null;
function chatShow(step){
  chatStep=step;
  document.querySelectorAll('.chat-panel .chat-view').forEach(v=>v.classList.remove('is-active'));
  const map={qa:'chatViewQa',choices:'chatViewChoices',thread:'chatViewThread'};
  const el=document.getElementById(map[step]); if(el)el.classList.add('is-active');
  if(chatBack)chatBack.classList.toggle('show',step!=='qa');
  if(chatInputRow)chatInputRow.classList.toggle('show',step==='thread');
  if(step==='qa'){
    chatTitle.textContent='پشتیبانی <?= e(BRAND_NAME) ?>';
    chatSubtitle.textContent='سوالات متداول، پشتیبانی انسانی یا دستیار هوشمند';
    chatNote.textContent='پاسخ‌ها جنبهٔ راهنمایی دارن. برای موضوعات فنی از فرم تماس هم می‌تونی استفاده کنی.';
  }else if(step==='choices'){
    chatTitle.textContent='چطور کمکت کنم؟';
    chatSubtitle.textContent='یکی از دو مسیر زیر رو انتخاب کن';
    chatNote.textContent='گفتگوت ذخیره میشه تا بعداً هم بتونی ادامه بدی.';
  }else{
    chatTitle.textContent=chatMode==='human'?'گفتگو با پشتیبانی':('دستیار هوشمند '+BOT_LABEL);
    chatSubtitle.textContent=chatMode==='human'?'پیام‌ها برای تیم پشتیبانی ثبت میشه':'پاسخ‌ها بر پایهٔ اطلاعات ثبت‌شده است';
    chatNote.textContent=chatMode==='human'?'اگر آفلاین باشیم، پیامت ثبت میشه و همینجا جواب می‌گیری.':'اگر جوابی در دانشِ من نباشه، حدس نمی‌زنم و به پشتیبانی وصلت می‌کنم.';
  }
}
function chatToggle(force){
  const open=force!==undefined?force:!chatPanel.classList.contains('open');
  chatPanel.classList.toggle('open',open);
  chatFab.setAttribute('aria-expanded',open);
  if(open){ chatFab.classList.remove('has-news'); if(chatStep==='thread')chatPollStart(); }
  else chatPollStop();
}
function chatPost(payload){
  const body=new URLSearchParams();
  body.append('csrf',CHAT_CSRF());
  Object.keys(payload).forEach(k=>body.append(k,payload[k]));
  return fetch(location.pathname+location.search,{method:'POST',headers:{'X-Requested-With':'XMLHttpRequest'},credentials:'same-origin',body:body})
    .then(r=>r.json());
}
function chatBubble(role,text,who){
  const div=document.createElement('div');
  div.className='chat-msg '+(role==='user'?'user':(role==='admin'?'admin':'bot'));
  if(who){ const s=document.createElement('span'); s.className='msg-who'; s.textContent=who; div.appendChild(s); }
  const t=document.createElement('span'); t.textContent=text; div.appendChild(t);
  chatMsgs.appendChild(div);
  chatMsgs.scrollTop=chatMsgs.scrollHeight;
  return div;
}
function chatRender(list){
  chatMsgs.textContent='';
  chatLastId=0;
  (list||[]).forEach(m=>{
    chatBubble(m.role,m.body,m.role==='admin'?'پشتیبانی':(m.role==='bot'?BOT_LABEL:''));
    if(m.id>chatLastId)chatLastId=m.id;
  });
}
function chatPollStop(){ if(chatPoller){clearInterval(chatPoller);chatPoller=null;} }
function chatPollStart(){
  chatPollStop();
  if(chatMode!=='human')return;
  chatPoller=setInterval(()=>{
    chatPost({action:'chat_poll',after:chatLastId}).then(d=>{
      if(!d.ok)return;
      (d.messages||[]).forEach(m=>{
        chatBubble(m.role,m.body,m.role==='admin'?'پشتیبانی':(m.role==='bot'?BOT_LABEL:''));
        if(m.id>chatLastId)chatLastId=m.id;
        if(m.role!=='user'&&!chatPanel.classList.contains('open'))chatFab.classList.add('has-news');
      });
    }).catch(()=>{});
  },7000);
}
function chatStart(mode){
  chatMode=mode;
  chatShow('thread');
  chatMsgs.textContent='';
  const wait=chatBubble('bot','در حال آماده‌سازی گفتگو…',null);
  chatPost({action:'chat_start',mode:mode}).then(d=>{
    if(!d.ok){ wait.textContent=d.message||'شروع گفتگو ممکن نشد.'; return; }
    chatMode=d.mode||mode;
    if(d.history&&d.history.length)chatRender(d.history);
    else{
      chatMsgs.textContent='';
      chatBubble('bot',chatMode==='human'
        ?'سلام! پیامت رو بنویس؛ برای تیم پشتیبانی ثبت میشه و همینجا جواب می‌گیری.'
        :('سلام! من '+BOT_LABEL+' هستم، دستیار هوشمند <?= e(BRAND_NAME) ?>. دربارهٔ محصولات، قیمت و روند خرید بپرس.'),
        chatMode==='human'?null:BOT_LABEL);
    }
    chatShow('thread');
    chatPollStart();
    chatInput.focus();
  }).catch(()=>{ wait.textContent='خطا در ارتباط با سرور. دوباره تلاش کن.'; });
}
function chatSubmit(){
  const q=chatInput.value.trim();
  if(!q||chatSend.disabled||chatStep!=='thread')return;
  chatBubble('user',q);
  chatInput.value='';
  chatSend.disabled=true;
  const act=chatMode==='human'?'chat_send':'ask_ai';
  let typing=null;
  if(chatMode!=='human'){
    typing=document.createElement('div');
    typing.className='chat-typing';
    typing.innerHTML='<span></span><span></span><span></span>';
    chatMsgs.appendChild(typing);
    chatMsgs.scrollTop=chatMsgs.scrollHeight;
  }
  chatPost({action:act,q:q}).then(d=>{
    if(typing)typing.remove();
    if(!d.ok){ chatBubble('bot',d.message||'ارسال ناموفق بود.',null); return; }
    if(d.id&&d.id>chatLastId)chatLastId=d.id;
    if(chatMode==='human'){ chatPollStart(); }
    else chatBubble('bot',d.message||'پاسخی یافت نشد.',BOT_LABEL);
  }).catch(()=>{ if(typing)typing.remove(); chatBubble('bot','خطا در ارتباط با سرور. دوباره تلاش کن.',null); })
    .finally(()=>{ chatSend.disabled=false; chatInput.focus(); chatMsgs.scrollTop=chatMsgs.scrollHeight; });
}
if(chatFab){
  chatFab.addEventListener('click',()=>chatToggle());
  if(chatClose)chatClose.addEventListener('click',()=>chatToggle(false));
  if(chatBack)chatBack.addEventListener('click',()=>{ chatPollStop(); chatShow(chatStep==='thread'?'choices':'qa'); });
  document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&chatPanel.classList.contains('open'))chatToggle(false);});
  const goChoices=document.getElementById('chatGoChoices');
  if(goChoices)goChoices.addEventListener('click',()=>chatShow('choices'));
  document.querySelectorAll('[data-chat-mode]').forEach(b=>b.addEventListener('click',()=>chatStart(b.dataset.chatMode)));
}
if(navSupport){
  navSupport.addEventListener('click',()=>{ navSet(false); chatToggle(true); });
}
document.querySelectorAll('.chat-panel .qa-item').forEach(item=>{
  const q=item.querySelector('.qa-q'),a=item.querySelector('.qa-a');
  q.addEventListener('click',()=>{
    const open=a.classList.toggle('open');
    q.classList.toggle('open',open);
    q.setAttribute('aria-expanded',open);
  });
});
if(chatSend&&chatInput){
  chatSend.addEventListener('click',chatSubmit);
  chatInput.addEventListener('keydown',ev=>{if(ev.key==='Enter')chatSubmit();});
}
</script>
<?php clear_old(); ?>
</body>
</html>
<?php }

/* ============================================================
   صفحات عمومی
   ============================================================ */
function page_home():void{ layout('صفحهٔ اصلی',function(){ $preview=array_slice(projects(),0,3); ?>
<section class="hero"><div class="container hero-grid">
  <div class="reveal">
    <p class="status-chip"><span class="pulse-dot"></span> آمادهٔ همکاری پروژه‌ای</p>
    <h1 class="hero-name">حسین <span>امیان</span></h1>
    <p class="hero-role">من <span id="roleTyper" class="role-typer" data-roles='["توسعه‌دهندهٔ Full-Stack","طراح رابط کاربری","متخصص PHP و MySQL","علاقه‌مند به تجارت الکترونیک"]'></span><span class="caret"></span></p>
    <p class="hero-desc">بیش از 2.5 ساله که وب‌سایت‌ها و فروشگاه‌های سریع، امن و قابل‌اتکا طراحی میکنم؛ از طراحی رابط کاربری تا بک‌اند PHP و دیتابیس.</p>
    <div class="hero-actions"><a class="btn btn-primary" href="<?= url('portfolio') ?>">مشاهدهٔ نمونه‌کارها</a><a class="btn btn-outline" href="<?= url('shop') ?>">فروشگاه</a></div>
    <ul class="hero-meta"><li><em><?= fi('target',17) ?></em><b>2.5+</b> سال تجربه</li><li><em><?= fi('check',17) ?></em><b>20</b> پروژهٔ موفق</li><li><em><?= fi('pin',17) ?></em><b>شیراز</b> / ریموت</li></ul>
  </div>
  <div class="hero-visual reveal" style="--d:.15s">
    <div class="terminal"><div class="terminal-bar"><span></span><span></span><span></span><em>developer.php</em></div>
<pre class="terminal-code"><code><span class="tk-c">// developer.php</span>
<span class="tk-k">class</span> <span class="tk-f">Developer</span> {
  <span class="tk-k">public</span> <span class="tk-v">$name</span>  = <span class="tk-s">'Hossein Amyan'</span>;
  <span class="tk-k">public array</span> <span class="tk-v">$stack</span> = [<span class="tk-s">'PHP'</span>, <span class="tk-s">'MySQL'</span>, <span class="tk-s">'JS'</span>];
  <span class="tk-k">public function</span> <span class="tk-f">build</span>(<span class="tk-v">$idea</span>) {
    <span class="tk-k">return new</span> <span class="tk-f">Product</span>(<span class="tk-v">$idea</span>); <span class="tk-c">// idea → product</span>
  }
}</code></pre></div>
    <img class="hero-avatar" src="assets/images/avatar-hossein.svg" alt="حسین امیان">
  </div>
</div></section>
<div class="marquee"><div class="marquee-track">
  <?php for($rep=0;$rep<2;$rep++): ?>
  <span<?= $rep?' aria-hidden="true"':'' ?>><?php $i=0; foreach(TOPICS as $slug=>$t): ?><?php if($i++): ?><i>✦</i><?php endif; ?><a href="<?= url('topic').'&t='.urlencode($slug) ?>" title="<?= e($t['lead']) ?>"><?= e($t['title']) ?></a><?php endforeach; ?><i>✦</i></span>
  <?php endfor; ?>
</div></div>
<section class="stats-band"><div class="container stats-grid">
  <div class="stat-item reveal"><div class="stat-num"><span data-count="2.5">۰</span>+</div><div class="stat-label">سال تجربه</div></div>
  <div class="stat-item reveal" style="--d:.1s"><div class="stat-num"><span data-count="20">۰</span></div><div class="stat-label">پروژهٔ تحویل‌شده</div></div>
  <div class="stat-item reveal" style="--d:.2s"><div class="stat-num"><span data-count="20">۰</span></div><div class="stat-label">مشتری راضی</div></div>
  <div class="stat-item reveal" style="--d:.3s"><div class="stat-num"><span data-count="500">۰</span>+</div><div class="stat-label">فنجان قهوه</div></div>
</div></section>
<section class="section"><div class="container">
  <div class="section-head reveal"><span class="kicker">مهارت‌ها</span><h2 class="section-title">ابزارهای مورد استفاده: </h2></div>
  <div class="skills-grid">
    <div class="reveal">
      <div class="skill-row"><div class="skill-head"><span>PHP / MySQL / Laravel</span><b>۹۲٪</b></div><div class="bar"><div class="bar-fill" data-level="92"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>HTML / CSS / Tailwind / JS</span><b>۹۵٪</b></div><div class="bar"><div class="bar-fill" data-level="95"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>Python / اتوماسیون</span><b>۷۵٪</b></div><div class="bar"><div class="bar-fill" data-level="75"></div></div></div>
    </div>
    <div class="reveal" style="--d:.15s">
      <div class="skill-row"><div class="skill-head"><span>طراحی UI/UX (Figma)</span><b>۷۸٪</b></div><div class="bar"><div class="bar-fill" data-level="78"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>Laravel</span><b>۸۸٪</b></div><div class="bar"><div class="bar-fill" data-level="88"></div></div></div>
      <div class="skill-row"><div class="skill-head"><span>Git / DevOps پایه</span><b>۷۰٪</b></div><div class="bar"><div class="bar-fill" data-level="70"></div></div></div>
    </div>
  </div>
</div></section>
<section class="section section-alt"><div class="container">
  <div class="section-head reveal"><span class="kicker"><?= fi('image',16) ?>نمونه‌کارها</span><h2 class="section-title">گزیده‌ای از پروژه‌های اخیر</h2></div>
  <div class="portfolio-grid">
  <?php foreach($preview as $p): ?>
    <article class="project-card reveal">
      <span class="project-year"><?= e($p['year']) ?></span>
      <div class="project-media"><img src="<?= e($p['image']) ?>" alt="<?= e($p['title']) ?>" loading="lazy"></div>
      <div class="project-body">
        <div class="project-tags"><?php foreach($p['tags'] as $t): ?><span class="tag<?= $t==='shop'?' tag-gold':'' ?>"><?= e(TAG_LABEL[$t]??$t) ?></span><?php endforeach; ?></div>
        <h3><?= e($p['title']) ?></h3><p><?= e($p['desc']) ?></p>
        <a class="project-link" href="<?= url('portfolio') ?>">دیدن پروژه</a>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
  <p style="margin-top:2rem" class="reveal"><a class="btn btn-outline" href="<?= url('portfolio') ?>">بخشی از نمونه‌کارها</a></p>
</div></section>
<section class="section"><div class="container">
  <div class="cta-band reveal"><div><h2>ایده‌متفاوتی دارین؟</h2><p>اگه نیاز به راهنمایی و گفت و گوی بیشتر داشتید:</p></div><a class="btn btn-saffron" href="<?= url('contact') ?>">شروع همکاری</a></div>
</div></section>
<section class="section section-alt"><div class="container">
  <div class="section-head reveal"><span class="kicker"><?= fi('image',16) ?>دموهای زنده</span><h2 class="section-title">پیش‌نمایش محصولات را همین‌جا ببینید</h2></div>
  <div class="demo-grid">
    <?php foreach(db()->query("SELECT id,title,description,price,stock,image,slug FROM products WHERE status='published' ORDER BY id LIMIT 6")->fetchAll() as $d):
      $dt=DEMO_TYPE[$d['slug']]??['label'=>'پیش‌نمایش محصول','tags'=>['دموی زنده']]; $din=(int)$d['stock']>0; ?>
    <article class="demo-card reveal">
      <div class="demo-media">
        <img src="<?= e((string)$d['image']) ?>" alt="<?= e($d['title']) ?>" loading="lazy">
        <span class="demo-type"><?= e($dt['label']) ?></span>
      </div>
      <div class="demo-body">
        <div class="demo-tags"><?php foreach($dt['tags'] as $t): ?><span class="demo-tag"><?= e($t) ?></span><?php endforeach; ?></div>
        <h3><?= e($d['title']) ?></h3>
        <p><?= e(mb_substr((string)$d['description'],0,110)) ?>…</p>
        <div class="demo-actions">
          <a class="btn btn-primary btn-sm" href="<?= url('demo').'&id='.(int)$d['id'] ?>"><?= fi('image',14) ?> دموی زنده</a>
          <form method="post" class="inline-form">
            <input type="hidden" name="action" value="add_to_cart"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="btn btn-outline btn-sm"<?= $din?'':' disabled' ?>><?= $din?'خرید سریع':'ناموجود' ?></button>
          </form>
        </div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
</div></section>
<?php }); }

/* ---------- دموی داخلی محصولات: پیش‌نمایش زندهٔ امن (بدون افشای سورس واقعی) ---------- */
function page_demo():void{
  $st=db()->prepare("SELECT * FROM products WHERE id=? AND status='published' LIMIT 1");
  $st->execute([(int)($_GET['id']??0)]); $p=$st->fetch();
  if(!$p){ flash('error','دموی این محصول پیدا نشد.'); redirect(url('shop')); }
  layout('دموی زندهٔ '.$p['title'],function()use($p){
    $slug=(string)$p['slug']; $in=(int)$p['stock']>0; ?>
<section class="section" style="padding-top:2rem"><div class="container">
  <p class="breadcrumb"><a href="<?= url() ?>">خانه</a> / <a href="<?= url('shop') ?>">فروشگاه</a> / دموی <?= e($p['title']) ?></p>
  <div class="page-title-row"><h1 style="font-family:var(--fd);font-size:1.7rem">دموی زندهٔ <?= e($p['title']) ?></h1></div>
  <div class="demo-frame">
    <div class="demo-chrome">
      <span class="dots"><span style="background:#ff5f57"></span><span style="background:#febc2e"></span><span style="background:#28c840"></span></span>
      <span class="url"><?= e(((!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').($_SERVER['REQUEST_URI']??'')) ?></span>
    </div>
    <div class="demo-stage">
      <?php if(str_contains($slug,'azarin')): ?>
      <div class="d-nav"><span class="d-logo">آذین شاپ</span><nav><span>خانه</span><span>فروشگاه</span><span>وبلاگ</span><span>تماس</span></nav></div>
      <div class="d-hero"><h2>فروشگاه تخصصی پوشاک</h2><p>این یک پیش‌نمایش با دادهٔ نمایشی است؛ چیدمان، تایپوگرافی و رنگ‌بندی را ببینید.</p><span class="btn btn-primary btn-sm" style="pointer-events:none">شروع خرید</span></div>
      <div class="d-grid">
        <?php $thumbs=['پیراهن','کتانی','کیف','ساعت','شال','عینک']; $grads=['#0c7f70,#14b8a6','#0b3b74,#6366f1','#b45309,#f59e0b','#9d174d,#ec4899','#065f46,#10b981','#4c1d95,#8b5cf6']; foreach($thumbs as $k=>$t): ?>
        <div class="d-card"><div class="d-thumb" style="background:linear-gradient(135deg,<?= $grads[$k] ?>)"><?= e($t) ?></div><div class="b"><b><?= e($t) ?> نمونه</b><i><?= money(298000+$k*137000) ?></i></div></div>
        <?php endforeach; ?>
      </div>
      <?php elseif(str_contains($slug,'cms')): ?>
      <div class="d-side">
        <aside><b>پنل سبک</b><a class="on">داشبورد</a><a>نوشته‌ها</a><a>صفحه‌ها</a><a>رسانه</a><a>دیدگاه‌ها</a><a>تنظیمات</a></aside>
        <div class="d-main">
          <div class="d-stats">
            <div class="d-stat"><b>۱۲</b><small>نوشته منتشرشده</small></div>
            <div class="d-stat"><b>۴</b><small>پیش‌نویس</small></div>
            <div class="d-stat"><b>۸۶</b><small>دیدگاه</small></div>
          </div>
          <div class="d-rows">
            <?php $rows=[['راهنمای نصب اسکریپت','۱۴۰۳/۰۵/۱۲'],['بهینه‌سازی کوئری MySQL','۱۴۰۳/۰۵/۰۹'],['معرفی نسخهٔ ۲.۱','۱۴۰۳/۰۴/۳۰'],['ساختار جدول کاربران','۱۴۰۳/۰۴/۲۲'],['نکات امنیتی پنل','۱۴۰۳/۰۴/۱۸']]; foreach($rows as $r): ?>
            <div class="d-row"><span><?= e($r[0]) ?></span><small><?= e($r[1]) ?></small></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php elseif(str_contains($slug,'ui')): ?>
      <div class="d-kit">
        <div><h3>دکمه‌ها</h3><div class="d-rowbtns" style="margin-top:.6rem"><span class="btn btn-primary btn-sm" style="pointer-events:none">اصلی</span><span class="btn btn-outline btn-sm" style="pointer-events:none">خط‌دار</span><span class="btn btn-saffron btn-sm" style="pointer-events:none">زعفرانی</span><span class="btn btn-soft btn-sm" style="pointer-events:none">مخرب</span></div></div>
        <div><h3>نشان‌ها</h3><div class="d-rowbtns" style="margin-top:.6rem"><span class="d-chip">جدید</span><span class="d-chip">پرفروش</span><span class="d-chip">تخفیف‌دار</span><span class="d-chip">ناموجود</span></div></div>
        <div><h3>فیلدها</h3><div class="d-inputs" style="margin-top:.6rem"><input type="text" placeholder="نام کاربری" disabled><input type="email" placeholder="ایمیل" disabled><textarea rows="2" placeholder="پیام شما…" disabled></textarea></div></div>
        <div class="d-panel"><b style="font-size:.92rem">کارت نمونه</b><p style="font-size:.85rem;color:var(--ink-2);margin-top:.3rem">توکن‌های رنگ، فاصله و شعاع یکسان در همهٔ کامپوننت‌ها اعمال شده‌اند.</p></div>
      </div>
      <?php else: ?>
      <div class="d-hero" style="padding:4rem 1.4rem"><h2>پیش‌نمایش این محصول به‌زودی</h2><p>فعلاً تصاویر و توضیحات محصول را در فروشگاه ببینید.</p></div>
      <?php endif; ?>
    </div>
    <div class="demo-watermark">
      <span><b>نسخهٔ نمایشی</b> — این صفحه فقط دادهٔ نمایشی دارد؛ سورس کامل محصول تنها پس از خرید تحویل داده می‌شود.</span>
      <form method="post" class="inline-form">
        <input type="hidden" name="action" value="add_to_cart"><?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
        <button class="btn btn-saffron btn-sm"<?= $in?'':' disabled' ?>><?= $in?'خرید و تحویل سورس ('.money($p['price']).')':'ناموجود' ?></button>
      </form>
    </div>
  </div>
  <p style="margin-top:1.4rem;color:var(--ink-3);font-size:.85rem">دمو، خودِ محصول نیست؛ فقط طراحی و چیدمان را نشان می‌دهد. فایل‌های واقعی (سورس) پس از پرداخت موفق، در پنل کاربری فعال می‌شوند.</p>
</div></section>
<?php }); }

function page_about():void{ layout('دربارهٔ من',function(){ ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / دربارهٔ من</p><h1>کمی بیشتر دربارهٔ من</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container about-grid">
  <div class="about-photo reveal"><img src="assets/images/avatar-hossein.svg" alt="حسین امیان"></div>
  <div class="reveal" style="--d:.1s">
    <span class="kicker"><?= fi('user',16) ?>معرفی</span>
    <h2 class="section-title">از نظر من همه جزئیات یه پروژه خیلی مهمه</h2>
    <p class="section-lead"> اولویت من اینه که سایت یا اپی که نوشته میشه بهتره هم زیبا و هم کارآمد باشه</p>
    <div class="values">
      <div class="value"><h4>کد تمیز</h4><p>ساختار ماژولار و قابل نگهداری.</p></div>
      <div class="value"><h4>اول امنیت بعد شروع</h4><p>اعتبارسنجی و دفاع در هر لایه.</p></div>
      <div class="value"><h4> ساختار و زمان بندی تحویل</h4><p>ساختار مطابق با میل شما و برنامه ریزی شفاف و منظم</p></div>
      <div class="value"><h4>یادگیری مداوم</h4><p>به‌روز با تکنولوژی‌های روز.</p></div>
    </div>
  </div>
</div></section>
<?php }); }

function page_portfolio():void{ layout('نمونه‌کارها',function(){ $filters=['all'=>'همه','web'=>'وب‌سایت','shop'=>'فروشگاه','app'=>'اپلیکیشن','ui'=>'رابط کاربری']; ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / نمونه‌کارها</p><h1>نمونه‌کارهای من</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <div class="filter-bar reveal"><?php foreach($filters as $k=>$l): ?><button class="filter-btn<?= $k==='all'?' is-active':'' ?>" data-filter="<?= e($k) ?>"><?= e($l) ?></button><?php endforeach; ?></div>
  <div class="portfolio-grid">
  <?php foreach(projects() as $p): ?>
    <article class="project-card reveal" data-tags="<?= e(implode(',',$p['tags'])) ?>">
      <span class="project-year"><?= e($p['year']) ?></span>
      <div class="project-media"><img src="<?= e($p['image']) ?>" alt="<?= e($p['title']) ?>" loading="lazy"></div>
      <div class="project-body">
        <div class="project-tags"><?php foreach($p['tags'] as $t): ?><span class="tag<?= $t==='shop'?' tag-gold':'' ?>"><?= e(TAG_LABEL[$t]??$t) ?></span><?php endforeach; ?></div>
        <h3><?= e($p['title']) ?></h3><p><?= e($p['desc']) ?></p>
        <a class="project-link" href="<?= url('contact') ?>">سفارش پروژهٔ مشابه</a>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
</div></section>
<?php }); }

function page_shop():void{ layout('فروشگاه',function(){
  $products=db()->query("SELECT * FROM products WHERE status='published' ORDER BY created_at DESC")->fetchAll(); ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / فروشگاه</p><h1>فروشگاه محصولات دیجیتال</h1><p class="section-lead">محصولات را به سبد اضافه کنید و پرداخت را (به‌صورت شبیه‌سازی‌شده) تجربه کنید.</p></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <script type="application/ld+json" nonce="<?= e(csp_nonce()) ?>"><?= json_encode(['@context'=>'https://schema.org','@type'=>'ItemList','itemListElement'=>array_map(fn($i,$p)=>['@type'=>'ListItem','position'=>$i+1,'item'=>['@type'=>'Product','name'=>$p['title'],'description'=>mb_substr((string)$p['description'],0,160),'image'=>site_base_url().'/'.ltrim((string)$p['image'],'/'),'offers'=>['@type'=>'Offer','price'=>(float)$p['price'],'priceCurrency'=>'IRR','availability'=>((int)$p['stock']>0?'https://schema.org/InStock':'https://schema.org/OutOfStock')]]],array_keys($products),array_values($products))],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG) ?></script>
  <?php if(!$products): ?><div class="empty-state card">هنوز محصولی منتشر نشده است.</div>
  <?php else: ?><div class="shop-grid">
    <?php foreach($products as $p): $inStock=(int)$p['stock']>0; ?>
    <article class="product-card reveal" id="p<?= (int)$p['id'] ?>">
      <div class="product-media"><img src="<?= e($p['image']??'') ?>" alt="<?= e($p['title']) ?>" loading="lazy">
        <span class="product-stock<?= !$inStock?' out':((int)$p['stock']<=5?' low':'') ?>"><?= $inStock?'موجود ('.fa_num($p['stock']).')':'ناموجود' ?></span></div>
      <div class="product-body">
        <h3><?= e($p['title']) ?></h3><p><?= e(mb_substr((string)$p['description'],0,70)) ?>…</p>
        <div class="product-foot"><span class="price"><?= money($p['price']) ?></span>
          <form method="post" class="inline-form"><input type="hidden" name="action" value="add_to_cart"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="btn btn-sm btn-primary"<?= $inStock?'':' disabled' ?>><?= $inStock?'افزودن به سبد':'ناموجود' ?></button>
          </form>
        </div>
      </div>
    </article>
    <?php endforeach; ?>
  </div><?php endif; ?>
</div></section>
<?php },'خرید قالب، اسکریپت و کیت رابط کاربری — محصولات دیجیتال '.BRAND_FA.' با پرداخت شبیه‌سازی‌شده و تحویل پس از تأیید.'); }

function page_contact():void{ layout('تماس با من',function(){ ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / تماس با من</p><h1>بیایید گفت‌وگو کنیم</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container contact-grid">
  <div class="reveal">
    <span class="kicker"><?= fi('mail',16) ?>راه‌های ارتباطی</span><h2 class="section-title">در دسترس هستم</h2>
    <p class="section-lead">برای سفارش پروژه، مشاوره تماس بگیرید</p>
    <ul class="info-list"><li><span>ایمیل</span><b>hossaine1alli2@gmail.com</b></li><li><span>تلفن</span><b>۰۹۹۲۸۵۶۹۱۰۲</b></li><li><span>آدرس</span><b>ایران، استان فارس، شیراز</b></li></ul>
  </div>
  <div class="card reveal" style="--d:.1s">
    <h2>ارسال پیام</h2>
    <form method="post">
      <input type="hidden" name="action" value="contact"><?= csrf_field() ?>
      <div class="form-field"><label for="c-name">نام</label><input id="c-name" type="text" name="name" value="<?= old('name') ?>" required></div>
      <div class="form-field"><label for="c-email">ایمیل</label><input id="c-email" type="email" name="email" value="<?= old('email') ?>" required></div>
      <div class="form-field"><label for="c-subject">موضوع</label><input id="c-subject" type="text" name="subject" value="<?= old('subject') ?>" required></div>
      <div class="form-field"><label for="c-body">پیام</label><textarea id="c-body" name="body" required><?= old('body') ?></textarea></div>
      <button class="btn btn-primary btn-block">ارسال پیام</button>
    </form>
  </div>
</div></section>
<?php }); }

/* ---------- سبد / پرداخت / سفارش ---------- */
function page_cart():void{ layout('سبد خرید',function(){ $items=cart_items(); ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / سبد خرید</p><h1>سبد خرید شما</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <?php if(!$items): ?>
    <div class="empty-state card"><p style="font-size:2.6rem"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg></p><p>سبد خرید شما خالیه.</p><p style="margin-top:1rem"><a class="btn btn-primary" href="<?= url('shop') ?>">بازگشت به فروشگاه</a></p></div>
  <?php else: ?>
    <div class="checkout-grid" id="cartPage">
      <div class="card reveal">
        <form method="post"><input type="hidden" name="action" value="cart_update"><?= csrf_field() ?>
        <?php foreach($items as $i): $p=$i['p']; ?>
          <div class="cart-item" data-cart-row data-id="<?= (int)$p['id'] ?>" data-price="<?= (float)$p['price'] ?>" data-max="<?= max(1,(int)$p['stock']) ?>">
            <img src="<?= e($p['image']??'') ?>" alt="">
            <div class="ci-info"><b><?= e($p['title']) ?></b><small data-unit-price><?= money($p['price']) ?> / هر عدد</small><?php if((int)$p['stock']<=5): ?><small class="ci-stock<?= (int)$p['stock']<=0?' is-out':'' ?>"><?= fi('box',13) ?><?= (int)$p['stock']>0?'فقط '.fa_num((int)$p['stock']).' تا در انبار مانده':'ناموجود' ?></small><?php endif; ?></div>
            <div class="qty-group">
              <button type="button" class="qty-step" data-step="-1" aria-label="کاهش"<?= $i['qty']<=1?' disabled':'' ?>>−</button>
              <input type="number" class="qty-input" data-qty name="qty[<?= (int)$p['id'] ?>]" value="<?= (int)$i['qty'] ?>" min="0" max="99" aria-label="تعداد" inputmode="numeric">
              <button type="button" class="qty-step" data-step="1" aria-label="افزایش"<?= $i['qty']>=(int)$p['stock']?' disabled':'' ?>>+</button>
            </div>
            <span class="ci-price" data-line-total><?= money($p['price']*$i['qty']) ?></span>
            <button type="button" form="rm<?= (int)$p['id'] ?>" class="btn btn-soft btn-sm" title="حذف"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
          <form id="rm<?= (int)$p['id'] ?>" method="post" class="inline-form" style="display:none"><input type="hidden" name="action" value="cart_remove"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"></form>
        <?php endforeach; ?>
          <p style="margin-top:1.2rem"><button class="btn btn-outline btn-sm">بهروزرسانی سبد</button> <span style="color:var(--ink-3);font-size:.8rem">تغییر تعداد بلافاصله در جمع اعمال میشه؛ دکمهٔ ذخیره برای نهایی‌کردن در دیتابیس است.</span></p>
        </form>
      </div>
      <div class="cart-summary reveal" style="--d:.1s">
        <h2 style="font-family:var(--fd);font-size:1.3rem;margin-bottom:1rem">خلاصهٔ سفارش</h2>
        <?php foreach($items as $i): ?>
        <p data-summary-row data-id="<?= (int)$i['p']['id'] ?>" style="display:flex;justify-content:space-between;font-size:.88rem;color:var(--ink-2);padding:.25rem 0">
          <span><?= e($i['p']['title']) ?> × <span data-sum-qty><?= (int)$i['qty'] ?></span></span>
          <span data-sum-line><?= money($i['p']['price']*$i['qty']) ?></span>
        </p><?php endforeach; ?>
        <div class="total-row"><span>جمع کل</span><b data-total><?= money(cart_total()) ?></b></div>
        <a class="btn btn-primary btn-block" style="margin-top:1.2rem" href="<?= url('checkout') ?>">ادامه و تسویهحساب ←</a>
        <a class="btn btn-ghost btn-block" href="<?= url('shop') ?>">خرید بیشتر</a>
      </div>
    </div>
  <?php endif; ?>
</div></section>
<?php }); }

function page_checkout():void{ require_login(); $u=current_user();
  if(!cart_items()){ flash('error','سبد خرید خالیه! '); redirect(url('shop')); }
  layout('تسویه‌حساب',function()use($u){ $items=cart_items(); ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / تسویه‌حساب</p><h1>اطلاعات ارسال و پرداخت</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <div class="checkout-grid">
    <div class="card reveal">
      <h2>اطلاعات خریدار</h2>
      <form method="post">
        <input type="hidden" name="action" value="checkout_info"><?= csrf_field() ?>
        <div class="form-field"><label>نام و نام خانوادگی</label><input type="text" value="<?= e($u['name']) ?>" disabled></div>
        <div class="form-field"><label for="ch-phone">شماره تماس</label><input id="ch-phone" type="tel" name="phone" value="<?= old('phone') ?>" placeholder="09123456789" required></div>
        <div class="form-field"><label for="ch-addr">آدرس تحویل</label><textarea id="ch-addr" name="address" required><?= old('address') ?></textarea></div>
        <div class="form-field"><label for="ch-note">توضیحات سفارش <span class="hint">(اختیاری)</span></label><input id="ch-note" type="text" name="note" value="<?= old('note') ?>"></div>
        <button class="btn btn-primary btn-block">ادامه(اتصال به درگاه پرداخت)  ←</button>
      </form>
    </div>
    <div class="cart-summary reveal" style="--d:.1s">
      <h2 style="font-family:var(--fd);font-size:1.3rem;margin-bottom:1rem">سفارش شما</h2>
      <?php foreach($items as $i): ?><p style="display:flex;justify-content:space-between;font-size:.88rem;color:var(--ink-2);padding:.25rem 0"><span><?= e($i['p']['title']) ?> × <?= fa_num($i['qty']) ?></span><span><?= money($i['p']['price']*$i['qty']) ?></span></p><?php endforeach; ?>
      <div class="total-row"><span>مبلغ قابل پرداخت</span><b><?= money(cart_total()) ?></b></div>
    </div>
  </div>
</div></section>
<?php }); }

function page_payment():void{ require_login();
  if(!cart_items()){ flash('error','سبد خرید خالیه'); redirect(url('shop')); }
  layout('درگاه پرداخت',function(){ $total=cart_total(); ?>
<section class="section" style="padding-top:2rem"><div class="container">
  <div class="pay-gateway reveal">
    <div class="pay-head">
      <p style="font-size:.9rem;opacity:.9"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-inline-end:4px"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> درگاه پرداخت امن (شبیه‌سازی‌شده)</p>
      <div class="amount"><?= money($total) ?></div>
    </div>
    <div class="pay-body">
      <p style="font-size:.85rem;color:var(--ink-2);margin-bottom:.6rem">شمارهٔ کارت (تستی)</p>
      <div class="card-row">6037 **** **** 1234</div>
      <form method="post"><input type="hidden" name="action" value="pay"><?= csrf_field() ?>
        <button class="btn btn-success btn-block">پرداخت <?= money($total) ?></button>
      </form>
      <form method="post" style="margin-top:.6rem"><input type="hidden" name="action" value="cancel_pay"><?= csrf_field() ?>
        <button class="btn btn-ghost btn-block">لغو و بازگشت به سبد</button>
      </form>
      <p class="pay-note">  درگاه آزمایشیه و هیچ تراکنش واقعی انجام نمیشه!</p>
    </div>
  </div>
</div></section>
<?php }); }

function page_order_success():void{ require_login(); $u=current_user();
  $st=db()->prepare('SELECT * FROM orders WHERE id=? AND user_id=? LIMIT 1');
  $st->execute([(int)($_GET['id']??0),(int)$u['id']]); $order=$st->fetch();
  if(!$order){ flash('error','سفارش یافت نشد.'); redirect(url('my_orders')); }
  layout('سفارش ثبت شد',function()use($order){ ?>
<section class="section" style="padding-top:2rem"><div class="container">
  <div class="success-box reveal">
    <div class="success-icon"><?= fi('check',44) ?></div>
    <h1 style="font-family:var(--fd);font-size:1.9rem;margin-bottom:.4rem">پرداخت موفق!</h1>
    <p class="section-lead">سفارش ثبت شد و به‌زودی ارسال خواهد شد</p>
    <p style="margin:1.2rem 0;font-size:.95rem">شمارهٔ پیگیری: <b class="ref" style="font-family:Consolas,monospace;color:var(--teal-deep)"><?= e($order['ref_id']) ?></b></p>
    <p style="font-family:var(--fd);font-size:1.4rem;color:var(--teal-deep)"><?= money($order['total']) ?></p>
    <div style="display:flex;gap:.7rem;justify-content:center;margin-top:1.6rem;flex-wrap:wrap">
      <a class="btn btn-primary" href="<?= url('my_orders') ?>"> سفارش‌های من</a>
      <a class="btn btn-outline" href="<?= url('shop') ?>">خرید بیشتر</a>
    </div>
  </div>
</div></section>
<?php }); }

function page_my_orders():void{ require_login(); $u=current_user();
  $st=db()->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC');
  $st->execute([(int)$u['id']]); $orders=$st->fetchAll();
  layout('سفارش‌های من',function()use($orders){ ?>
<section class="page-head"><div class="container"><p class="breadcrumb">خانه / سفارش‌های من</p><h1>سفارش‌های من</h1></div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <?php if(!$orders): ?><div class="empty-state card"><p>هنوز سفارشی ثبت نکردین!</p><p style="margin-top:1rem"><a class="btn btn-primary" href="<?= url('shop') ?>">شروع خرید</a></p></div>
  <?php else: foreach($orders as $o):
    $it=db()->prepare('SELECT * FROM order_items WHERE order_id=?'); $it->execute([(int)$o['id']]); $items=$it->fetchAll(); ?>
    <div class="order-card reveal">
      <div class="order-head">
        <span class="ref"><?= e($o['ref_id']) ?></span>
        <span style="color:var(--ink-3);font-size:.85rem"><?= adate($o['created_at'],true) ?></span>
        <span class="badge badge-<?= e($o['status']) ?>"><?= e(ORDER_STATUS[$o['status']]??$o['status']) ?></span>
      </div>
      <ul class="order-items">
        <?php foreach($items as $i): ?><li><span><?= e($i['title']) ?> × <?= fa_num($i['qty']) ?></span><span><?= money($i['price']*$i['qty']) ?></span></li><?php endforeach; ?>
      </ul>
      <div class="order-total"><span>مبلغ کل</span><b><?= money($o['total']) ?></b></div>
    </div>
  <?php endforeach; endif; ?>
</div></section>
<?php }); }

/* ---------- احراز هویت ---------- */
function page_login():void{ layout('ورود',function(){ if(current_user()) redirect(url('panel')); ?>
<div class="auth-wrap reveal">
  <h1 class="auth-title">ورود به حساب</h1>
  <p class="auth-sub">با نام کاربری یا ایمیل خود وارد شوید.</p>
  <form method="post">
    <input type="hidden" name="action" value="login"><?= csrf_field() ?>
    <div class="form-field"><label for="l-id">نام کاربری یا ایمیل</label><input id="l-id" type="text" name="identifier" value="<?= old('identifier') ?>" required autofocus></div>
    <div class="form-field"><label for="l-pass">رمز عبور</label><input id="l-pass" type="password" name="password" required></div>
    <button class="btn btn-primary btn-block">ورود</button>
  </form>
  <p class="auth-alt">حساب ندارید؟ <a href="<?= url('register') ?>">ثبت‌نام کنید</a></p>
</div>
<?php }); }

function page_register():void{ layout('ثبت‌نام',function(){ if(current_user()) redirect(url('panel')); ?>
<div class="auth-wrap reveal">
  <h1 class="auth-title">ساخت حساب کاربری</h1>
  <p class="auth-sub">برای دسترسی به پنل کاربری و خرید از فروشگاه ثبت‌نام کنید.</p>
  <form method="post">
    <input type="hidden" name="action" value="register"><?= csrf_field() ?>
    <div class="form-field"><label for="r-name">نام و نام خانوادگی</label><input id="r-name" type="text" name="name" value="<?= old('name') ?>" required></div>
    <div class="form-field"><label for="r-user">نام کاربری <span class="hint">(انگلیسی)</span></label><input id="r-user" type="text" name="username" value="<?= old('username') ?>" required></div>
    <div class="form-field"><label for="r-email">ایمیل</label><input id="r-email" type="email" name="email" value="<?= old('email') ?>" required></div>
    <div class="form-field"><label for="r-pass">رمز عبور <span class="hint">(حداقل ۸ کاراکتر)</span></label><input id="r-pass" type="password" name="password" required></div>
    <div class="form-field"><label for="r-pass2">تکرار رمز عبور</label><input id="r-pass2" type="password" name="password_confirm" required></div>
    <button class="btn btn-primary btn-block">ثبت‌نام</button>
  </form>
  <p class="auth-alt">حساب دارید؟ <a href="<?= url('login') ?>">وارد شوید</a></p>
</div>
<?php }); }

function page_panel():void{ require_login(); $u=current_user(); layout('پنل کاربری',function()use($u){
  $oc=db()->prepare('SELECT COUNT(*) FROM orders WHERE user_id=?'); $oc->execute([(int)$u['id']]); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <div class="panel-head reveal">
    <div class="avatar-circle"><?= e(mb_substr($u['name'],0,1)) ?></div>
    <div><h1>سلام، <?= e($u['name']) ?></h1><p>عضویت از <?= adate($u['created_at']) ?> — <?= fa_num($oc->fetchColumn()) ?> سفارش</p>
    <span class="role-badge"><?= $u['role']==='admin'?'مدیر':'کاربر' ?></span></div>
  </div>
  <?php if(!empty($_SESSION['must_change_pw'])): ?>
  <div style="background:#fff7e6;border:1px solid #f3d692;color:#7c5400;border-radius:var(--r-md);padding:1rem 1.3rem;margin-bottom:1.5rem;display:flex;gap:.6rem;align-items:flex-start;font-size:.95rem">
    <span aria-hidden="true">⚠️</span>
    <span><b>امنیت حساب:</b> هنوز از رمز عبور پیش‌فرض استفاده می‌کنید. از کارت «تغییر رمز عبور» در همین صفحه رمز جدیدی انتخاب کنید تا این هشدار برطرف شود.</span>
  </div>
  <?php endif; ?>
  <div class="panel-grid">
    <div class="card reveal"><h2>ویرایش اطلاعات</h2>
      <form method="post"><input type="hidden" name="action" value="profile"><?= csrf_field() ?>
        <div class="form-field"><label for="p-name">نام و نام خانوادگی</label><input id="p-name" type="text" name="name" value="<?= old('name',$u['name']) ?>" required></div>
        <div class="form-field"><label for="p-email">ایمیل</label><input id="p-email" type="email" name="email" value="<?= old('email',$u['email']) ?>" required></div>
        <button class="btn btn-primary btn-block">ذخیره تغییرات</button>
      </form>
    </div>
    <div class="card reveal" style="--d:.1s"><h2>تغییر رمز عبور</h2>
      <form method="post"><input type="hidden" name="action" value="password"><?= csrf_field() ?>
        <div class="form-field"><label for="p-cur">رمز عبور فعلی</label><input id="p-cur" type="password" name="current" required></div>
        <div class="form-field"><label for="p-new">رمز عبور جدید <span class="hint">(حداقل ۸ کاراکتر)</span></label><input id="p-new" type="password" name="password" required></div>
        <div class="form-field"><label for="p-new2">تکرار رمز عبور جدید</label><input id="p-new2" type="password" name="password_confirm" required></div>
        <button class="btn btn-saffron btn-block">به‌روزرسانی رمز</button>
      </form>
    </div>
    <div class="card reveal" style="--d:.2s"><h2>سفارش‌ها و دسترسی</h2>
      <div style="display:flex;gap:.6rem;flex-wrap:wrap">
        <a class="btn btn-primary btn-sm" href="<?= url('my_orders') ?>"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-inline-end:4px"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg> سفارش‌های من</a>
        <a class="btn btn-outline btn-sm" href="<?= url('shop') ?>">فروشگاه</a>
        <a class="btn btn-outline btn-sm" href="<?= url('contact') ?>">تماس</a>
      </div>
      <ul class="info-list" style="margin-top:1.2rem">
        <li><span>نام کاربری</span><b><?= e($u['username']) ?></b></li>
        <li><span>نقش</span><b><?= $u['role']==='admin'?'مدیر':'کاربر' ?></b></li>
        <li><span>وضعیت</span><b style="color:#15803d">فعال</b></li>
      </ul>
    </div>
  </div>
</div></section>
<?php }); }

/* ---------- مدیریت ---------- */
function admin_tabs(string $active):void{ ?>
<div class="admin-tabs">
  <a class="admin-tab<?= $active==='dash'?' is-active':'' ?>" href="<?= url('admin') ?>">داشبورد</a>
  <a class="admin-tab<?= $active==='orders'?' is-active':'' ?>" href="<?= url('admin_orders') ?>">سفارش‌ها</a>
  <a class="admin-tab<?= $active==='products'?' is-active':'' ?>" href="<?= url('admin_products') ?>">محصولات</a>
  <a class="admin-tab<?= $active==='users'?' is-active':'' ?>" href="<?= url('admin_users') ?>">کاربران</a>
  <a class="admin-tab<?= $active==='messages'?' is-active':'' ?>" href="<?= url('admin_messages') ?>">پیامها</a>
</div>
<?php }

function page_admin():void{ require_admin(); layout('داشبورد مدیریت',function(){
  $s=['users'=>(int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
      'products'=>(int)db()->query('SELECT COUNT(*) FROM products')->fetchColumn(),
      'orders'=>(int)db()->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
      'revenue'=>(float)db()->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status<>'cancelled'")->fetchColumn()];
  $recent=db()->query('SELECT o.*,u.name AS uname FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 5')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('dash'); ?>
  <div class="stat-cards">
    <div class="stat-card reveal"><div class="num"><?= fa_num($s['users']) ?></div><div class="lbl">کاربران</div></div>
    <div class="stat-card gold reveal" style="--d:.08s"><div class="num"><?= fa_num($s['orders']) ?></div><div class="lbl">سفارش‌ها</div></div>
    <div class="stat-card turq reveal" style="--d:.16s"><div class="num"><?= fa_num($s['products']) ?></div><div class="lbl">محصولات</div></div>
    <div class="stat-card rose reveal" style="--d:.24s"><div class="num" style="font-size:1.5rem"><?= money($s['revenue']) ?></div><div class="lbl">درآمد کل</div></div>
  </div>
  <div class="page-title-row reveal"><h1>آخرین سفارش‌ها</h1><a class="btn btn-primary btn-sm" href="<?= url('admin_orders') ?>">همهٔ سفارش‌ها</a></div>
  <?php if(!$recent): ?><div class="empty-state card">هنوز سفارشی ثبت نشده است.</div>
  <?php else: ?><div class="table-wrap reveal"><table>
    <thead><tr><th>پیگیری</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>
    <?php foreach($recent as $o): ?><tr>
      <td class="ref" style="font-family:Consolas,monospace"><?= e($o['ref_id']) ?></td>
      <td><?= e($o['uname']) ?></td>
      <td><?= money($o['total']) ?></td>
      <td><span class="badge badge-<?= e($o['status']) ?>"><?= e(ORDER_STATUS[$o['status']]??$o['status']) ?></span></td>
      <td><?= adate($o['created_at']) ?></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

function page_admin_orders():void{ require_admin(); layout('مدیریت سفارش‌ها',function(){
  $orders=db()->query('SELECT o.*,u.name AS uname,u.email AS uemail FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('orders'); ?>
  <div class="page-title-row"><h1>سفارش‌ها <span style="color:var(--ink-3);font-size:1rem">(<?= fa_num(count($orders)) ?>)</span></h1></div>
  <?php if(!$orders): ?><div class="empty-state card">هنوز سفارشی ثبت نشده است.</div>
  <?php else: ?><div class="table-wrap"><table>
    <thead><tr><th>پیگیری</th><th>مشتری</th><th>اقلام</th><th>مبلغ</th><th>تاریخ</th><th>وضعیت</th></tr></thead><tbody>
    <?php foreach($orders as $o):
      $cnt=db()->prepare('SELECT COALESCE(SUM(qty),0) FROM order_items WHERE order_id=?'); $cnt->execute([(int)$o['id']]); ?>
    <tr>
      <td class="ref" style="font-family:Consolas,monospace"><?= e($o['ref_id']) ?><br><small style="color:var(--ink-3)"><?= e($o['phone']) ?></small></td>
      <td><b><?= e($o['uname']) ?></b><br><small style="color:var(--ink-3)"><?= e($o['uemail']) ?></small></td>
      <td><?= fa_num($cnt->fetchColumn()) ?> عدد</td>
      <td><?= money($o['total']) ?></td>
      <td><?= adate($o['created_at']) ?></td>
      <td><form method="post" class="inline-form"><input type="hidden" name="action" value="order_status"><?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
        <select name="status" class="auto-submit" style="padding:.4rem .6rem;font-size:.85rem">
          <?php foreach(ORDER_STATUS as $k=>$l): ?><option value="<?= e($k) ?>"<?= $o['status']===$k?' selected':'' ?>><?= e($l) ?></option><?php endforeach; ?>
        </select></form></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

function page_admin_products():void{ require_admin(); layout('مدیریت محصولات',function(){
  $products=db()->query('SELECT * FROM products ORDER BY created_at DESC')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('products'); ?>
  <div class="page-title-row"><h1>محصولات <span style="color:var(--ink-3);font-size:1rem">(<?= fa_num(count($products)) ?>)</span></h1>
  <a class="btn btn-primary btn-sm" href="<?= url('product_create') ?>">+ محصول جدید</a></div>
  <?php if(!$products): ?><div class="empty-state card">هنوز محصولی ثبت نشده است.</div>
  <?php else: ?><div class="table-wrap"><table>
    <thead><tr><th>تصویر</th><th>عنوان</th><th>قیمت</th><th>موجودی</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($products as $p): ?><tr>
      <td><?= $p['image']?'<img class="thumb" src="'.e($p['image']).'" alt="">':'—' ?></td>
      <td><b><?= e($p['title']) ?></b><br><small style="color:var(--ink-3)"><?= e($p['slug']) ?></small></td>
      <td><?= money($p['price']) ?></td><td><?= fa_num($p['stock']) ?></td>
      <td><?= $p['status']==='published'?'<span class="badge badge-ok">منتشر</span>':'<span class="badge badge-draft">پیش‌نویس</span>' ?></td>
      <td><div class="row-actions">
        <a class="btn btn-outline btn-sm" href="<?= url('product_edit&id='.$p['id']) ?>">ویرایش</a>
        <form method="post" class="inline-form" data-confirm="این محصول حذف شود؟">
          <input type="hidden" name="action" value="product_delete"><?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button>
        </form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

function product_form(?array $editing):void{ layout($editing?'ویرایش محصول':'محصول جدید',function()use($editing){ ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('products'); ?>
  <div class="page-title-row"><h1><?= $editing?'ویرایش محصول':'محصول جدید' ?></h1><a class="btn btn-ghost btn-sm" href="<?= url('admin_products') ?>">بازگشت به لیست</a></div>
  <div class="card"><form method="post">
    <input type="hidden" name="action" value="product_save"><?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($editing['id']??0) ?>">
    <div class="panel-grid">
      <div>
        <div class="form-field"><label for="pr-title">عنوان محصول</label><input id="pr-title" type="text" name="title" value="<?= old('title',$editing['title']??'') ?>" required></div>
        <div class="form-field"><label for="pr-slug">اسلاگ <span class="hint">(اختیاری؛ خودکار ساخته می‌شود)</span></label><input id="pr-slug" type="text" name="slug" value="<?= old('slug',$editing['slug']??'') ?>"></div>
        <div class="form-field"><label for="pr-desc">توضیحات</label><textarea id="pr-desc" name="description"><?= old('description',$editing['description']??'') ?></textarea></div>
      </div>
      <div>
        <div class="form-field"><label for="pr-price">قیمت (تومان)</label><input id="pr-price" type="number" name="price" min="0" value="<?= old('price',(string)($editing['price']??0)) ?>" required></div>
        <div class="form-field"><label for="pr-stock">موجودی</label><input id="pr-stock" type="number" name="stock" min="0" value="<?= old('stock',(string)($editing['stock']??0)) ?>" required></div>
        <div class="form-field"><label for="pr-image">نشانی تصویر <span class="hint">(URL)</span></label><input id="pr-image" type="url" name="image" value="<?= old('image',$editing['image']??'') ?>"></div>
        <div class="form-field"><label for="pr-status">وضعیت</label><select id="pr-status" name="status">
          <?php $cur=old('status',$editing['status']??'published'); ?>
          <option value="published"<?= $cur==='published'?' selected':'' ?>>منتشرشده</option>
          <option value="draft"<?= $cur==='draft'?' selected':'' ?>>پیش‌نویس</option>
        </select></div>
      </div>
    </div>
    <button class="btn btn-primary">ذخیره محصول</button>
  </form></div>
</div></section>
<?php }); }
function page_product_create():void{ require_admin(); product_form(null); }
function page_product_edit():void{ require_admin();
  $st=db()->prepare('SELECT * FROM products WHERE id=? LIMIT 1'); $st->execute([(int)($_GET['id']??0)]); $p=$st->fetch();
  if(!$p){ flash('error','محصول یافت نشد.'); redirect(url('admin_products')); }
  product_form($p);
}

function page_admin_users():void{ require_admin(); layout('مدیریت کاربران',function(){
  $users=db()->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll(); ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('users'); ?>
  <div class="page-title-row"><h1>کاربران <span style="color:var(--ink-3);font-size:1rem">(<?= fa_num(count($users)) ?>)</span></h1></div>
  <div class="table-wrap"><table>
    <thead><tr><th>کاربر</th><th>ایمیل</th><th>نقش</th><th>وضعیت</th><th>عضویت</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($users as $usr): ?><tr>
      <td><div class="user-cell"><span class="mini"><?= e(mb_substr($usr['name'],0,1)) ?></span>
        <div><b><?= e($usr['name']) ?></b><br><small style="color:var(--ink-3)">@<?= e($usr['username']) ?></small></div></div></td>
      <td><?= e($usr['email']) ?></td>
      <td><?= $usr['role']==='admin'?'<span class="badge badge-admin">مدیر</span>':'<span class="badge badge-user">کاربر</span>' ?></td>
      <td><?= (int)$usr['status']?'<span class="badge badge-ok">فعال</span>':'<span class="badge badge-no">غیرفعال</span>' ?></td>
      <td><?= adate($usr['created_at']) ?></td>
      <td><div class="row-actions">
        <form method="post" class="inline-form"><input type="hidden" name="action" value="user_role"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-outline btn-sm"><?= $usr['role']==='admin'?'تبدیل به کاربر':'ارتقا به مدیر' ?></button></form>
        <form method="post" class="inline-form"><input type="hidden" name="action" value="user_status"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-ghost btn-sm"><?= (int)$usr['status']?'غیرفعال‌سازی':'فعال‌سازی' ?></button></form>
        <form method="post" class="inline-form" data-confirm="این کاربر حذف شود؟"><input type="hidden" name="action" value="user_delete"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button></form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div>
</div></section>
<?php }); }

function page_admin_messages():void{ require_admin(); layout('مدیریت پیامها',function(){
  $msgs=db()->query('SELECT * FROM messages ORDER BY created_at DESC')->fetchAll();
  $unread=(int)db()->query('SELECT COUNT(*) FROM messages WHERE is_read=0')->fetchColumn();
  $sessions=db()->query("SELECT s.*,u.name AS uname,u.email AS uemail,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.session_id=s.id) AS msg_count,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.session_id=s.id AND m.role='user' AND m.seen_by_admin=0) AS new_count,
      (SELECT m.body FROM chat_messages m WHERE m.session_id=s.id ORDER BY m.id DESC LIMIT 1) AS last_body
      FROM chat_sessions s LEFT JOIN users u ON u.id=s.user_id
      ORDER BY s.updated_at DESC LIMIT 60")->fetchAll();
  $openId=(int)($_GET['s']??0);
  $thread=[]; $cur=null;
  if($openId){
    $st=db()->prepare('SELECT s.*,u.name AS uname,u.email AS uemail FROM chat_sessions s LEFT JOIN users u ON u.id=s.user_id WHERE s.id=? LIMIT 1');
    $st->execute([$openId]); $cur=$st->fetch();
    if($cur){
      $thread=chat_history($openId,300);
      db()->prepare("UPDATE chat_messages SET seen_by_admin=1 WHERE session_id=? AND role='user'")->execute([$openId]);
    }
  } ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <?php admin_tabs('messages'); ?>
  <div class="page-title-row"><h1>پیامهای تماس
    <?php if($unread): ?><span class="badge badge-no" style="font-size:.8rem;vertical-align:middle;"><?= fa_num($unread) ?> جدید</span><?php endif; ?>
  </h1></div>
  <?php if(!$msgs): ?><div class="empty-state card">پیامی ثبت نشده است.</div>
  <?php else: ?><div class="table-wrap"><table>
    <thead><tr><th>فرستنده</th><th>موضوع</th><th>متن</th><th>تاریخ</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($msgs as $m): ?><tr<?= (int)$m['is_read']?'':' style="background:#fdf6ec"' ?>>
      <td><b><?= e($m['name']) ?></b><br><small style="color:var(--ink-3)"><?= e($m['email']) ?></small></td>
      <td><?= e($m['subject']) ?></td>
      <td><small><?= e(mb_substr($m['body'],0,120)) ?><?= mb_strlen($m['body'])>120?'…':'' ?></small></td>
      <td><?= adate($m['created_at']) ?></td>
      <td><div class="row-actions">
        <form method="post" class="inline-form"><input type="hidden" name="action" value="<?= (int)$m['is_read']?'message_unread':'message_read' ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><button class="btn btn-outline btn-sm"><?= (int)$m['is_read']?'نخوانده':'خواندم' ?></button></form>
        <form method="post" class="inline-form" data-confirm="این پیام حذف شود؟"><input type="hidden" name="action" value="message_delete"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button></form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>

  <div class="page-title-row" style="margin-top:2.5rem"><h1>گفتگوهای چت</h1></div>
  <?php if($cur): ?>
  <div class="card" style="margin-bottom:1.5rem">
    <div class="page-title-row">
      <h2 style="font-size:1.2rem">
        گفتگو #<?= fa_num($cur['id']) ?> —
        <?= $cur['uname']?e($cur['uname']):($cur['guest_name']?e($cur['guest_name']):'مهمان') ?>
        <span class="badge"><?= $cur['mode']==='human'?'پشتیبانی انسانی':'دستیار هوشمند' ?></span>
      </h2>
      <a class="btn btn-ghost btn-sm" href="<?= url('admin_messages') ?>">بستن</a>
    </div>
    <p style="font-size:.82rem;color:var(--ink-3)">
      <?= $cur['uemail']?e($cur['uemail']):($cur['guest_email']?e($cur['guest_email']):'—') ?>
      • آخرین بهروزرسانی: <?= adate($cur['updated_at'],true) ?>
    </p>
    <div style="margin:1rem 0;display:flex;flex-direction:column;gap:.6rem;max-height:420px;overflow-y:auto">
      <?php foreach($thread as $t): $me=$t['role']==='user'; ?>
      <div style="align-self:<?= $me?'flex-start':'flex-end' ?>;max-width:78%;background:<?= $me?'#eef4f1':($t['role']==='admin'?'#fdf3e3':'#e8f3f0') ?>;border:1px solid var(--line);border-radius:12px;padding:.6rem .9rem">
        <small style="color:var(--ink-3);display:block;font-size:.7rem"><?= $me?'کاربر':($t['role']==='admin'?'پشتیبانی':BOT_NAME) ?> • <?= adate($t['created_at'],true) ?></small>
        <span style="font-size:.88rem;white-space:pre-wrap"><?= e((string)$t['body']) ?></span>
      </div>
      <?php endforeach; ?>
      <?php if(!$thread): ?><p style="color:var(--ink-3);font-size:.85rem">پیامی در این گفتگو نیست.</p><?php endif; ?>
    </div>
    <form method="post" style="display:flex;gap:.5rem;flex-wrap:wrap">
      <input type="hidden" name="action" value="chat_reply"><?= csrf_field() ?>
      <input type="hidden" name="session_id" value="<?= (int)$cur['id'] ?>">
      <input type="text" name="body" maxlength="2000" required placeholder="پاسخ پشتیبانی…" style="flex:1;min-width:220px;padding:.6rem .9rem">
      <button class="btn btn-primary btn-sm">ارسال پاسخ</button>
    </form>
  </div>
  <?php endif; ?>
  <?php if(!$sessions): ?><div class="empty-state card">هنوز گفتگویی شروع نشده است.</div>
  <?php else: ?><div class="table-wrap"><table>
    <thead><tr><th>کاربر</th><th>نوع</th><th>آخرین پیام</th><th>تعداد</th><th>بهروزرسانی</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach($sessions as $s): ?><tr<?= (int)$s['new_count']?' style="background:#fdf6ec"':'' ?>>
      <td>
        <?php if($s['uname']): ?><b><?= e($s['uname']) ?></b><br><small style="color:var(--ink-3)"><?= e((string)$s['uemail']) ?></small>
        <?php elseif($s['guest_name']||$s['guest_email']): ?><b><?= e((string)($s['guest_name']?:'مهمان')) ?></b><br><small style="color:var(--ink-3)"><?= e((string)$s['guest_email']) ?></small>
        <?php else: ?><span class="badge">مهمان</span><?php endif; ?>
      </td>
      <td><span class="badge"><?= $s['mode']==='human'?'انسانی':'دستیار' ?></span><?php if((int)$s['new_count']): ?> <span class="badge badge-no"><?= fa_num($s['new_count']) ?> جدید</span><?php endif; ?></td>
      <td><small><?= e(mb_substr((string)$s['last_body'],0,90)) ?></small></td>
      <td><?= fa_num($s['msg_count']) ?></td>
      <td><?= adate($s['updated_at'],true) ?></td>
      <td><div class="row-actions">
        <a class="btn btn-outline btn-sm" href="<?= url('admin_messages').'&s='.(int)$s['id'] ?>">مشاهده</a>
        <form method="post" class="inline-form" data-confirm="کل این گفتگو حذف شود؟"><input type="hidden" name="action" value="chat_session_delete"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn btn-soft btn-sm">حذف</button></form>
      </div></td>
    </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div></section>
<?php }); }

/* ---------- موضوعات آموزشی (بلاگ داخلی برای سئو) ---------- */
function page_topics():void{ layout('آموزش و مقالات',function(){ ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <div class="section-head reveal"><span class="kicker">آموزش</span><h1 class="section-title">مقالات و موضوعات فنی</h1>
    <p class="section-lead">هر موضوع یک صفحهٔ مستقل داره؛ می‌تونی از داخل توضیحات پروژه‌ها یا محصولات به این صفحه‌ها لینک بدی.</p></div>
  <div class="topic-grid">
    <?php foreach(TOPICS as $slug=>$t): ?>
    <a class="topic-card reveal" href="<?= url('topic').'&t='.urlencode($slug) ?>">
      <h3><?= e($t['title']) ?></h3><p><?= e($t['lead']) ?></p>
    </a>
    <?php endforeach; ?>
  </div>
</div></section>
<?php }); }

function page_topic():void{
  $slug=(string)($_GET['t']??'');
  if(!isset(TOPICS[$slug])){ flash('error','موضوع مورد نظر پیدا نشد.'); redirect(url('topics')); }
  $t=TOPICS[$slug];
  layout($t['title'],function() use($slug,$t){ ?>
<section class="section" style="padding-top:3rem"><div class="container">
  <nav class="breadcrumb" aria-label="مسیر"><a href="<?= url() ?>">خانه</a> › <a href="<?= url('topics') ?>">آموزش و مقالات</a> › <span><?= e($t['title']) ?></span></nav>
  <article class="article reveal">
    <h1><?= e($t['title']) ?></h1>
    <p class="lead"><?= e($t['lead']) ?></p>
    <?php foreach(preg_split('/\n+/',$t['body']) as $para): if(trim($para)===''){continue;} ?>
    <p><?= e(trim($para)) ?></p>
    <?php endforeach; ?>
    <div class="topic-nav">
      <?php foreach(TOPICS as $s2=>$t2): if($s2===$slug){continue;} ?>
      <a href="<?= url('topic').'&t='.urlencode($s2) ?>"><?= e($t2['title']) ?></a>
      <?php endforeach; ?>
    </div>
  </article>
</div></section>
<?php }); }
/* ---------- جستجوی سراسری (محصولات + نمونه‌کارها + مقالات) ---------- */
function page_search():void{
  $q=trim((string)($_GET['q']??''));
  layout($q!==''?('جستجو: '.$q):'جستجو',function() use($q){
    $products=[]; $projs=[]; $topics=[];
    if($q!==''){
      $like='%'.$q.'%';
      $st=db()->prepare("SELECT * FROM products WHERE status='published' AND (title LIKE ? OR description LIKE ?) ORDER BY created_at DESC LIMIT 24");
      $st->execute([$like,$like]);
      $products=$st->fetchAll();
      foreach(projects() as $p){
        if(mb_stripos($p['title'],$q)!==false||mb_stripos($p['desc'],$q)!==false) $projs[]=$p;
      }
      foreach(TOPICS as $slug=>$t){
        if(mb_stripos($t['title'],$q)!==false||mb_stripos($t['lead'],$q)!==false||mb_stripos($t['body'],$q)!==false) $topics[$slug]=$t;
      }
    }
    $total=count($products)+count($projs)+count($topics);
?>
<section class="page-head"><div class="container">
  <p class="breadcrumb">خانه / جستجو</p>
  <h1>نتیجهٔ جستجو</h1>
  <?php if($q===''): ?>
    <p class="section-lead">عبارتی برای جستجو وارد کنید؛ نتایج از محصولات، نمونه‌کارها و مقالات آموزشی جمع‌آوری می‌شود.</p>
  <?php else: ?>
    <p class="section-lead">برای «<?= e($q) ?>» تعداد <?= fa_num($total) ?> نتیجه پیدا شد.</p>
  <?php endif; ?>
</div></section>
<section class="section" style="padding-top:1rem"><div class="container">
  <?php if($q!==''&&$total===0): ?>
    <div class="empty-state card">
      <p>نتیجه‌ای برای «<?= e($q) ?>» پیدا نشد.</p>
      <p style="margin-top:1rem"><a class="btn btn-primary" href="<?= url('shop') ?>">رفتن به فروشگاه</a> <a class="btn btn-outline" href="<?= url('topics') ?>">مقالات آموزشی</a></p>
    </div>
  <?php endif; ?>

  <?php if($products): ?>
  <div class="section-head reveal"><span class="kicker"><?= fi('cart',16) ?>محصولات</span><h2 class="section-title">محصولات مرتبط</h2></div>
  <div class="shop-grid">
    <?php foreach($products as $p): $inStock=(int)$p['stock']>0; ?>
    <article class="product-card reveal">
      <div class="product-media"><img src="<?= e($p['image']??'') ?>" alt="<?= e($p['title']) ?>" loading="lazy">
        <span class="product-stock<?= !$inStock?' out':'' ?>"><?= $inStock?'موجود ('.fa_num($p['stock']).')':'ناموجود' ?></span></div>
      <div class="product-body">
        <h3><?= e($p['title']) ?></h3><p><?= e(mb_substr((string)$p['description'],0,70)) ?>…</p>
        <div class="product-foot"><span class="price"><?= money($p['price']) ?></span>
          <form method="post" class="inline-form"><input type="hidden" name="action" value="add_to_cart"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="btn btn-sm btn-primary"<?= $inStock?'':' disabled' ?>><?= $inStock?'افزودن به سبد':'ناموجود' ?></button>
          </form>
        </div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if($projs): ?>
  <div class="section-head reveal" style="margin-top:3rem"><span class="kicker"><?= fi('image',16) ?>نمونه‌کارها</span><h2 class="section-title">پروژه‌های مرتبط</h2></div>
  <div class="portfolio-grid">
    <?php foreach($projs as $p): ?>
    <article class="project-card reveal">
      <span class="project-year"><?= e($p['year']) ?></span>
      <div class="project-media"><img src="<?= e($p['image']) ?>" alt="<?= e($p['title']) ?>" loading="lazy"></div>
      <div class="project-body">
        <div class="project-tags"><?php foreach($p['tags'] as $t): ?><span class="tag<?= $t==='shop'?' tag-gold':'' ?>"><?= e(TAG_LABEL[$t]??$t) ?></span><?php endforeach; ?></div>
        <h3><?= e($p['title']) ?></h3><p><?= e($p['desc']) ?></p>
        <a class="project-link" href="<?= url('portfolio') ?>">دیدن همهٔ نمونه‌کارها</a>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if($topics): ?>
  <div class="section-head reveal" style="margin-top:3rem"><span class="kicker"><?= fi('book',16) ?>آموزش</span><h2 class="section-title">مقالات مرتبط</h2></div>
  <div class="topic-grid">
    <?php foreach($topics as $slug=>$t): ?>
    <a class="topic-card reveal" href="<?= url('topic').'&t='.urlencode($slug) ?>">
      <h3><?= e($t['title']) ?></h3><p><?= e($t['lead']) ?></p>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div></section>
<?php }); }
$routes=[
  'home'=>'page_home','about'=>'page_about','portfolio'=>'page_portfolio','shop'=>'page_shop','contact'=>'page_contact',
  'topics'=>'page_topics','topic'=>'page_topic','search'=>'page_search','demo'=>'page_demo',
  'login'=>'page_login','register'=>'page_register','panel'=>'page_panel',
  'cart'=>'page_cart','checkout'=>'page_checkout','payment'=>'page_payment','order_success'=>'page_order_success','my_orders'=>'page_my_orders',
  'admin'=>'page_admin','admin_orders'=>'page_admin_orders','admin_products'=>'page_admin_products','admin_users'=>'page_admin_users','admin_messages'=>'page_admin_messages',
  'product_create'=>'page_product_create','product_edit'=>'page_product_edit',
];
$page=$_GET['page']??'home';
$fn=$routes[$page]??'page_home';
$fn();